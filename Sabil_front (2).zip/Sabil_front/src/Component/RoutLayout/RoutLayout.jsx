import { Outlet } from "react-router-dom";
import React, { useContext, lazy } from "react";
const Navbar = lazy(() => import("../Navbar/Navbar"));
const Footer = lazy(() => import("../Footer/Footer"));
const MobileNav = lazy(() => import("../MobileNav/MobileNav.jsx"));
const DarkModeToggle = lazy(() =>
  import("../Ui/DarkModeToggle/DarkModeToggle.jsx")
);
const WhatsappComponent = lazy(() =>
  import("../Ui/WhatsappComponent/WhatsappComponent.jsx")
);
import Spinner from "../Ui/Spinner/Spinner.jsx";
import { IsMobileContext } from "../../Context/isMobileContext";
import { isThemeModeContext } from "../../Context/isThemeModeContext.jsx";
import HomeLoading from "../Ui/HomeLoading/HomeLoading.jsx";

export default function RoutLayout() {
  const { isMobile } = useContext(IsMobileContext);
  const { isDarkMode, setIsDarkMode } = useContext(isThemeModeContext);
  return (
    <React.Suspense fallback={<HomeLoading />}>
      <React.Suspense fallback={<Spinner sectionFlag={false} />}>
        {!isMobile && <Navbar />}
        <WhatsappComponent />
      </React.Suspense>
      <React.Suspense fallback={<Spinner />}>
        <Outlet />
      </React.Suspense>
      <React.Suspense fallback={<Spinner sectionFlag={false} />}>
        <DarkModeToggle isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} />
        {isMobile && <MobileNav />} <Footer />
      </React.Suspense>
    </React.Suspense>
  );
}
