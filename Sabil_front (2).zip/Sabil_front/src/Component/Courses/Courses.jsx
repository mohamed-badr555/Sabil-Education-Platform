import React, { useEffect, useState } from "react";
import style from "./Courses.module.css";
import { useTranslation } from "react-i18next";
import Heading from "../Heading/Heading";
import Search from "../Ui/SearchInput/SearchInput";
import { OrderBasedOn } from "../../Utilies/data";
import { Link } from "react-router-dom";
import { motion, useInView } from "framer-motion";
import ApiManager from "../../Utilies/ApiManager";
// import { use } from 'react';
import Spinner from "../Ui/Spinner/Spinner";
import { RatingStars } from "../RatingStars/RatingStars";
import DefaultImage from "../../assets/Images/default.png"

const Courses = () => {
  const { t } = useTranslation();
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [selectedPrice, setSelectedPrice] = useState("");
  const [selectedLevel, setSelectedLevel] = useState("");
  // const [selectedLanguage, setSelectedLanguage] = useState('');
  const [SortingType, setSortingType] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const ref = React.useRef(null);
  const [flagNoData, setFlagNoData] = useState(false);
  const [pupularCourses, setPupularCourses] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(null);
  const [pageSize, setPageSize] = useState(10);
  const [Categories, setCategories] = useState(null);
  const [search, setSearch] = useState("");
  const [isLoading, setIsLoading] = useState(false); // 1. Add loading state

  const getPopularCourses = async () => {
    try {
      setPupularCourses(null);
      setFlagNoData(false);
      const { data } = await ApiManager.getPopularCourses();
      if (data.data && data.data.length !== 0) {
        setPupularCourses(data.data.data);
        setPageSize(data.data.pageSize);

        setTotalPages(Math.ceil(data.data.count / pageSize));
      } else {
        setFlagNoData(true);
        setPupularCourses(null);
      }
    } catch (error) {
      setFlagNoData(true);
    }
  };
  const getCateogries = async () => {
    try {
      const { data } = await ApiManager.getCategories();

      if (data.data && data.data.length !== 0) {
        setCategories(data.data);
      } else {
        setCategories(null);
      }
    } catch (error) {
      setCategories(null);
    }
  };
  const getSearch = async (param = "") => {
    try {
      setIsLoading(true); // 2. Modify getSearch function
      setPupularCourses(null);
      setFlagNoData(false);
      const { data } = await ApiManager.searchCourses(
        `?search=${param}&categoryId=${selectedDepartment}&IsFree=${selectedPrice}&level=${selectedLevel}&sort=${SortingType}&pageNo=${currentPage}&pageSize=${pageSize}`
      );
      if (data.data && data.data.length !== 0) {
        setPupularCourses(data.data.data);
        setPageSize(data.data.pageSize);
        setTotalPages(Math.ceil(data.data.count / pageSize));
      } else {
        setFlagNoData(true);
        setPupularCourses(null);
      }
    } catch (error) {
      setFlagNoData(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getPopularCourses();
  }, [currentPage]);

  useEffect(() => {
    getCateogries();
  }, []);
  useEffect(() => {
    if (
      search ||
      selectedDepartment ||
      selectedPrice ||
      selectedLevel ||
      SortingType ||
      currentPage
    ) {
      getSearch(search);
    } else {
      getPopularCourses();
    }
  }, [
    search,
    currentPage,
    selectedDepartment,
    selectedPrice,
    selectedLevel,
    SortingType,
  ]);

  const isInView = useInView(ref, { once: true, amount: 0.1 });
  // Add this handler function
  // const handleLanguageChange = (e) => {
  //   const value = e.target.value;
  //   setSelectedLanguage(selectedLanguage === value ? '' : value);
  // };

  // Add these handler functions
  const handlePriceChange = (e) => {
    const value = e.target.value;
    // Convert to boolean - true for free, false for paid
    const isFree = value === "free";
    setSelectedPrice(isFree);
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  return (
    <section id="courses" className="overflow-hidden ">
      <Heading title={t("Courses_title")} text={t("Courses_text")} />
      <div className="container my-5 ">
        <Search SearchAbout={t("searchAboutCourses")} setSearch={setSearch} />

        <div className={style.coursesContainer}>
          {/*filter from lg section  */}
          <div className={`${style.filterLg} `}>
            <div className="d-flex align-items-center  justify-content-between">
              <div>
                <h3>{t("Courses_list")}</h3>
              </div>
              <div className="">
                <div
                  className={`${style.filterIcon} d-flex align-items-center gap-2`}
                  onClick={toggleSidebar}
                >
                  <i className="fa-solid fa-filter"></i>
                  <p>{t("filter_lg")}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Add overlay */}
          <div
            className={`${style.sidebarOverlay} ${
              isSidebarOpen ? style.active : ""
            }`}
            onClick={closeSidebar}
          ></div>

          {/* Update sidebar classes */}
          <div
            className={`${style.sidebar} shadow ${
              isSidebarOpen ? style.active : ""
            }`}
          >
            <div className={style.filterSection}>
              <h3>{t("Price_Course")}</h3>
              <ul>
                <li className="d-flex align-items-center mb-2 gap-2">
                  <input
                    type="radio"
                    name="price"
                    id="free"
                    value="free"
                    checked={selectedPrice === true}
                    onChange={handlePriceChange}
                  />
                  <label
                    htmlFor="free"
                    onClick={(e) => {
                      e.preventDefault();
                      handlePriceChange({ target: { value: "free" } });
                    }}
                  >
                    {t("Free_Course")}
                  </label>
                </li>
                <li className="d-flex align-items-center mb-2 gap-2">
                  <input
                    type="radio"
                    name="price"
                    id="paied"
                    value="paied"
                    checked={selectedPrice === false}
                    onChange={handlePriceChange}
                  />
                  <label
                    htmlFor="paied"
                    onClick={(e) => {
                      e.preventDefault();
                      handlePriceChange({ target: { value: "paied" } });
                    }}
                  >
                    {t("Paied_Course")}
                  </label>
                </li>
              </ul>
            </div>
            {/* For Future */}
            {/* <div className={style.filterSection}>
            <h3>{t("Type_Course")}</h3>
            <ul>
              <li className='d-flex align-items-center mb-2 gap-2'>
                <input 
                  type="radio" 
                  name="type" 
                  id="onlline"
                  value="onlline"
                  checked={selectedType === 'onlline'}
                  onChange={handleTypeChange}
                />
                <label 
                  htmlFor="onlline"
                  onClick={(e) => {
               
                    e.preventDefault();
                    handleTypeChange({ target: { value: 'onlline' } });
                  }}
                >
                  {t("Online_Course")}
                </label>
              </li>
              <li className='d-flex align-items-center mb-2 gap-2'>
                <input 
                  type="radio" 
                  name="type" 
                  id="offline"
                  value="offline"
                  checked={selectedType === 'offline'}
                  onChange={handleTypeChange}
                />
                <label 
                  htmlFor="offline"
                  onClick={(e) => {
               
                    e.preventDefault();
                    handleTypeChange({ target: { value: 'offline' } });
                  }}
                >
                  {t("Offline_Course")}
                </label>
              </li>
            </ul>
          </div>

    
          <div className={style.filterSection}>
            <h3>{t('Language_Course')}</h3>
            <ul>
              <li className='d-flex align-items-center mb-2 gap-2'>
                <input 
                  type="radio" 
                  name="language" 
                  id="arabic"
                  value="arabic"
                  checked={selectedLanguage === 'arabic'}
                  onChange={handleLanguageChange}
                />
                <label 
                  htmlFor="arabic"
                  onClick={(e) => {
               
                    e.preventDefault();
                    handleLanguageChange({ target: { value: 'arabic' } });
                  }}
                >
                  {t('Lan_Ar_Course')}
                </label>
              </li>
              <li className='d-flex align-items-center mb-2 gap-2'>
                <input 
                  type="radio" 
                  name="language" 
                  id="english"
                  value="english"
                  checked={selectedLanguage === 'english'}
                  onChange={handleLanguageChange}
                />
                <label 
                  htmlFor="english"
                  onClick={(e) => {
               
                    e.preventDefault();
                    handleLanguageChange({ target: { value: 'english' } });
                  }}
                >
                  {t('Lan_En_Course')}
                </label>
              </li>
            </ul>
          </div> */}
          </div>

          {/* Main Content */}
          <div className={style.mainContent}>
            <div className={`${style.coursesGrid} mb-3`}>
              <div className={style.topFilters}>
                <div className="">
                  <select
                    className={`${style.filterSelect} rounded-pill  `}
                    onChange={(e) => {
                      setSelectedDepartment(e.target.value);
                    }}
                    value={selectedDepartment || ""}
                  >
                    <option value="">{t("Courses_list")}</option>
                    {Categories?.map((dept) => (
                      <option key={dept.id} value={dept.id}>
                        {dept.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="gap-2 d-flex align-items-center ">
                  <select
                    onChange={(e) => setSortingType(e.target.value)}
                    className={`${style.filterSelect} rounded-pill`}
                  >
                    <option value="title">{t("OrderBasedON")}</option>
                    {OrderBasedOn.map((option) => (
                      <option key={option.id} value={option.id}>
                        {t(option.label)}
                      </option>
                    ))}
                  </select>
                  <select
                    onChange={(e) => {
                      setSelectedLevel(e.target.value);
                    }}
                    className={`${style.filterSelect} rounded-pill  `}
                  >
                    <option value="">{t("Stage_Level")}</option>
                    <option value="Beginner">{t("Beginners")}</option>
                    <option value="Intermediate">{t("Intermediate")}</option>
                    <option value="Advanced">{t("Advanced")}</option>
                    <option value="All">{t("All")} </option>
                  </select>
                </div>
              </div>

              {/* Courses Grid */}
              <div ref={ref} className={style.coursesGrid}>
                {isLoading ? ( // 3. Update UI render condition
                  <Spinner />
                ) : pupularCourses && pupularCourses.length > 0 ? (
                  <>
                    {pupularCourses.map((course) => (
                      <Link key={course.path} to={`/courses/${course.path}`}>
                        <motion.div
                          initial={{ opacity: 0, x: -100 }}
                          animate={
                            isInView
                              ? { opacity: 1, x: 0 }
                              : { opacity: 0, x: -100 }
                          }
                          transition={{
                            duration: 0.1 * pupularCourses.length,
                            delay: 0.1 * course.path,
                          }}
                          className={`${style.courseCard} d-flex     `}
                        >
                          <div className={`${style.courseImage} col-md-4  `}>
                            <img 
                              src={course.fullThumbnailUrl} 
                              alt={course.title} 
                              onError={(e) => {
                                console.log("Image failed to load, using default");
                                e.target.onerror = null; // Prevent infinite loop
                                e.target.src = DefaultImage;
                              }}
                            />
                          </div>
                          <div className={`${style.courseInfo} col-md-8 `}>
                            <div className={`${style.rating}  `}>
                              <RatingStars rating={course.rate} />
                            </div>
                            <h4>{t(course.title)}</h4>
                            <div
                              dangerouslySetInnerHTML={{ __html: course.description }}
                            ></div>
                            <div className={style.courseStats}>
                              <h5>
                                <span>{course.lessonsCount} </span>{" "}
                                {t("No_Lessons")}
                              </h5>

                              {/* <h5> <span>{course.Students}</span> {t('No_Students')}</h5> */}
                              <h5>{course.audienceLevel} </h5>
                              {/* <h5>{t("State_Course")} </h5> */}
                            </div>
                            <div
                              className={`d-flex align-items-center gap-2 justify-content-between `}
                            >
                 
                              {` ${course.price } EG`} 
                       

                              <Link
                                to={`/courses/${course.path}`}
                                className={`btn ${style.addToCartBtn}  `}
                              >
                                {/* <i className="fas fa-shopping-cart me-2"></i> */}
                                {t("goToCourse")}
                              </Link>
                            </div>
                          </div>
                        </motion.div>
                      </Link>
                    ))}
                    {/* pagination */}
                    <nav aria-label="Page my-3 navigation">
                      <ul className="pagination justify-content-center">
                        <li
                          className={`page-item ${
                            currentPage === 1 ? "disabled" : ""
                          }`}
                        >
                          <Link
                            className={`${style.pageLink} page-link`}
                            onClick={() =>
                              setCurrentPage((prev) => Math.max(prev - 1, 1))
                            }
                            to=""
                          >
                            {t("PreviousNav")}
                          </Link>
                        </li>

                        {[...Array(totalPages)].map((_, idx) => (
                          <li
                            key={idx}
                            className={`page-item ${
                              currentPage === idx + 1 ? style.active : ""
                            }`}
                          >
                            <Link
                              className="page-link"
                              onClick={() => setCurrentPage(idx + 1)}
                              to=""
                            >
                              {idx + 1}
                            </Link>
                          </li>
                        ))}

                        <li
                          className={`page-item ${
                            currentPage >= totalPages ? "disabled" : ""
                          }`}
                        >
                          <Link
                            className="page-link"
                            onClick={() =>
                              setCurrentPage((prev) =>
                                Math.min(prev + 1, totalPages)
                              )
                            }
                            to="#"
                          >
                            {t("NextNav")}
                          </Link>
                        </li>
                      </ul>
                    </nav>
                  </>
                ) : (
                  <div className="container flex-grow-1 d-flex justify-content-center align-items-center flex-column">
                    <h3
                      className={`text-center alert alert-warning no-data w-100`}
                    >
                      {t("courses_not_found")}
                    </h3>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Courses;
