import React, { useContext, useEffect, useState } from "react";
import style from "./InformationCourseContent.module.css";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import ApiManager from "../../Utilies/ApiManager";

import { RatingStars } from "../RatingStars/RatingStars";
import Spinner from "../Ui/Spinner/Spinner";
import { authContext } from "../../Context/authContext";
import Swal from "sweetalert2";
const InformationCourseContent = () => {
  const { courseId } = useParams();
  const { t } = useTranslation();
  const [flagNoData, setFlagNoData] = useState(false);
  const [courseDetailData, setCourseDetailsData] = useState(null);
  const [selectedRating, setSelectedRating] = useState(null);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { token } = useContext(authContext);
  const getCourseDetails = async () => {
    try {
      setFlagNoData(false);
      setCourseDetailsData(null);
      const { data } = await ApiManager.getCourseDetails(courseId);
      if (data.data && data.data.length !== 0) {
        setCourseDetailsData(data.data);
        setFlagNoData(false);
      } else {
        setCourseDetailsData(null);
        setFlagNoData(true);
      }
    } catch (error) {
      setFlagNoData(true);
    }
  };

  useEffect(() => {
    getCourseDetails();
  }, []);

  const handleSubmitRating = async () => {
    if (!selectedRating || !comment.trim()) {
      Swal.fire({
        icon: "warning",
        title: t("MustAddRate"),
        showConfirmButton: true,
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await ApiManager.MakeARate(token, courseId, {
        comment: comment,
        stars: selectedRating,
      });

      // Clear form after successful submission
      setSelectedRating(null);
      setComment("");
      // You may want to show a success message here
      Swal.fire({
        icon: "success",
        title: t("DoneRate"),
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: error?.response?.data?.message,
        showConfirmButton: true,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container ">
      <div className="row">
        <div className="col-lg-7">
          {courseDetailData ? (
            <div className="">
              <h4 className={`${style.titleD} mt-4`}>{t("ContainsCourse")}</h4>
              <div className={`${style.boxShadow}  my-2`}>
                {courseDetailData.lessonsCount} {t("No_Lessons")}
              </div>
              <h4 className={`${style.titleD} mt-4`}>
                {t("breifAboutCourse")}
              </h4>
              <div
                className={`${style.boxShadow}  my-2`}
                dangerouslySetInnerHTML={{
                  __html: courseDetailData.about,
                }}
              ></div>
              <h4 className={`${style.titleD} mt-4`}>{t("detailsCourse")}</h4>
              <div
                className={`${style.boxShadow}  my-2`}
                dangerouslySetInnerHTML={{
                  __html: courseDetailData.details,
                }}
              ></div>
              {courseDetailData?.opens && (
                <>
                  <h4 className={`${style.titleD} mt-4`}>
                    {t("coursesDates")}
                  </h4>
                  <div
                    className={`${style.boxShadow} ${style.coursesDates} d-flex flex-column gap-3  my-2`}
                  >
                    <p>
                      {t("course_opens_date")}:
                      <span className={style.opens}>
                        {courseDetailData.opens}
                      </span>
                    </p>
                    <p>
                      {t("course_closes_date")}:
                      <span className={style.closes}>
                        {courseDetailData.closes}
                      </span>
                    </p>
                    {/* {courseDetailData.contains.replace(/<\/?[^>]+(>|$)/g, "")} */}
                  </div>
                </>
              )}
              <h4 className={`${style.titleD} mt-4`}>{t("courseNotes")}</h4>
              <div
                className={`${style.boxShadow}  my-2`}
                dangerouslySetInnerHTML={{
                  __html: courseDetailData.notes,
                }}
              ></div>
              <h4 className={`${style.titleD} mt-4`}>{t("AboutTrainer")} </h4>
        
              <h4 className={`${style.titleD} mt-4`}>{t("NotesStudents")} </h4>
              <div className={`${style.boxShadow}`}>
                <div className="row ">
                  {courseDetailData && (
                    <div className="col-md-3">
                      <div className="d-flex flex-column align-items-center">
                        <div className={`${style.totalRates} text-center`}>
                          {(() => {
                            const rate = Math.max(
                              0,
                              Math.min(
                                parseFloat(courseDetailData?.rate || 0),
                                5
                              )
                            );
                            const fullStars = Math.max(0, Math.floor(rate));
                            const hasHalfStar = rate % 1 >= 0.5;
                            const emptyStars = Math.max(0, 5 - Math.ceil(rate));

                            return (
                              <>
                                <div className={``}>{rate.toFixed(1)}</div>
                                <div>
                                  {[...Array(fullStars)].map((_, i) => (
                                    <i
                                      key={`full-${i}`}
                                      className="fas fa-star text-warning"
                                    ></i>
                                  ))}
                                  {hasHalfStar && (
                                    <i className="fa-regular fa-star-half-stroke text-warning"></i>
                                  )}
                                  {[...Array(emptyStars)].map((_, i) => (
                                    <i
                                      key={`empty-${i}`}
                                      className="far fa-star text-warning"
                                    ></i>
                                  ))}
                                </div>
                              </>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  )}
                  {courseDetailData.rates && (
                    <div className="col-md-9 ">
                      <div className="mx-2 ">
                        {courseDetailData.rates.map((note, idex) => (
                          <div key={idex} className={`my-2 `}>
                            <div className="d-flex align-items-center my-2  justify-content-between ">
                              {/* Backend Updates */}
                              <div className="d-flex align-items-center gap-2">
                                <img
                                  src={note.accountImageUrl}
                                  className={`${style.smallImage}  `}
                                  alt="image Course"
                                />
                                <p className={`${style.NameStud}`}>
                                  {note.accountName}{" "}
                                </p>
                              </div>
                              <RatingStars rating={note.rateStars} />
                            </div>
                            <p className={`${style.Note} `}>
                              {note.rateComment}{" "}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <h4 className={`${style.titleD} mt-4`}>{t("AddRate")} </h4>
              <div className={`${style.boxShadow} `}>
                <div className={`${style.ratingContainer}`}>
                  <div className="d-flex justify-content-between align-items-center">
                    {[5, 4, 3, 2, 1].map((rating) => (
                      <div key={rating} className={`${style.ratingItem}`}>
                        <div className="d-flex align-items-center gap-2">
                          <span>{rating}</span>
                          <i className="fas fa-star text-warning"></i>
                        </div>
                        <div
                          className={`${style.checkCircle} ${
                            selectedRating === rating ? style.active : ""
                          }`}
                          onClick={() => {
                            setSelectedRating(rating);
                            // You can also call your API here to save the rating
                          }}
                        >
                          {selectedRating === rating && (
                            <i className="fas fa-check"></i>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <h4 className={`${style.titleD} mt-4`}>{t("AddComment")} </h4>

              <div className={`${style.boxShadow}`}>
                <textarea
                  className={style.textarea}
                  placeholder={`${t("AddComment")}`}
                  name="addcoment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                />
              </div>
              <button
                className={`mt-4 ${style.sendRate} rounded-pill`}
                onClick={handleSubmitRating}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <i className="fa-solid fa-spinner text-white fa-spin"></i>
                ) : (
                  t("SendRate")
                )}
              </button>
            </div>
          ) : (
            <>
              {flagNoData ? (
                <div className="container flex-grow-1 d-flex justify-content-center m-3 align-items-center flex-column">
                  <h3 className="text-center alert alert-warning text-dark w-100">
                    {t("CourseDetails_not_found")}
                  </h3>
                </div>
              ) : (
                <Spinner />
              )}
            </>
          )}
        </div>
        <div className="col-lg-5 d-none"></div>
      </div>
    </div>
  );
};

export default InformationCourseContent;
