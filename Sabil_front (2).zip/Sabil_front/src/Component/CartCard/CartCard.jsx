import { motion } from "framer-motion";
import React from "react";
import { useTranslation } from "react-i18next";
import style from "./CartCard.module.css";
import { Link } from "react-router-dom";

export default function CartCard({ item, idx, length, currency, removeItem }) {
  const { t } = useTranslation();
  const getType = (type) => {
    // Item Type:
    // 1: Course
    // 2: OnlineEdu
    // 3: Book
    switch (type) {
      case 1:
        return t("Course");
      case 2:
        return t("OnlineEdu");
      case 3:
        return t("Book");
      default:
        return t("Course");
    }
  };
  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{
        duration: 0.1 * length,
        delay: 0.1 * idx,
      }}
      className={`${style.cartCard} mb-3 d-flex`}
    >
      <div className="col-md-4">
        <img src={item.imageUrl} alt={item.itemName} />
      </div>
      <div className="col-md-8">
        <div className="d-flex p-3 gap-2 flex-wrap flex-md-nowrap">
          <div className="col-md-9 col-sm-12">
            <h3 className={`${style.cartCardTitle} `}>{item.itemName}</h3>
            <p className={`${style.cartCardText} `}>{getType(item.type)}</p>
            <p className={`${style.discountcartCardPrice} `}>
              {item.price} {currency}
            </p>
            {item.priceBefore !== item.price && (
              <p className={`${style.cartCardPrice} `}>
                {item.priceBefore} {currency}
              </p>
            )}
          </div>
          <div className="col-md-3 col-sm-12">
            <div className="d-flex align-items-center justify-content-evenly  gap-4">
              <Link to={item.itemUrl} className={`${style.info} `}>
                <i className="fa-solid fa-share"></i>{" "}
              </Link>
              <span
                onClick={() => removeItem(item.itemId)}
                className={style.delete}
              >
                <i className="fa-solid fa-trash-can"></i>
              </span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
