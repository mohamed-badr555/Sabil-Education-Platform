import React, { useEffect, useRef, useState } from "react";
import style from "./PhoneInput.module.css";
import { motion } from "framer-motion";
import intlTelInput from "intl-tel-input";
import "intl-tel-input/build/css/intlTelInput.css";
import ar from "intl-tel-input/i18n/ar"; // arabic
import en from "intl-tel-input/i18n/en"; // english
import { useTranslation } from "react-i18next";

export default function PhoneInput({
  inputName,
  inputTransition,
  myFormik,
  idx,
  icon,
  initialCountry,
  initialValue,
}) {
  const { t, i18n } = useTranslation();
  const [flagDirection, setFlagDirection] = useState(i18n.language === "ar");
  useEffect(() => {
    setFlagDirection(i18n.language === "ar");
  }, [i18n.language]);
  const [inputValue, setInputValue] = useState(
    initialValue ? initialValue : ""
  );
  const inputRef = useRef();

  useEffect(() => {
    const input = inputRef.current;
    const iti = intlTelInput(input, {
      i18n: flagDirection ? ar : en,
      initialCountry: initialCountry ? initialCountry.toLowerCase() : "eg",
      // separateDialCode: true,

      utilsScript:
        "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
    });

    // Define the change event handler
    const handleInputChange = (e) => {
      // take the phone number with the code from iti
      const phoneNumber = `+${iti.getSelectedCountryData().dialCode} ${
        input.value
      }`;
      // set the value of the input
      setInputValue(e.target.value);
      // set the value of the formik field with the phone number
      myFormik.setFieldValue(inputName, phoneNumber);
    };

    // Attach the event listener
    input.addEventListener("change", handleInputChange);

    // Cleanup
    return () => {
      input.removeEventListener("change", handleInputChange);
      iti.destroy();
    };
  }, [flagDirection, inputName, myFormik]);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 + idx * 0.1 }}
        className={
          style.phoneInputContainer + " mt-1 mb-3  justify-content-start"
        }
        dir={flagDirection ? "rtl" : "ltr"}
        style={{ maxHeight: "65px" }}
      >
        <label
          htmlFor={inputName}
          style={{
            marginRight: "0 10px",
          }}
        >
          <i className={`fa-solid  ${icon}`}></i>
        </label>
        <input
          type="tel"
          className={`form-control  `}
          id={inputName}
          name={inputName}
          defaultValue={inputValue}
          placeholder={t(inputTransition)}
          ref={inputRef}
        />
      </motion.div>

      {myFormik.errors[inputName] && myFormik.touched[inputName] && (
        <div className="px-3 text-danger text-center">
          {myFormik.errors[inputName]}
        </div>
      )}
    </>
  );
}
