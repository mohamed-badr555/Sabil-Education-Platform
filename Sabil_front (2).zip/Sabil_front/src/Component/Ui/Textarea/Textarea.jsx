import React from "react";
import { useTranslation } from "react-i18next";
import style from "./Textarea.module.css";
export default function Textarea({
  myFormik,
  inputName,
  inputTransition,
  icon,
  disabled,
}) {
  const { t } = useTranslation();
  return (
    <div
      className={
        " h-100 overflow-hidden d-flex flex-column px-1 " +
        style.textareaElement
      }
    >
      <label htmlFor={inputName} className="form-label ">
        <i className={`fa-solid ${icon}`}></i>
        {t(inputTransition)}
      </label>
      <textarea
        id={inputName}
        name={inputName}
        onChange={myFormik.handleChange}
        className="form-control flex-grow-1 mb-3"
        placeholder={t(inputTransition)}
        value={myFormik.values[inputName]}
        style={{
          minHeight: "100px",
        }}
      ></textarea>
      {myFormik.errors[inputName] && myFormik.touched[inputName] && (
        <div className="text-center w-100  text-danger">
          {myFormik.errors[inputName]}
        </div>
      )}
    </div>
  );
}
