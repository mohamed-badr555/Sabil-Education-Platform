import { motion } from "framer-motion";
import React, { useState, useEffect } from "react";
import style from "./DatalistElement.module.css";
import { useTranslation } from "react-i18next";

export default function DatalistElement({
  selectName,
  selectTransition,
  icon,
  options,
  myFormik,
  idx,
}) {
  const { t } = useTranslation();
  const [searchValue, setSearchValue] = useState("");
  const [filteredOptions, setFilteredOptions] = useState(options);

  useEffect(() => {
    const currentValue = myFormik.values[selectName];
    if (currentValue) {
      const selectedOption = options.find(
        (option) => option.value === currentValue
      );
      setSearchValue(selectedOption ? t(selectedOption.key) : "");
    } else {
      setSearchValue("");
    }
    setFilteredOptions(options);
  }, [myFormik.values[selectName], options, t]);

  const handleChange = (e) => {
    const inputValue = e.target.value;
    setSearchValue(inputValue);

    const filtered = options.filter((option) => {
      const translatedValue = t(option.key).toLowerCase();
      return translatedValue.includes(inputValue.toLowerCase());
    });

    setFilteredOptions(filtered);
    if (filtered.length === 1) {
      const exactMatch = filtered[0];
      setSearchValue(t(exactMatch.key));
      myFormik.setFieldValue(selectName, exactMatch.value);
    }

    const exactMatch = filtered.find(
      (option) => t(option.key).toLowerCase() === inputValue.toLowerCase()
    );

    if (exactMatch) {
      myFormik.setFieldValue(selectName, exactMatch.value);
    }
  };
  const handleBlur = () => {
    setTimeout(() => {
      const exactMatch = options.find(
        (option) => t(option.key).toLowerCase() === searchValue.toLowerCase()
      );

      if (!exactMatch && searchValue !== "") {
        setSearchValue("");
        myFormik.setFieldValue(selectName, "");
      }
      setFilteredOptions(options);
    }, 200);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.7 + idx * 0.1 }}
        className={style.selectContainer + " mb-3"}
      >
        <label htmlFor={selectName}>
          <i className={`fa-solid ${icon}`}></i>
        </label>
        <div className={style.selectBox}>
          <input
            id={selectName}
            name={selectName}
            list={`${selectName}List`}
            value={searchValue}
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder={t(selectTransition)}
            autoComplete="off"
          />
          <datalist id={`${selectName}List`}>
            {filteredOptions.map((option) => (
              <option key={option.value} value={t(option.key)} />
            ))}
          </datalist>
        </div>
      </motion.div>
      {myFormik.errors[selectName] && myFormik.touched[selectName] && (
        <div className="text-center text-danger">
          {myFormik.errors[selectName]}
        </div>
      )}
    </>
  );
}
