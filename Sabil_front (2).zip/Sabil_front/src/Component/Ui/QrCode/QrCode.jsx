import React, { useState, useEffect } from "react";
import QRCode from "react-qr-code"; // ✅ استيراد المكتبة الصحيحة

const QRCodeComponent = ({ qrData }) => {
  const [size, setSize] = useState(getQrSize());

  function getQrSize() {
    return Math.min(window.innerWidth * 0.5, 300); // يجعل الـ QR Code Responsive
  }

  useEffect(() => {
    const handleResize = () => setSize(getQrSize());
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="text-center">
      <QRCode value={qrData} style={{ width: `${size}px`, height: `${size}px` }} />
    </div>
  );
};

export default QRCodeComponent;
