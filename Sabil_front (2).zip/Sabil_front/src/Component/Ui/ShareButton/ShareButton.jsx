import React, { useEffect, useRef, useState } from "react";
import styles from "./ShareButton.module.css"; // Import CSS module

const ShareButton = ({ buttonText, shareText }) => {
  const encodedShareText = encodeURIComponent(shareText);
  const encodedUrl = encodeURIComponent(window.location.href);
  const [flagOpen, setFlagOpen] = useState(false);
  const shareContainer = useRef(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        shareContainer.current &&
        !shareContainer.current.contains(event.target)
      ) {
        setFlagOpen(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  return (
    <div className={styles.shareButtonContainer}  ref={shareContainer}>
      <button
        className={styles.buttonContent}
        onClick={() => setFlagOpen(!flagOpen)}
      >
        <span className={styles.text}>{buttonText}</span>
        <i
          className={`fas fa-share-alt mx-2 ${styles.shareIcon}`}
          aria-hidden="true"
        ></i>
      </button>
      {flagOpen && (
        <div className={styles.shareButtonContent} >
          <div className={styles.socialIcon}>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedShareText}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Share on Twitter"
            >
              <i className="fab fa-twitter" aria-hidden="true"></i>
            </a>
          </div>
          <div className={styles.socialIcon}>
            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedShareText}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Share on Facebook"
            >
              <i className="fab fa-facebook" aria-hidden="true"></i>
            </a>
          </div>
          <div className={styles.socialIcon}>
            <a
              href={`https://api.whatsapp.com/send?text=${encodedShareText}%20${encodedUrl}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Share on WhatsApp"
            >
              <i className="fab fa-whatsapp" aria-hidden="true"></i>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShareButton;
