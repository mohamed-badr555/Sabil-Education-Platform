import React from "react";
import style from "./SearchInput.module.css";
import i18n from "../../../i18n";

const SearchInput = ({ SearchAbout, setSearch }) => {
  const handleSearch = (e) => {
    setSearch(e.target.value);
  };
  return (
    <section className={` my-4 `}>
      <div className="position-relative">
        <div
          className={`${style.search_icon} ${
            i18n.language === "ar" ? "" : "d-none"
          } p-3`}
        >
          <i className="fa-solid fa-magnifying-glass fa-lg" />
        </div>
        <input
          type="text"
          placeholder={SearchAbout}
          onChange={handleSearch}
          className={`rounded-pill  ${style.search_input}`}
        />
      </div>
    </section>
  );
};

export default SearchInput;
