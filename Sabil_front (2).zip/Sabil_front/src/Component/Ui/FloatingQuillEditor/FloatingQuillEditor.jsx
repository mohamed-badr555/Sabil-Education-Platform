import { useTranslation } from "react-i18next";
import { useEffect, useState } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { motion } from "framer-motion";
import style from "./FloatingQuillEditor.module.css";

export default function FloatingQuillEditor({
  inputName,
  myFormik,
  idx,
  disabled,
  animationFlag = true,
}) {
  const modules = {
    toolbar: [
      [{ header: [1, 2,3,4,5,6, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link"],
      ["clean"],
    ],
  };

  const formats = [
    "header",
    "bold",
    "italic",
    "underline",
    "strike",
    "list",
    "bullet",
    "link",
  ];

  return (
    <>
      <motion.div
        dir="auto"
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{
          duration: animationFlag ? 0.5 : 0,
          delay: animationFlag ? 0.4 + idx * 0.1 : 0,
        }}
        className={"form-floating " + style.floating}
      >
        <ReactQuill
          value={myFormik.values[inputName]}
          onChange={(value) => myFormik.setFieldValue(inputName, value)}
          modules={modules}
          formats={formats}
          readOnly={disabled}
          className={style.quillEditor}
          defaultValue={myFormik.values[inputName]}
          i18nIsDynamicList={true}
        />
      </motion.div>

      {myFormik.errors[inputName] && myFormik.touched[inputName] && (
        <div className="px-3 text-danger text-center">
          {myFormik.errors[inputName]}
        </div>
      )}
    </>
  );
}
