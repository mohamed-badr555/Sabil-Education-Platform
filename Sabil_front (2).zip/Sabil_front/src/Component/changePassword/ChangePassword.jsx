import { useFormik } from 'formik';
import { useState, useContext, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import * as Yup from 'yup';
import { authContext } from '../../Context/authContext';
import ApiManager from '../../Utilies/ApiManager';
import style from './changePassword.module.css'
import FloatingInput from '../Ui/FloatingInput/FloatingInput';
import { motion } from 'framer-motion';

const ChangePassword = () => {
  const { t } = useTranslation();
  const [responseFlag, setResponseFlag] = useState(false);
  const { token } = useContext(authContext);
  const [resMessage, setResMessage] = useState(null);



  const validationSchemaYup = Yup.object().shape({
    currentPassword: Yup.string()
      .required(t("Required")),
    newPassword: Yup.string()
      .min(6, t("Password must contain at least 6 characters"))
      .required(t("Required")),
    confirmPassword: Yup.string()
      .required(t("Required"))
      .oneOf([Yup.ref("newPassword")], t("Passwords must match")),
  });

  const myFormik = useFormik({
    initialValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema: validationSchemaYup,
    onSubmit: async (values) => {
      await updateYourPassword(values);
    },
  });

  const updateYourPassword = async (values) => {
    setResponseFlag(true);
    try {
      let { data } = await ApiManager.updatePassword(
        {
          current: values.currentPassword,
          new: values.newPassword,
        },
        token
      );
      if (data.code === 200) {
        setResMessage({
          flag: true,
          message: t("Password updated successfully"),
        });
        myFormik.resetForm();
      } else {
        setResMessage({
          flag: false,
          message: t("Something went wrong, please try again later"),
        });
      }
    } catch (error) {
      setResMessage({
        flag: false,
        message: error.response?.data?.errors?.[0] || t("Something went wrong, please try again later"),
      });
    }
    setResponseFlag(false);
  };

  const inputs = [
    {
      inputType: "password",
      inputName: "currentPassword",
      inputTransition: "currentPassword",
      icon: "fa-lock",
    },
    {
      inputType: "password",
      inputName: "newPassword",
      inputTransition: "newPassword",
      icon: "fa-lock",
    },
    {
      inputType: "password",
      inputName: "confirmPassword",
      inputTransition: "confirmPassword",
      icon: "fa-lock",
    },
  ];

  return (
    <div>
      <form onSubmit={myFormik.handleSubmit} className="container">
        <h2 className={`${style.Head} mb-3`}>{t("Update Password")}</h2>
        <div className={`${style.cardInfo} mb-3`}>
          <div className="row">
            {inputs.map((input, index) => (
              <div key={index} className="col-md-4">
                <FloatingInput
                  idx={index}
                  {...input}
                  myFormik={myFormik}
                />
              </div>
            ))}
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="col-12 m-auto text-center"
        >
          <button
            type="submit"
            disabled={responseFlag}
            className="btn-web btn-web-primary"
          >
            {responseFlag ? (
              <div className="spinner-border text-light" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              t("updateProfile")
            )}
          </button>

          {resMessage && (
            <div
              className={`my-3 ${
                resMessage.flag ? "text-success" : "text-danger"
              }`}
            >
              {resMessage.message}
            </div>
          )}
        </motion.div>
      </form>
    </div>
  );
};

export default ChangePassword;