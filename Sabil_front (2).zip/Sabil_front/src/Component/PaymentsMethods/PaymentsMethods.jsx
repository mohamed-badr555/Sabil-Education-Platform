import React, { useEffect, useState } from "react";
import style from "./PaymentsMethods.module.css";
import { motion } from "framer-motion";
import ApiManager from "../../Utilies/ApiManager";
import { useTranslation } from "react-i18next";
import Swal from "sweetalert2";
import Spinner from "../Ui/Spinner/Spinner";
import QRCodeComponent from "../Ui/QrCode/QrCode";
import { Navigate } from "react-router-dom";

export default function PaymentsMethods({ hidePayments, cartId, token }) {
  const [paymentMethods, setPaymentMethods] = useState(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [paymentId, setPaymentId] = useState(2);
  const [fawryCodeObject, setFawryCodeObject] = useState();
  const [qrCodeObject, setQrCodeObject] = useState(null);
  const [loading, setLoading] = useState(false);
  const { t, i18n } = useTranslation();
  const getPayments = async () => {
    try {
      const { data } = await ApiManager.getPaymentMethods();
      if ((data.code = 200)) {
        setPaymentMethods(data.data);
      } else {
      }
    } catch (error) {}
  };
  useEffect(() => {
    getPayments();
  }, []);

  // request body
  //   {
  //     "Language": "AR", // AR or EN
  //     "PaymentMethodId": 2,
  //     "CartId": "76505dc9-9a1c-4072-8c6b-92dc465fd5db",
  //     "EWalletPhone": "01140167118" // required if user choosed EWallet
  // }

  const handlePayment = async (paymentMethodId) => {
    setLoading(true);
    if (cartId) {
      const data = {
        Language: i18n.language === "ar" ? "AR" : "EN",
        CartId: cartId,
      };

      switch (paymentMethodId) {
        case 2:
          data.PaymentMethodId = 2;
          // Visa-Mastercard
          await payWithVisa(data);
          break;
        case 3 || 4:
          data.PaymentMethodId = paymentMethodId;
          // Fawry Or MobileWallets
          if (!validatePhoneNumber(phoneNumber)) return;
          data.EWalletPhone = phoneNumber;
          await payWithFawryOrWallet(data);
          break;
        default:
          break;
      }
    }
  };
  const validatePhoneNumber = (phoneNumber) => {
    if (phoneNumber.trim() == "" && isNaN(Number(phoneNumber))) {
      Swal.fire({
        icon: "error",
        title: t("Error"),
        text: t("error.please_enter_your_phone_number"),
      });
      setLoading(false);
      return false;
    } else if (!phoneNumber.match(/^01[0125][0-9]{8}$/)) {
      Swal.fire({
        icon: "error",
        title: t("Error"),
        text: t("error.please_enter_a_valid_phone_number"),
      });
      setLoading(false);
      return false;
    }
    return true;
  };
  const payWithVisa = async (dataObject) => {
    const data = await createOrder(dataObject);

    if (data.redirectTo && data.redirectTo !== "") {
      window.open(data.redirectTo, "_blank");
      hidePayments();
    } else {
      Swal.fire({
        icon: "error",
        title: t("Error"),
        text: t("Something went wrong, please try again later"),
      });
    }
  };
  const payWithFawryOrWallet = async (dataObject) => {
    const data = await createOrder(dataObject);
    if (paymentId == 3) {
      setFawryCodeObject(data);
    } else if (paymentId == 4) {
      setQrCodeObject(data);
    }
  };

  const createOrder = async (dataObject) => {
    try {
      const { data } = await ApiManager.createPayment(dataObject, token);
      if (data.code == 200) {
        return data.data;
      } else if (data.code == 205) {
        <Navigate to="/profile/myTransactions" />;
      } else failPayment(data.code);
    } catch (error) {
      failPayment(error.response.data.code);
    }
  };

  const failPayment = (errorCode) => {
    let message = "";

    switch (errorCode) {
      case 401:
        message = t("error.unauthorized");
        break;
      case 400:
        message = t("error.general");
        break;
      case 404:
        message = t("error.invalid_item_id");
        break;
      case 420:
        message = t("error.empty_cart");
        break;
      case 421:
        message = t("error.invalid_payment_method_id");
        break;
      case 422:
        message = t("error.expired_coupon");
        break;
      case 423:
        message = t("error.invalid_coupon");
        break;
      case 424:
        message = t("error.wallet_required");
        break;

      default:
        message = t("error.unknown");
        break;
    }

    Swal.fire({
      icon: "error",
      title: t("error.title"),
      text: message,
    });
    setLoading(false);
  };

  useEffect(() => {
    if (paymentMethods && paymentMethods.length == 1) {
      handlePayment(paymentMethods[0].paymentId);
    }
  }, [paymentMethods]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 1,
        delay: 0.3,
      }}
      className={style.PaymentsMethods}
    >
      {paymentMethods ? (
        <div className="container">
          <div className="row g-3">
            <div className=" col-md-12 d-flex justify-content-around ">
              {!(fawryCodeObject || qrCodeObject) &&
                paymentMethods.map((payment, idx) => (
                  <div
                    key={idx}
                    className={style.payment + " mb-3 border border-warning"}
                    onClick={() => {
                      setPaymentId(payment.paymentId);
                      setPhoneNumber("");
                    }}
                  >
                    <img src={payment.logo} alt={payment.nameEn} />
                  </div>
                ))}
            </div>
            <div className={"col-md-12 " + style.PaymentsMethods_container}>
              <div className=" d-flex gap-3 flex-column align-items-center">
                <img
                  src={
                    paymentMethods.filter(
                      (payment) => payment.paymentId === paymentId
                    )[0].logo
                  }
                  alt={
                    paymentMethods.filter(
                      (payment) => payment.paymentId === paymentId
                    )[0].nameEn
                  }
                  style={{ width: "100px" }}
                />
                <h4 className={"mb-0 "}>
                  {
                    paymentMethods.filter(
                      (payment) => payment.paymentId === paymentId
                    )[0][`name${i18n.language == "ar" ? "Ar" : "En"}`]
                  }
                </h4>
              </div>
              {
                <RenderFawryAndWallet
                  paymentId={paymentId}
                  phoneNumber={phoneNumber}
                  setPhoneNumber={setPhoneNumber}
                  fawryCodeObject={fawryCodeObject}
                  qrCodeObject={qrCodeObject}
                  handlePayment={handlePayment}
                  loading={loading}
                />
              }
            </div>
          </div>
        </div>
      ) : (
        <Spinner />
      )}
      <button
        className={style.hidePayments + " btn btn-danger text-white "}
        onClick={() => {
          hidePayments(false);
        }}
      >
        <i className="fa-x fa-solid"></i>
      </button>
    </motion.div>
  );
}
const RenderFawryAndWallet = ({
  paymentId,
  phoneNumber,
  setPhoneNumber,
  fawryCodeObject,
  qrCodeObject,
  handlePayment,
  loading,
}) => {
  const { t, i18n } = useTranslation();
  let jsxElement = null;
  if (paymentId == 3 || paymentId == 4) {
    jsxElement = (
      <>
        <input
          type="tel"
          dir={i18n.language == "ar" ? "rtl" : "ltr"}
          className="form-control w-75"
          value={phoneNumber}
          placeholder={t("Phone Number")}
          onChange={(e) => setPhoneNumber(e.target.value)}
        />
      </>
    );
  }

  return (
    <>
      {fawryCodeObject || qrCodeObject ? (
        qrCodeObject ? (
          <>
            <QRCodeComponent qrData={qrCodeObject.meezaQrCode} />

            <p className="text-center text-info-emphasis">
              {t("message will be sent to your phoneNumber with Details")}
            </p>
          </>
        ) : (
          <div className="d-flex flex-column align-items-center">
            <p className={"mb-0 " + style.fwaryCode}>
              {fawryCodeObject.fawryCode}
            </p>
            <p className="my-2 text-bg-warning rounded-2 p-1">
              {t("expiry date") +
                " " +
                new Date(fawryCodeObject.expireDate).toLocaleDateString()}
            </p>
            <p className="text-center text-info-emphasis">
              {t("Please_pay_this_code_to_pay")}
            </p>
          </div>
        )
      ) : (
        <>
          {jsxElement}
          <button
            className="btn-web btn-web-primary"
            onClick={() => handlePayment(paymentId)}
            disabled={loading}
          >
            <i className={loading && "fa-solid fa-spinner fa-spin"}>
              {!loading && t("Pay_now")}
            </i>
          </button>
        </>
      )}
    </>
  );
};
