import React, { lazy, useContext, useEffect, useState } from "react";
import style from "./CourseDetails.module.css";
import { useNavigate, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { RatingStars } from "./../RatingStars/RatingStars";
import { Link } from "react-router-dom";
import CustomPlayer from "../CustomPlayer/CustomPlayer";

// import { AllCourses, CourseNotes } from '../../Utilies/data';
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../Ui/Spinner/Spinner";
import { authContext } from "../../Context/authContext";
import { basketContext } from "../../Context/basketContext";
import { websiteURL } from "../../Utilies/data";
import ShareButton from "../Ui/ShareButton/ShareButton";
import { Helmet } from "react-helmet-async";
const MainSwiper = lazy(() => import("../../Component/MainSwip/MainSwiper"));
const CourseTeacherCard = lazy(() =>
  import("../../Component/CourseTeacherCard/CourseTeacherCard")
);
const CourseDetails = () => {
  const { courseId } = useParams();
  const { t } = useTranslation();
  const [flagNoData, setFlagNoData] = useState(false);
  const [courseDetailData, setCourseDetailsData] = useState(null);
  const { token } = useContext(authContext);
  const [realPrice, setRealPrice] = useState(0);
  const navigate = useNavigate();
  const getCourseDetails = async () => {
    try {
      setFlagNoData(false);
      setCourseDetailsData(null);
      const { data } = await ApiManager.getCourseDetails(courseId, token);
      if (data.data && data.data.length !== 0) {
        setCourseDetailsData(data.data);
        if (data.data.discount) {
          setRealPrice(
            data.data.price - (data.data.price * data.data.discount) / 100
          );
        } else {
          setRealPrice(data.data.price);
        }
        setFlagNoData(false);
      } else {
        setCourseDetailsData(null);
        setFlagNoData(true);
      }
    } catch (error) {
      setFlagNoData(true);
    }
  };
  const [metaData, setMetaData] = useState(null);

  useEffect(() => {
    if (courseDetailData && courseDetailData.title) {
      setMetaData({
        title: courseDetailData.title,
        description:
          "انضم إلى الدورة الآن وتعلم من أفضل المحاضرين على منصة حصون التعليمية!",
        image: window.location.origin + courseDetailData.thumbnail,
        url: window.location.origin + "/courses/" + courseDetailData.path,
      });
    }
  }, [courseDetailData]);
  useEffect(() => {
    getCourseDetails();
  }, []);

  const { addBasketItem, containInBasket, buyFreeItem } =
    useContext(basketContext);

  const createItemToCart = () => {
    const item = {
      itemId: courseDetailData.path,
      itemUrl: `${websiteURL}courses/${courseDetailData.path}`,
      itemName: courseDetailData.title,
      imageUrl: courseDetailData.thumbnail,
      price: realPrice,
      quantity: 1,
      type: 1,
    };
    return item;
  };

  const addToBasket = () => {
    const item = createItemToCart();
    addBasketItem(item);
    navigate("/cart");
  };
  const buyNow = async () => {
    if (realPrice === 0) {
      await buyFreeItem(token, 1, courseDetailData.path, navigate);
      await getCourseDetails();
    } else {
      addToBasket();
    }
  };

  return (
    <>
      {metaData && (
        <Helmet>
          <meta property="og:title" content={metaData.title} />
          <meta property="og:description" content={metaData.description} />
          <meta property="og:image" content={metaData.image} />
          <meta property="og:url" content={metaData.url} />
          <meta property="og:type" content="website" />
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:title" content={metaData.title} />
          <meta name="twitter:description" content={metaData.description} />
          <meta name="twitter:image" content={metaData.image} />
          <meta name="twitter:url" content={metaData.url} />
        </Helmet>
      )}
      <section className=" position-relative">
        {courseDetailData ? (
          <div className="">
            {/* Header */}
            <div className={`${style.BGheadr}  `}>
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="container"
              >
                <h2 className={style.main_head_title}>
                  {courseDetailData.title}
                </h2>

                <div className="d-flex align-items-center my-3 flex-nowrap  column-gap-5">
                  <RatingStars rating={courseDetailData.rate} />
                  {/* <p className={`text-white `}>{t(  "No_Students")}</p> */}
                </div>
                <div className={`my-3 ${style.ShowHideDetails}`}>
                  <img src={courseDetailData.thumbnail} alt="image Course" />
                  <div className="d-flex align-items-center  flex-wrap my-3">
                    {courseDetailData.tags.map((tag, index) => (
                      <span key={index} className={`${style.tag} m-2`}>
                        <i className="fa-solid mx-1 fa-tags"></i> {tag}
                      </span>
                    ))}
                  </div>
                  <p className={"text-white my-2 fs-5 fw-bold "}>
                    {realPrice == 0 ? (
                      <span className={style.free}>{t("free")}</span>
                    ) : (
                      `${realPrice} ${courseDetailData.currency}`
                    )}
                  </p>
                  <p className={`${style.whiteColor} my-2`}>
                    {t("CratedBy")}{" "}
                    <span className={`${style.bold}`}>
                      {`${courseDetailData.trainer.firstName} ${courseDetailData.trainer.lastName} `}
                    </span>
                  </p>
                  <p className={`${style.whiteColor}`}>
                    {t("LastUpdate")}{" "}
                    <span className={`${style.bold}`}>
                      {courseDetailData.lastUpdate.split("T")[0]}
                    </span>
                  </p>
                  {courseDetailData.isRegistered == true ? (
                    <Link
                      to={`/courses/${courseId}/content`}
                      className={`my-2 ${style.btnEnroll} `}
                    >
                      {t("gotoCourse")}
                    </Link>
                  ) : (
                    <button
                      className={`my-2 ${style.btnEnroll} `}
                      onClick={buyNow}
                      disabled={containInBasket(courseDetailData.path)}
                    >
                      {containInBasket(courseDetailData.path)
                        ? t("AddedToBasket")
                        : t("EnrollNow")}
                    </button>
                  )}
                </div>

                <div className=" d-flex align-items-center column-gap-5  flex-nowrap">
                  <ShareButton
                    buttonText={t("Share")}
                    shareText={`
                    📚✨ هل تبحث عن دورة مميزة لتطوير مهاراتك؟ انضم إلى دورة ${courseDetailData.title} على منصة حصون التعليمية وتعلم من أفضل المحاضرين! لا تفوّت الفرصة وسجّل الآن! 🔗👇`}
                  />
                  {/* <div className={`d-flex align-items-center gap-2 flex-nowrap ${style.icons}`}>
        <i className="fa-regular  fa-heart" ></i>
        <p className={`text-white `}>{t("AddToFavorite") }</p>
        </div>
        <div className={`d-flex align-items-center gap-2 flex-nowrap ${style.icons}`}>
        <i className="fa-regular fa-flag" ></i>
        <p className={`text-white `}>{t("MakeReport") }</p>
        </div> */}
                </div>
              </motion.div>
            </div>
            {/* Body */}
            <div className={`container   `}>
              <div className="my-5 ">
                <div className="w-100 row   ">
                  <div className="col-lg-7">
                    <div className={`${style.CourseDetails}`}>
                      <h4 className={`${style.titleD}`}>{t("InterVideo")} </h4>
                      {/* Inter Video here */}

                      <CustomPlayer
                        videoId={courseDetailData?.introVideo}
                        onReady={() => console.log("Video ready")}
                        onEnded={() => console.log("Video ended")}
                      />
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("ContainsCourse")}
                      </h4>
                      <div className={`${style.boxShadow}  my-2`}>
                        {courseDetailData.lessonsCount} {t("No_Lessons")}
                      </div>
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("breifAboutCourse")}
                      </h4>
                      <div
                        className={`${style.boxShadow}  my-2`}
                        dangerouslySetInnerHTML={{
                          __html: courseDetailData.about,
                        }}
                      ></div>
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("detailsCourse")}
                      </h4>
                      <div
                        className={`${style.boxShadow}  my-2`}
                        dangerouslySetInnerHTML={{
                          __html: courseDetailData.details,
                        }}
                      ></div>
                      {courseDetailData?.opens && (
                        <>
                          <h4 className={`${style.titleD} mt-4`}>
                            {t("coursesDates")}
                          </h4>
                          <div
                            className={`${style.boxShadow} ${style.coursesDates} d-flex flex-column gap-3  my-2`}
                          >
                            <p>
                              {t("course_opens_date")}:
                              <span className={style.opens}>
                                {courseDetailData.opens}
                              </span>
                            </p>
                            <p>
                              {t("course_closes_date")}:
                              <span className={style.closes}>
                                {courseDetailData.closes}
                              </span>
                            </p>
                            {/* {courseDetailData.contains.replace(/<\/?[^>]+(>|$)/g, "")} */}
                          </div>
                        </>
                      )}
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("courseNotes")}
                      </h4>
                      <div
                        className={`${style.boxShadow}  my-2`}
                        dangerouslySetInnerHTML={{
                          __html: courseDetailData.notes,
                        }}
                      ></div>
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("AboutTrainer")}
                      </h4>
                  
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("NotesStudents")}
                      </h4>
                      <div className={`${style.boxShadow}`}>
                        <div className="row ">
                          {courseDetailData && (
                            <div className="col-md-3">
                              <div className="d-flex flex-column align-items-center">
                                <div
                                  className={`${style.totalRates} text-center`}
                                >
                                  {(() => {
                                    const rate = Math.max(
                                      0,
                                      Math.min(
                                        parseFloat(courseDetailData?.rate || 0),
                                        5
                                      )
                                    );
                                    const fullStars = Math.max(
                                      0,
                                      Math.floor(rate)
                                    );
                                    const hasHalfStar = rate % 1 >= 0.5;
                                    const emptyStars = Math.max(
                                      0,
                                      5 - Math.ceil(rate)
                                    );

                                    return (
                                      <>
                                        <div className={``}>
                                          {rate.toFixed(1)}
                                        </div>
                                        <div>
                                          {[...Array(fullStars)].map((_, i) => (
                                            <i
                                              key={`full-${i}`}
                                              className="fas fa-star text-warning"
                                            ></i>
                                          ))}
                                          {hasHalfStar && (
                                            <i className="fa-regular fa-star-half-stroke text-warning"></i>
                                          )}
                                          {[...Array(emptyStars)].map(
                                            (_, i) => (
                                              <i
                                                key={`empty-${i}`}
                                                className="far fa-star text-warning"
                                              ></i>
                                            )
                                          )}
                                        </div>
                                      </>
                                    );
                                  })()}
                                </div>
                              </div>
                            </div>
                          )}
                          {courseDetailData.rates && (
                            <div className="col-md-9 ">
                              <div className="mx-2 ">
                                {courseDetailData.rates.map((note, idex) => (
                                  <div key={idex} className={`my-2 `}>
                                    <div className="d-flex align-items-center my-2  justify-content-between ">
                                      {/* Backend Updates */}
                                      <div className="d-flex align-items-center gap-2">
                                        <img
                                          src={note.accountImageUrl}
                                          className={`${style.smallImage}  `}
                                          alt="image Course"
                                        />
                                        <p className={`${style.NameStud}`}>
                                          {note.accountName}
                                        </p>
                                      </div>
                                      <RatingStars rating={note.rateStars} />
                                    </div>
                                    <p className={`${style.comment} `}>
                                      {note.rateComment}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-5 d-none    d-lg-block">
                    <div className="d-flex justify-content-center  me-5 align-items-center">
                      <div className={`${style.AbsoluteLayout}`}>
                        <img
                          src={courseDetailData.thumbnail}
                          alt="image Course"
                        />
                        <div className="d-flex align-items-center gap-1 flex-wrap my-3">
                          {courseDetailData.tags.map((tag, index) => (
                            <span key={index} className={`${style.tagAbs}`}>
                              <i className="fa-solid mx-1 fa-tags"></i> {tag}
                            </span>
                          ))}
                        </div>

                        {realPrice == 0 ? (
                          <p className="fs-5 fw-bold text-white">
                            <span className={style.free}>{t("free")}</span>
                          </p>
                        ) : (
                          <p className={`${style.PriceAbs} my-2`}>
                            {courseDetailData.discount == 0 ? (
                              <span>{realPrice}</span>
                            ) : (
                              <>
                                <span className={style.discount}>
                                  {courseDetailData.price}{" "}
                                </span>
                                <span>{realPrice}</span>
                              </>
                            )}
                            {courseDetailData.currency}
                          </p>
                        )}

                        <p className={`${style.whiteColorAbs} my-2`}>
                          {t("CratedBy")}{" "}
                          <span className={`${style.boldAbs}`}>
                            {`${courseDetailData.trainer.firstName} ${courseDetailData.trainer.lastName} `}
                          </span>
                        </p>
                        <p className={`${style.whiteColorAbs}`}>
                          {t("LastUpdate")}{" "}
                          <span className={`${style.boldAbs}`}>
                            {courseDetailData.lastUpdate.split("T")[0]}
                          </span>
                        </p>

                        {courseDetailData.isRegistered ? (
                          <Link
                            to={`/courses/${courseId}/content`}
                            className={`my-2 ${style.btnEnrollAbs} `}
                          >
                            {t("gotoCourse")}
                          </Link>
                        ) : (
                          <button
                            className={`my-2 ${style.btnEnrollAbs} `}
                            onClick={buyNow}
                            disabled={containInBasket(courseDetailData.path)}
                          >
                            {containInBasket(courseDetailData.path)
                              ? t("AddedToBasket")
                              : t("EnrollNow")}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                {courseDetailData.relatedCourses &&
                  courseDetailData.relatedCourses.length > 0 && (
                    <>
                      <h4 className={`${style.titleD} mt-4`}>
                        {t("NewCoureses")}{" "}
                      </h4>
                      <div className="mainSwoper">
                        <MainSwiper
                          data={courseDetailData.relatedCourses}
                          Card={CourseTeacherCard}
                        />
                      </div>
                    </>
                  )}
              </div>
            </div>
          </div>
        ) : (
          <>
            {flagNoData ? (
              <div className="container flex-grow-1 d-flex justify-content-center m-3 align-items-center flex-column">
                <h3 className="text-center alert alert-warning text-dark w-100">
                  {t("CourseDetails_not_found")}
                </h3>
              </div>
            ) : (
              <Spinner />
            )}
          </>
        )}
      </section>
    </>
  );
};

export default CourseDetails;
