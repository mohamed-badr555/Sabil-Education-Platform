import React, { useContext, useEffect, useState } from "react";
import style from "./CourseContent.module.css";
import { useTranslation } from "react-i18next";
import { Outlet, useNavigate, useParams } from "react-router-dom";
import { authContext } from "../../Context/authContext";
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../Ui/Spinner/Spinner";
import SubLinkNavigator from "../Ui/SubLinkNavigator/SubLinkNavigator";
const CourseContent = () => {
  const { courseId } = useParams();
  const { t } = useTranslation();
  let navigate = useNavigate();
  const { token } = useContext(authContext);
  const [courseData, setCourseData] = useState(null);
  const [flagNoData, setNoData] = useState(false);

  const getContentCourse = async () => {
    try {
      setNoData(false);
      setCourseData(null);
      let { data } = await ApiManager.GetContentCourse(token, courseId);
      if (data.data && data.data.length !== 0) {
        setCourseData(data.data);
        setNoData(false);
      } else {
        setCourseData(null);
        setNoData(true);
      }
    } catch (error) {
      console.error("Error fetching course content:", error);
      setNoData(true);
    }
  };
  useEffect(() => {
    getContentCourse();
  }, []);

  const links = [
    {
      title: t("informationCourse"),
      to: `/courses/${courseId}/content/courseinformation`,
      active: `/courses/${courseId}/content/courseinformation`,
    },
    {
      title: t("ContentCourse"),
      to: `/courses/${courseId}/content`,
      active: `/courses/${courseId}/content`,
    },
  ];

  return (
    <section>
      {courseData ? (
        <>
          <div className={style.BGheader}>
            <div className="container">
              <div className="row align-items-center">
                {/* Course Image */}
                <div className="col-lg-4 col-md-5 mb-3 mb-md-0">
                  <div className={style.imageWrapper}>
                    <img
                      src={courseData.thumbnail}
                      className={style.DefaultImage}
                      alt="Course"
                    />
                  </div>
                </div>

                {/* Course Details */}
                <div className="col-lg-8 col-md-7">
                  <div className={style.courseInfo}>
                    <h2 className={style.courseTitle}> {courseData.title} </h2>

                    <div className={style.courseStats}>
                      <div className={style.statItem}>
                        <span className={style.statLabel}>
                          {t("CratedBy")}{" "}
                        </span>
                        <span className={style.statValue}>
                          {courseData.teacher}{" "}
                        </span>
                      </div>
                      <div className={style.statItem}>
                        <span className={style.statLabel}>
                          {t("StudentsRegisters")}:
                        </span>
                        <span className={style.statValue}>
                          {courseData.studentsCount}
                        </span>
                      </div>
                    </div>

                    <div
                      className={style.courseDescription}
                      dangerouslySetInnerHTML={{
                        __html: courseData.description,
                      }}
                    ></div>

                    <div className={style.progressSection}>
                      <div className={style.progressBar}>
                        <div
                          className={style.progressFill}
                          style={{ width: `${courseData.progress}%` }}
                        ></div>
                      </div>
                      <div
                        className={
                          courseData.progress != 100
                            ? "text-white"
                            : style.fullTop
                        }
                      >
                        <i className="fa-solid fa-2x fa-trophy"></i>
                      </div>
                    </div>

                    <button
                      className={style.detailsButton}
                      onClick={() => navigate(`/courses/${courseId}`)}
                    >
                      {t("DetailsCourse")}
                      <i className="fa-solid fa-chevron-left"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container my-5">
            <SubLinkNavigator options={links} />

            <Outlet
              context={{
                lastAccessedVideoId: courseData.lastAccessedVideoId,
                units: courseData.units,
                updateCourseData: getContentCourse,
                finalExamId: courseData.finalExamId,
              }}
            />
          </div>
        </>
      ) : (
        <>
          {flagNoData ? (
            <div className="container flex-grow-1 d-flex justify-content-center my-2 align-items-center flex-column">
              <h3 className="text-center alert alert-warning text-dark w-100">
                {t("NotEnrolled")}
              </h3>
            </div>
          ) : (
            <Spinner />
          )}{" "}
        </>
      )}
    </section>
  );
};

export default CourseContent;
