import { motion } from "framer-motion";
import style from "./Heading.module.css";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useContext } from "react";
import { authContext } from "../../Context/authContext";

export default function Heading({ text, title }) {
  const { t } = useTranslation();
  const { onlineUser } = useContext(authContext);
  return (
    <div className={style.mainHead}>
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className={`container `}
      >
        <div className="d-flex py-md-4  py-2 gap-1  text-center justify-content-between ">
          <div className="d-flex flex-column   p-2  justify-content-between  gap-5   ">
            {onlineUser && (
              <>
                <p className={style.StName}>{onlineUser?.name}</p>
                <p className={style.studentInfo}>{`${t("Total_degree")}: ${
0                } ${t("Point")}`}</p>
              </>
            )}
          </div>

          <div className="d-flex flex-column justify-content-center">
            <h2 className={style.main_head_title}>{title}</h2>
            {text && <p className={style.main_head_text}>{text}</p>}
          </div>

          <div className="d-flex flex-column  gap-5  p-1 justify-content-between">
            {onlineUser && (
              <>
                <Link to="/onlineEdu/student/MyLessons" className={style.links}>
                  {t("MyCourses")}
                </Link>
                <Link to="/onlineEdu/student/MyDate" className={style.links}>
                  {t("MySchedule")}
                </Link>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
