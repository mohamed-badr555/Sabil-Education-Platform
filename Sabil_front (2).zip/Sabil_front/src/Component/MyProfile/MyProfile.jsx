import { useTranslation } from "react-i18next";
import Heading from "../Heading/Heading";
import { Outlet } from "react-router-dom";
import SubLinkNavigator from "../Ui/SubLinkNavigator/SubLinkNavigator";

const MyProfile = () => {
  const { t } = useTranslation();


  const ProfileOptions = [
    {
      title: t("PersonalInformation"),
      active: "/profile",
      to: "/profile",
    },
    {
      title: t("changeEmail"),
      active: "/profile/changeEmail",
      to: "/profile/changeEmail",
    },
    {
      title: t("changePassword"),
      active: "/profile/changePassword",
      to: "/profile/changePassword",
    },
  ];
  return (
    <div>
      <Heading title={t("MyProfile")} />
      <div className="container my-5 ">
        <SubLinkNavigator options={ProfileOptions} />
        <div className="">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default MyProfile;
