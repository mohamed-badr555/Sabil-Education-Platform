import { useTranslation } from "react-i18next";
import style from "./changeEmail.module.css";
import { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { authContext } from "../../Context/authContext";
import * as Yup from "yup";
import ApiManager from "../../Utilies/ApiManager";
import Swal from "sweetalert2";
import { useFormik } from "formik";
import FloatingInput from "../Ui/FloatingInput/FloatingInput";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
const ChangeEmail = () => {
  const { t, i18n } = useTranslation();
  const [responseFlag, setResponseFlag] = useState(false);
  const { user, token } = useContext(authContext);
  const [resMessage, setResMessage] = useState(null);
  let navigator = useNavigate();

  useEffect(() => {
    
    if (user?.email) {
      myFormik.setFieldValue("oldEmail", user.email);
    }
  }, [user]);

  const validationSchemaYup = Yup.object().shape({
    oldEmail: Yup.string()
      .email(t("Invalid email address"))
      .required(t("Required")),
    newEmail: Yup.string()
      .email(t("Invalid email address"))
      .required(t("Required"))
      .notOneOf(
        [Yup.ref("oldEmail")],
        t("New email must be different from old email")
      ),
  });

  const myFormik = useFormik({
    initialValues: {
      oldEmail: user?.email || "",
      newEmail: "",
    },
    validationSchema: validationSchemaYup,
    onSubmit: async (values) => {
      if (values.oldEmail !== user?.email) {
        Swal.fire({
          icon: "error",
          title: t("Old email doesn't match your current email"),
        });
        return;
      }
      await sendEmail(values.newEmail);
    },
  });

  const sendEmail = async (email) => {
    setResponseFlag(true);
    try {
      let { data } = await ApiManager.updateEmail(email, token);
      if (data.code === 200) {
        setResMessage({
          flag: true,
          message: t("You need to verify your email"),
        });
        setTimeout(() => {
          navigator("/EmailConfirmOtp", { state: { token: token } });
        }, 2000);
      } else {
        setResMessage({ flag: false, message: data.errors[0] });
      }
    } catch (error) {
      let { data } = error.response;
      if (data.code == 400) {
        setResMessage({ flag: false, message: data.errors[0] });
      } else
        setResMessage({
          flag: false,
          message: t("Something went wrong, please try again later"),
        });
    }
    setResponseFlag(false);
  };

  const inputs = [
    {
      inputType: "email",
      inputName: "oldEmail",
      inputTransition: "oldEmail",
      icon: "fa-envelope",
      disabled: true,
    },
    {
      inputType: "email",
      inputName: "newEmail",
      inputTransition: "newEmail",
      icon: "fa-envelope",
    },
  ];

  return (
    <div>
      <form onSubmit={myFormik.handleSubmit} className="container">
        <h2 className={`${style.Head} mb-3`}>{t("Update Email")}</h2>
        <div className={`${style.cardInfo} mb-3 `}>
          <div className="row">
            {inputs.map((input, index) => (
              <div key={index} className="col-md-6  ">
                <FloatingInput idx={index} {...input} myFormik={myFormik} />
              </div>
            ))}
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="col-12 m-auto text-center"
        >
          <button
            type="submit"
            disabled={responseFlag}
            className="btn-web btn-web-primary"
          >
            {responseFlag ? (
              <div className="spinner-border text-light" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              t("updateProfile")
            )}
          </button>

          {resMessage && (
            <div
              className={`my-3 ${
                resMessage.flag ? "text-success" : "text-danger"
              }`}
            >
              {resMessage.message}
            </div>
          )}

          {user && !user?.isVerified && (
            <p className="text-center my-2 text-danger">
              {t("You need to verify your email it ")}
              <Link
                to="/EmailConfirmOtp"
                state={{ token: token }}
                onClick={async () => {
                  await ApiManager.sendOtp(token);
                }}
              >
                {t("Verify Email Now")}
              </Link>
            </p>
          )}
        </motion.div>
      </form>
    </div>
  );
};

export default ChangeEmail;
