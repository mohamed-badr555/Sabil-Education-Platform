import React, { useContext, useEffect, useState } from "react";
import logo from "../../assets/Images/icon.png";
import style from "./Footer.module.css";
import { useTranslation } from "react-i18next";
import { HomeContentContext } from "../../Context/homeContentContext.jsx";
import { IsMobileContext } from "../../Context/isMobileContext.jsx";
import { Link } from "react-router-dom";
import Spinner from "../Ui/Spinner/Spinner.jsx";
const Footer = () => {
  const { t } = useTranslation();
  const [socialMediaLinks, setSocialMediaLinks] = useState(null);
  const { homeContent, isLoading } = useContext(HomeContentContext);
  const { isMobile } = useContext(IsMobileContext);
  useEffect(() => {
    if (homeContent != undefined) {
      setSocialMediaLinks(homeContent?.homeInfo?.socialMediaLinks);
    }
  }, [homeContent]);

  return (
    <footer className={`${style.footers}`} id="footer">
      {!isLoading ? (
        <div className="overflow-hidden p-5 ">
          <div
            className={` d-flex text-center gap-4 justify-content-between flex-column    `}
          >
            {/* <div className="image">
              <img src={logo} alt="logo" />
            </div> */}
            <div
              className={` d-flex flex-row gap-4 flex-wrap justify-content-center align-items-center`}
            >
              {/* {SocialMedia.map((item, idx) => (
              <div key={idx} className={`${style.cricle}`}>
                <Link to={item.link}>{item.icon}</Link>
              </div>
            ))} */}
              {socialMediaLinks &&
                Object.keys(socialMediaLinks).map((soMedi, idx) => (
                  <div key={idx} className={`${style.socialMedia}`}>
                    <a href={socialMediaLinks[soMedi]} target="_blank">
                      <i
                        className={`fa-brands fa-xl fa-${soMedi.toLowerCase()}`}
                      ></i>
                    </a>
                  </div>
                ))}
            </div>
            <div
              className={
                "d-flex justify-content-center align-items-center " +
                style.validateCertificate
              }
            >
              {/* <Link className="fs-4" to="Validate-Certificates">
                <i className="fa-solid fa-certificate mx-2"></i>
                {t("ValidateCertificates")}
              </Link> */}
            </div>{" "}
            <div className={`${style.line}`}></div>
          </div>
          {!isMobile && (
            <div className="container d-flex mt-4 rights justify-content-between align-items-center flex-column flex-lg-row gap-3">
              <p
                className={`${style.rights}`}
                dangerouslySetInnerHTML={{ __html: t("footer_right") }}
              ></p>
              <p
                className={`${style.rights}`}
                dangerouslySetInnerHTML={{ __html: t("Company_Teschs") }}
              ></p>
            </div>
          )}
        </div>
      ) : (
        <Spinner/>
      )}
    </footer>
  );
};

export default Footer;
