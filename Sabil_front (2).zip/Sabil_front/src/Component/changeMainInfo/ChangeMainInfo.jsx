import { useTranslation } from "react-i18next";
import style from "./changeMainInfo.module.css";
import { useContext, useEffect, useState } from "react";
import imageUplad from "../../assets/Images/uploadimage.png";
import { authContext } from "../../Context/authContext";
import * as Yup from "yup";
import { useFormik } from "formik";
import ApiManager from "../../Utilies/ApiManager";
import { arCountries, countries } from "../../Utilies/data";
import FloatingQuillEditor from "../Ui/FloatingQuillEditor/FloatingQuillEditor";
import PhoneInput from "../Ui/PhoneInput/PhoneInput";
import FloatingInput from "../Ui/FloatingInput/FloatingInput";
import SelectElement from "../Ui/SelectElement/SelectElement";
import { motion } from "framer-motion";
import DatalistElement from "../Ui/DatalistElement/DatalistElement";
import Swal from "sweetalert2";

const ChangeMainInfo = () => {
  const { t, i18n } = useTranslation();
  const [responseFlag, setResponseFlag] = useState(false);
  const { user, token, setUser } = useContext(authContext);
  const [resMessage, setResMessage] = useState(null);
  const [loadingImageUpdate, setLoadingImageUpdate] = useState(false);
  const [profileImage, setProfileImage] = useState(
    user.image ? "https://hosoun.com"+user.image : imageUplad
  );

  // // Function to fetch fresh user data
  // const refreshUserData = async () => {
  //   try {
  //     const response = await ApiManager.getProfile(token);
  //     if (response.data.code === 200) {
  //       const freshUserData = response.data;
  //       setUser(freshUserData);
  //       localStorage.setItem("user", JSON.stringify(freshUserData));
  //     }
  //   } catch (error) {
  //     console.error("Error refreshing user data:", error);
  //   }
  // };

  useEffect(() => {
    if (user) {
      myFormik.setValues({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        phone: user.phoneNumber || "",
        birthDate: user.birthDate || "",
        gender: user.gender == "female" ? "F" : "M",
        countryId: user.countryId || "",
        eduLevel: user.eduLevel || "",
        aboutMe: user.aboutMe || "",
        profileTitle: user.profileTitle || "",
        facebook: user.facebook || "",
        x: user.x || "",
        linkedIn: user.linkedIn || "",
        youtube: user.youtube || "",
        email: user.email || "",
        address: user.address || "",
      });
    }
  }, [user]);

  const validationSchemaYup = Yup.object().shape({
    firstName: Yup.string()
      .min(3, t("Must be 3 characters or more"))
      .required(t("Required")),
    lastName: Yup.string()
      .min(3, t("Must be 3 characters or more"))
      .required(t("Required")),
    phone: Yup.string()
      .matches(/^\+?[0-9\s]+$/, t("Phone number is not valid"))
      .required(t("Required")),
    email: Yup.string()
      .email(t("Invalid email address"))
      .required(t("Required")),
    birthDate: Yup.date().required(t("Required")),
    gender: Yup.string().required(t("Required")),
    countryId: Yup.string().required(t("Required")),
    eduLevel: Yup.string().required(t("Required")),
    facebook: Yup.string(),
    twitter: Yup.string(),
    youtube: Yup.string(),
  });

  const sendData = async (values) => {
    setResponseFlag(true);

    try {
      let userData = JSON.stringify({
        firstName: values.firstName,
        lastName: values.lastName,
        phone: values.phone,
        birthDate: values.birthDate,
        gender: values.gender === "M",
        eduLevel: Number(values.eduLevel),
        country: "EGY",
        aboutMe: values.aboutMe || "",
        profileTitle: values.profileTitle || "",
        facebook: values.facebook || "",
        x: values.x || "",
        youtube: values.youtube || "",
        linkedIn: values.linkedIn || "",
        address: values.address || "",
      });

      const response = await ApiManager.updateProfile(userData, token);
      const res = response.data;

      if (res.code === 200) {
        // Fetch fresh data from the server
        // await refreshUserData();
        setUser(res.profile);

        setResMessage({
          flag: true,
          message: t("Profile updated successfully"),
        });
      } else {
        setResMessage({
          flag: false,
          message: res.errors[0],
        });
      }
    } catch (error) {
      console.error("Update error:", error.response?.data);
      const data = error.response?.data;
      setResMessage({
        flag: false,
        message:
          data?.code === 400
            ? data.errors[0]
            : t("Something went wrong, please try again later"),
      });
    } finally {
      setResponseFlag(false);
    }
  };
  const myFormik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      phone: "",
      email: "",
      birthDate: "",
      gender: "M",
      countryId: "",
      eduLevel: "",
      facebook: "",
      x: "",
      address: "",
      youtube: "",
      linkedIn: "",
      aboutMe: "",
    },
    validationSchema: validationSchemaYup,
    onSubmit: sendData,
  });

  const countryOptions = (i18n.language === "ar" ? arCountries : countries).map(
    (country) => ({
      value: country.value,
      key: country.key,
    })
  );
  const registerInputs = [
    {
      inputType: "text",
      inputName: "firstName",
      inputTransition: "firstName",
      icon: "fa-user",
    },
    {
      inputType: "text",
      inputName: "lastName",
      inputTransition: "lastName",
      icon: "fa-user",
    },
    {
      inputType: "tel",
      inputName: "phone",
      inputTransition: "phoneNumber",
      icon: "fa-phone",
    },
    {
      inputType: "email",
      inputName: "email",
      inputTransition: "email",
      icon: "fa-envelope",
      disabled: true,
    },
    {
      inputType: "text",
      inputName: "profileTitle",
      inputTransition: "profileTitle",
      icon: "fa-solid fa-id-badge",
    },
    {
      inputType: "text",
      inputName: "address",
      inputTransition: "address",
      icon: "fa-solid fa-location-dot",
    },
  ];
  // const UserDate = {
  //   code: 200,
  //   message: "current user profile",
  //   data: {
  //     isVerified: true,
  //     email: "ahmedalaaelsaadani0@gmail.com",
  //     firstName: "Ahmed Alaa",
  //     lastName: "Elsaadani",
  //     phoneNumber: "+20 01033487865",
  //     gender: "male",
  //     aboutMe: null,
  //     countryId: 43,
  //     eduLevel: 5,
  //     birthDate: "2001-08-01",
  //     facebook: null,
  //     address: null,
  //     x: null,
  //     linkedIn: null,
  //     youtube: null,
  //     image: "https://hosoun.izitechs.com",
  //     userName: "ahmedalaaelsaadani06625",
  //     countryCode: "EG",
  //   },
  // };
  const SocialInputs = [
    {
      inputType: "text",
      inputName: "facebook",
      inputTransition: "facebook",
      icon: "fa-brands fa-facebook",
    },
    {
      inputType: "text",
      inputName: "x",
      inputTransition: "twitter",
      icon: "fa-x",
    },
    {
      inputType: "text",
      inputName: "youtube",
      inputTransition: "youtube",
      icon: "fa-brands fa-youtube",
    },
    {
      inputType: "text",
      inputName: "linkedIn",
      inputTransition: "linkedinLabel",
      icon: "fa-brands fa-linkedin",
    },
  ];
  const registerInputs2 = [
    {
      inputType: "date",
      inputName: "birthDate",
      inputTransition: "birthday",
      icon: "fa-calendar",
    },
  ];
  const registerSelect = [
    {
      selectName: "eduLevel",
      selectTransition: "eduLevel",
      options: [
        {
          key: "level 1",
          value: 1,
        },
        {
          key: "level 2",
          value: 2,
        },
        {
          key: "level 3",
          value: 3,
        },
        {
          key: "level 4",
          value: 4,
        },
        {
          key: "level 5",
          value: 5,
        },
        {
          key: "level 6",
          value: 6,
        },
        {
          key: "level 7",
          value: 7,
        },
        {
          key: "level 8",
          value: 8,
        },
      ],
      icon: "fa-graduation-cap",
    },
    {
      selectName: "countryId",
      selectTransition: "Country",
      options: countryOptions,
      icon: "fa-location-dot",
    },

    {
      selectName: "gender",
      selectTransition: "Gender",
      options: [
        {
          key: "Male",
          value: "M",
        },
        {
          key: "Female",
          value: "F",
        },
      ],
      icon: "fa-children",
    },
  ];
  function validateImage(file) {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif"];
    const sizeLimit = 5 * 1024 * 1024;
    if (!file) return false;
    if (!allowedTypes.includes(file.type)) {
      Swal.fire({
        icon: "error",
        title: t("Invalid file type. Only JPEG, PNG, and GIF are allowed."),
      });
      return false;
    }
    if (file.size > sizeLimit) {
      Swal.fire({
        icon: "error",
        title: t("File size exceeds the 5MB limit."),
      });
      return false;
    }
    return true;
  }
  const uploadImage = async (file) => {
    if (validateImage(file)) {
      setLoadingImageUpdate(true);
      // Handle the file upload logic here
      const reader = new FileReader();

      try {
        const { data } = await ApiManager.updateImage(token, file);
        if (data?.code == 200) {
          reader.readAsDataURL(file);
          reader.onload = () => setProfileImage(reader.result);
          Swal.fire({
            icon: "success",
            title: t("Success"),
            text: t("Image changed successfully"),
            confirmButtonText: t("Ok"),
          });
          setLoadingImageUpdate(false);
        }
      } catch (error) {
        setLoadingImageUpdate(false);
        Swal.fire({
          icon: "error",
          text: t("Something went wrong, please try again later"),
        });
      }
    }
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    await uploadImage(file);
  };

  return (
    <div className="overflow-hidden">
      <h2 className={`${style.Head} mb-3`}>{t("PersonalInformation")}</h2>
      <form onSubmit={myFormik.handleSubmit} className="container">
        <div className={`${style.cardInfo} mb-5 `}>
          <div
            className={`${style.profileImage} mb-3 position-relative  overflow-hidden d-flex justify-content-center align-items-center`}
            style={{
              // backgroundImage: `url(${user.image ?"https://hosoun.com/" +user.image : imageUplad})`,
              backgroundImage: loadingImageUpdate
                ? "none"
                : `url(${profileImage})`,
            }}
          >
            {loadingImageUpdate ? (
              <>
                <i className="fa-solid fa-spinner fa-spin fa-spin-plus fs-4 text-warning"></i>
              </>
            ) : (
              <>
                <div
                  className={
                    style["profileImageLayer"] +
                    " position-absolute top-0 bottom-0 start-0 end-0 d-flex justify-content-center align-items-center "
                  }
                >
                  <i className="fa-solid fa-pen-to-square fs-3"></i>
                </div>
                <input
                  type="file"
                  style={{ opacity: "0", cursor: "pointer" }}
                  className="top-0 w-100 h-100 position-absolute end-0 start-0 bottom-0"
                  accept="image/*"
                  onChange={handleFileChange}
                />
              </>
            )}
          </div>
          <div className="row">
            {registerInputs.map((input, index) => (
              <>
                {input.inputType == "tel" ? (
                  <div key={index} className="col-md-6 ">
                    <PhoneInput
                      idx={index}
                      key={index}
                      {...input}
                      myFormik={myFormik}
                      initialValue={user?.phoneNumber?.split(" ")[1]}
                      initialCountry={user?.countryCode}
                    />
                  </div>
                ) : (
                  <div key={index} className="col-md-6  ">
                    <FloatingInput idx={index} {...input} myFormik={myFormik} />
                  </div>
                )}
              </>
            ))}
            {registerSelect.map((select, index) => (
              <div key={index} className="col-md-6">
                {select.selectName == "countryId" ? (
                  <DatalistElement
                    idx={index}
                    {...select}
                    myFormik={myFormik}
                    icon={select.icon}
                  />
                ) : (
                  <SelectElement
                    idx={index}
                    {...select}
                    myFormik={myFormik}
                    icon={select.icon}
                  />
                )}
              </div>
            ))}
            {registerInputs2.map((input, index) => (
              <div key={index} className="col-md-6">
                <FloatingInput
                  key={index}
                  idx={index}
                  {...input}
                  myFormik={myFormik}
                />
              </div>
            ))}
          </div>
        </div>
        <h2 className={`${style.Head} mb-3`}>{t("breifAboutMe")}</h2>
        <div className={`${style.cardInfo} mb-5 `}>
          {/* <FloatingQuillEditor
            name="infoaboutme"
            className={`${style.textarea} w-100`}
          ></FloatingQuillEditor> */}
          <FloatingQuillEditor
            inputName="aboutMe"
            myFormik={myFormik}
            idx={2}
            disabled={false}
          />
        </div>
        <h2 className={`${style.Head} mb-3`}>{t("ScoailMediaLabal")}</h2>
        <div className={`${style.cardInfo} mb-3 `}>
          <div className="row">
            {SocialInputs.map((input, index) => (
              <div key={index} className="col-md-6  ">
                <FloatingInput idx={index} {...input} myFormik={myFormik} />
              </div>
            ))}
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="col-12 m-auto text-center"
        >
          <button
            type="submit"
            disabled={responseFlag}
            className="btn-web btn-web-primary"
          >
            {responseFlag ? (
              <div className="spinner-border text-light" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              t("updateProfile")
            )}
          </button>

          {resMessage && (
            <div
              className={`my-3 ${
                resMessage.flag ? "text-success" : "text-danger"
              }`}
            >
              {resMessage.message}
            </div>
          )}
        </motion.div>
      </form>
    </div>
  );
};

export default ChangeMainInfo;
