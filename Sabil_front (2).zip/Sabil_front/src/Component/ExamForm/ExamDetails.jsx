import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import Spinner from "../Ui/Spinner/Spinner";
import ApiManager from "../../Utilies/ApiManager";
import Swal from "sweetalert2";
const ExamDetails = ({
  attemptId,
  style,
  token,
  setFlagDetails,
  doAfterFinishExam,
  cancelExam,
}) => {
  const [attemptDetails, setAttemptDetails] = useState(null);
  const { t } = useTranslation();
  const [flagFailed, setFlagFailed] = useState(false);

  // const getDetails = async () => {
  // setAttemptDetails({
  //   attemptId: 11,
  //   examId: 10,
  //   title: "4444",
  //   description: "7458",
  //   successGrade: 10,
  //   fullMark: 25,
  //   totalGrade: 18,
  //   isSucceed: true,
  //   timeInMinutes: 10,
  //   takenTimeInMinutes: 2.924039685,
  //   startTimeUtc: "2025-02-05T19:45:00.9930421",
  //   answers: [
  //     {
  //       questionText: "الإجاية الصحيحة هي الأولى",
  //       questionId: 36,
  //       studentChoiceId: 99,
  //       correctChoiceId: 99,
  //       isCorrect: true,
  //       studentGrade: 5,
  //       questionGrade: 5,
  //       choices: [
  //         {
  //           id: 99,
  //           text: "صح",
  //         },
  //         {
  //           id: 100,
  //           text: "خطأ",
  //         },
  //       ],
  //     },
  //     {
  //       questionText: "الإجاية الصحيحة هي الأولى",
  //       questionId: 37,
  //       studentChoiceId: 101,
  //       correctChoiceId: 101,
  //       isCorrect: true,
  //       studentGrade: 5,
  //       questionGrade: 5,
  //       choices: [
  //         {
  //           id: 101,
  //           text: "1",
  //         },
  //         {
  //           id: 102,
  //           text: "2",
  //         },
  //         {
  //           id: 103,
  //           text: "3",
  //         },
  //         {
  //           id: 104,
  //           text: "4",
  //         },
  //       ],
  //     },
  //     {
  //       questionText: "الإجاية الصحيحة هي الثانية",
  //       questionId: 38,
  //       studentChoiceId: 106,
  //       correctChoiceId: 106,
  //       isCorrect: true,
  //       studentGrade: 8,
  //       questionGrade: 8,
  //       choices: [
  //         {
  //           id: 105,
  //           text: "صح",
  //         },
  //         {
  //           id: 106,
  //           text: "خطأ",
  //         },
  //       ],
  //     },
  //     {
  //       questionText: "الإجاية الصحيحة هي الأخيرة",
  //       questionId: 39,
  //       studentChoiceId: 109,
  //       correctChoiceId: 110,
  //       isCorrect: false,
  //       studentGrade: 0,
  //       questionGrade: 7,
  //       choices: [
  //         {
  //           id: 107,
  //           text: "1",
  //         },
  //         {
  //           id: 108,
  //           text: "2",
  //         },
  //         {
  //           id: 109,
  //           text: "3",
  //         },
  //         {
  //           id: 110,
  //           text: "4",
  //         },
  //       ],
  //     },
  //   ],
  // });
  const getDetails = async () => {
    try {
      const { data } = await ApiManager.getExamDetails(token, attemptId);
      if (data.code == 200) {
        setAttemptDetails(data.data);
      }
    } catch (error) {
      const errorCode = error.response?.data?.code;

      console.error("Error caught! Code:", errorCode);

      if (errorCode === 411) {
        Swal.fire({
          icon: "error",
          title: t("attempt.failed"),
          text: t("attempt.you have not succeeded in this attempt!"),
        });
        setFlagFailed(true);
      }
    }
  };

  useEffect(() => {
    getDetails();
  }, [attemptId]);

  return (
    <>
      {attemptDetails ? (
        <div className={"container mt-4 " + style.Exam}>
          <div className="shadow-lg p-4">
            <h2 className="mb-4 text-center">{attemptDetails.title}</h2>
            <p
              className="text-center"
              dangerouslySetInnerHTML={{ __html: attemptDetails.description }}
            ></p>
            <div className="row">
              <p className="text-center text-warning col-md-6 p-1 my-2 lead border border-warning">
                {t("Exam.success mark")} {attemptDetails.successGrade}
              </p>
              <p className="text-center text-warning col-md-6 p-1 my-2 lead border border-warning">
                {t("Exam.full mark")} {attemptDetails.fullMark}
              </p>
            </div>
            <p
              className="text-center fw-bold"
              style={{ color: attemptDetails.isSucceed ? "green" : "red" }}
            >
              {t("mark")}: {attemptDetails.totalGrade} /{" "}
              {attemptDetails.fullMark}
            </p>
            <p className="text-center">
              {t("Exam.Time elapsed")}{" "}
              {Math.round(attemptDetails.takenTimeInMinutes + 1)} m
            </p>

            <div className="mt-4">
              {attemptDetails.answers.map((answer, idx) => (
                <div
                  key={answer.questionId}
                  className="mb-3 p-3 border rounded"
                >
                  <div className="d-flex flex-column my-2">
                    <p className="fw-bold">
                      {idx + 1}- {answer.questionText}
                    </p>
                    <p className="align-self-end">
                      <span className="text-bg-warning text-white rounded px-1 ">
                        {t("mark")}:
                        {answer.studentGrade + "/" + answer.questionGrade}
                      </span>
                    </p>
                  </div>
                  <div className="form-check  p-0">
                    {answer.choices.map((choice) => (
                      <div
                        key={choice.id}
                        className={`mb-2 d-flex justify-content-start gap-5 w-100 align-content-end  ${
                          choice.id === answer.correctChoiceId
                            ? style.correctChoice
                            : choice.id === answer.studentChoiceId
                            ? style.wrongChoice
                            : ""
                        }`}
                      >
                        <input
                          className="form-check-input"
                          type="radio"
                          name={`q${answer.questionId}`}
                          id={`q${answer.questionId}-choice${choice.id}`}
                          value={choice.id}
                          checked={answer.studentChoiceId === choice.id}
                          readOnly
                        />
                        <label
                          className="form-check-label ms-2"
                          htmlFor={`q${answer.questionId}-choice${choice.id}`}
                        >
                          {choice.text}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="row justify-content-center">
              {attemptDetails.isSucceed ? (
                <div className="col-lg-6 col-md-12">
                  <button
                    className="btn-web w-100 btn-web-primary"
                    onClick={doAfterFinishExam}
                  >
                    {t("Ok")}
                  </button>
                </div>
              ) : (
                <div className="col-lg-6 col-md-12">
                  <button
                    className="btn-web w-100 btn-web-secondary"
                    onClick={() => setFlagDetails(false)}
                  >
                    {t("Exam.start a new attempt")}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : flagFailed ? (
        <div className={"container mt-4 " + style.Exam}>
          <div className="row">
            <div className="col-12 bg-danger rounded-3 p-3 fs-3 text-center my-3">
              <p>{t("attempt.you have not succeeded in this attempt!")}</p>
            </div>
            <div className="col-lg-6 col-md-12">
              <button
                className="btn-web w-100 btn-web-primary"
                onClick={() => {
                  setFlagFailed(false);
                  cancelExam();
                }}
              >
                {t("Cancel")}
              </button>
            </div>
            <div className="col-lg-6 col-md-12">
              <button
                className="btn-web w-100 btn-web-secondary"
                onClick={() => {
                  setFlagFailed(false);
                  setFlagDetails(false);
                }}
              >
                {t("Exam.start a new attempt")}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <Spinner />
      )}
    </>
  );
};
export default ExamDetails;

