import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useFormik } from "formik";
import style from "./ExamForm.module.css";
import { useTranslation } from "react-i18next";
import Swal from "sweetalert2";
import Spinner from "../Ui/Spinner/Spinner";
import ApiManager from "../../Utilies/ApiManager";
import ExamDetails from "./ExamDetails";
//STILL WORKING

/*
    ExamSource values:
        1: Courses
        2: OnlineEdu
*/
function ExamForm({
  examId, //
  examSource, //
  coursePath, //
  doAfterFinishExam, //
  subscriptionPlanId,
  token,
  cancelExam,
}) {
  const { t } = useTranslation();
  const [testTime, setTestTime] = useState(null);
  const [testTimeIntervalId, setTestTimeIntervalId] = useState(null);
  const [flagDetails, setFlagDetails] = useState(false);
  const [loading, setLoading] = useState(false);
  const [test, setTest] = useState(null);

  // const response = {
  //   code: 200,
  //   message: "exam questions",
  //   data: {
  //     id: 10,
  //     title: "4444",
  //     description: "7458",
  //     successGrade: 10,
  //     fullMark: 25,
  //     timeInMinutes: 10,
  //     attemptId: 12,
  //     questions: [
  //       {
  //         id: 36,
  //         text: "الإجاية الصحيحة هي الأولى",
  //         mark: 5,
  //         choices: [
  //           {
  //             id: 99,
  //             text: "صح",
  //           },
  //           {
  //             id: 100,
  //             text: "خطأ",
  //           },
  //         ],
  //       },
  //       {
  //         id: 37,
  //         text: "الإجاية الصحيحة هي الأولى",
  //         mark: 5,
  //         choices: [
  //           {
  //             id: 101,
  //             text: "1",
  //           },
  //           {
  //             id: 102,
  //             text: "2",
  //           },
  //           {
  //             id: 103,
  //             text: "3",
  //           },
  //           {
  //             id: 104,
  //             text: "4",
  //           },
  //         ],
  //       },
  //       {
  //         id: 38,
  //         text: "الإجاية الصحيحة هي الثانية",
  //         mark: 8,
  //         choices: [
  //           {
  //             id: 105,
  //             text: "صح",
  //           },
  //           {
  //             id: 106,
  //             text: "خطأ",
  //           },
  //         ],
  //       },
  //       {
  //         id: 39,
  //         text: "الإجاية الصحيحة هي الأخيرة",
  //         mark: 7,
  //         choices: [
  //           {
  //             id: 107,
  //             text: "1",
  //           },
  //           {
  //             id: 108,
  //             text: "2",
  //           },
  //           {
  //             id: 109,
  //             text: "3",
  //           },
  //           {
  //             id: 110,
  //             text: "4",
  //           },
  //         ],
  //       },
  //     ],
  //   },
  // };
  // const test = response.data;
  const submitExam = async (values) => {
    setLoading(true);
    const answers = Object.keys(values).map((questionId) => ({
      QuestionId: Number(questionId),
      ChoiceId: Number(values[questionId]),
    }));

    try {
      const { data } = await ApiManager.submitExam(
        token,
        answers,
        examId,
        test.attemptId
      );
      if (data.code === 200) {
        setTestTime(null);
        setFlagDetails(true);
        setLoading(false);
      }
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  const formik = useFormik({
    initialValues: test?.questions.reduce(
      (acc, q) => ({ ...acc, [q.id]: "" }),
      {}
    ),
    validate: (values) => {
      const errors = {};
      test?.questions.forEach((q) => {
        if (!values[q.id]) {
          errors[q.id] = t("Required");
        }
      });
      return errors;
    },
    validateOnChange: false,
    validateOnBlur: false,
    onSubmit: submitExam,
  });
  const getExam = async () => {
    try {
      const examObject = {
        examSource: examSource,
        coursePath: coursePath,
        subscriptionPlanId: subscriptionPlanId,
      };
      const { data } = await ApiManager.starExam(token, examObject, examId);
      if (data.code === 200) {
        setTestTime(data.data.timeInMinutes * 60);
        formik.setValues(
          data.data.questions.reduce((acc, q) => ({ ...acc, [q.id]: "" }), {})
        );
        setTest(data.data);
      }
    } catch (error) {
      console.error(error);
      if (error.response.data.code === 421) {
        Swal.fire({
          title: t("Error"),
          text: t(
            "Exam.You can't start a new attempt now, try again later after 48 hours from the last attempt"
          ),
          icon: "error",
          confirmButtonText: t("Ok"),
          confirmButtonColor: "var(--primary-color)",
          background: "var(--bg-color)",
          color: "var(--black-light-color)",
        });
        cancelExam();
      } else if (error.response.data.code === 420) {
        Swal.fire({
          title: t("Info"),
          text: t("Exam.You have already succeeded in this exam"),
          icon: "info",
          confirmButtonText: t("Ok"),
          confirmButtonColor: "var(--primary-color)",
          background: "var(--bg-color)",
          color: "var(--black-light-color)",
        });
        cancelExam();
      }

      setLoading(false);
    }
  };

  useEffect(() => {
    // start timer
    if (!testTimeIntervalId && testTime != 0) {
      const timer = setInterval(() => {
        setTestTime((prevTime) => prevTime - 1);
      }, 1000);
      setTestTimeIntervalId(timer);
    }
    // clear interval
    if (testTime === 0) {
      clearTimeout(testTimeIntervalId);

      Swal.fire({
        title: t("Exam.time is over"),
        text: t("Exam.that will affect your result"),
        icon: "error",
        confirmButtonText: t("Ok"),
        confirmButtonColor: "var(--primary-color)",
        background: "var(--bg-color)",
        color: "var(--black-light-color)",
      });
    }
    return () => clearTimeout(testTimeIntervalId);
  }, [testTime]);
  useEffect(() => {
    if (examId && examSource && (coursePath || subscriptionPlanId)) {
      if (!flagDetails) {
        getExam();
      }
    }
  }, [flagDetails]);
  return (
    <div className={"container mt-4 " + style.Exam}>
      {test ? (
        flagDetails ? (
          <ExamDetails
            style={style}
            token={token}
            attemptId={test.attemptId}
            setFlagDetails={setFlagDetails}
            doAfterFinishExam={doAfterFinishExam}
            cancelExam={cancelExam}
          />
        ) : (
          <div className=" shadow-lg p-4">
            <h2 className="mb-4 text-center">{test.title}</h2>
            <div
              className="my-2 text-center"
              dangerouslySetInnerHTML={{ __html: test.description }}
            ></div>
            <div className="d-flex align-items-center flex-column justify-content-around">
              <div className={`${style.progress}`}>
                <div
                  className={`${style.progressBar}`}
                  style={{
                    width: `${(testTime / (test.timeInMinutes * 60)) * 100}%`,
                  }}
                ></div>
              </div>
              <p className={`${style.precent} `}>
                {~~(testTime / 60)}m : {testTime % 60}s
              </p>
            </div>

            <form onSubmit={formik.handleSubmit} className="w-100">
              {test.questions.map((q, idx) => (
                <div key={q.id} className="mb-4">
                  <div className="d-flex flex-column my-2">
                    <p className="fw-bold">
                      {idx + 1}- {q.text}
                    </p>
                    <p className="align-self-end">
                      <span className="text-bg-warning text-white rounded px-1 ">
                        {t("mark")}: {q.mark}
                      </span>
                    </p>
                  </div>
                  <div className="form-check">
                    {q.choices.map((choice) => (
                      <div
                        key={choice.id}
                        className="mb-2  d-flex justify-content-start gap-5 align-content-end"
                      >
                        <input
                          className="form-check-input"
                          type="radio"
                          name={q.id}
                          id={`q${q.id}-choice${choice.id}`}
                          value={choice.id}
                          checked={formik.values[q.id] === String(choice.id)}
                          onChange={formik.handleChange}
                        />
                        <label
                          className="form-check-label ms-2"
                          htmlFor={`q${q.id}-choice${choice.id}`}
                        >
                          {choice.text}
                        </label>
                      </div>
                    ))}
                  </div>
                  {formik.errors[q.id] && (
                    <p className="text-danger">{formik.errors[q.id]}</p>
                  )}
                </div>
              ))}
              <div className="row">
                <p className="text-center text-warning col-md-6 p-1 my-2 lead border border-warning">
                  {t("Exam.success mark")} {test.successGrade}
                </p>
                <p className="text-center text-warning col-md-6 p-1 my-2 lead border border-warning">
                  {t("Exam.full mark")} {test.fullMark}
                </p>
              </div>
              <button
                type="submit"
                className=" btn-web btn-web-primary w-50 d-block mx-auto "
                disabled={loading}
              >
                <i
                  className={
                    loading ? "fa-solid fa-spinner fa-spin" : "fst-normal"
                  }
                  style={{
                    fontStyle: "normal",
                  }}
                >
                  {!loading && t("Exam.submit")}
                </i>
              </button>
            </form>
          </div>
        )
      ) : (
        <Spinner />
      )}
    </div>
  );
}

export default ExamForm;
