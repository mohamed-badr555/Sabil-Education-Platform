import React, { useRef } from "react";
import "./MainSwiper.css";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import i18n from "../../i18n";
const MainSwiper = ({ data, Card }) => {
  const swiperRef = useRef(null);
  const handlePrev = () => {
    if (swiperRef.current && swiperRef.current.swiper) {
      swiperRef.current.swiper.slidePrev();
    }
  };

  const handleNext = () => {
    if (swiperRef.current && swiperRef.current.swiper) {
      swiperRef.current.swiper.slideNext();
    }
  };

  return (
    <>
      {data.length >= 1 && (
        <div className="swiper-container ">
          <Swiper
            ref={swiperRef}
            // slidesPerView={1}
            // centeredSlides={true}
            breakpoints={{
              0: { slidesPerView: 1, spaceBetween: 5 },
              425: { slidesPerView: 2, spaceBetween: 15 },
              768: { slidesPerView: 3, spaceBetween: 20 },
              1200: { slidesPerView: 4, spaceBetween: 30 },
            }}
            initialSlide={0}
            grabCursor={true}
            modules={[Navigation]}
            className="mySwiper"
            style={{ width: "100%" }}
            loop={true}
          >
            {data.map((item, index) => (
              <SwiperSlide key={index} className="swiper-slide">
                <Card card={item} />
              </SwiperSlide>
            ))}
            {/* That fix the problem of the last two slides which one disappear and other display half */}
            {/* <SwiperSlide className="swiper-slide"></SwiperSlide>
            <SwiperSlide className="swiper-slide"></SwiperSlide> */}
          </Swiper>
          <div className="mt-4">
            <div className="custom-navigation ">
              <button className="custom-next" onClick={handlePrev}>
                {i18n.language === "ar" ? (
                  <i className="fa-solid fa-caret-right"></i>
                ) : (
                  <i className="fa-solid fa-caret-left"></i>
                )}
              </button>
              <button className="custom-prev" onClick={handleNext}>
                {i18n.language === "ar" ? (
                  <i className="fa-solid fa-caret-left"></i>
                ) : (
                  <i className="fa-solid fa-caret-right"></i>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default MainSwiper;
