import React, { useEffect, useState } from "react";
import contactimage from "../../assets/Images/ContactUs.png";
import callusimage from "../../assets/Images/Callus.png";
import payCard2 from "../../assets/Images/paycard2.png";
import payCard1 from "../../assets/Images/paycard1.png";
import style from "./ContactUS.module.css";
import { useTranslation } from "react-i18next";
import { useFormik } from "formik";
import ApiManager from "../../Utilies/ApiManager";
import * as Yup from "yup";
import { motion } from "framer-motion";
import FloatingInput from "../../Component/Ui/FloatingInput/FloatingInput";
import Swal from "sweetalert2";
import PhoneInput from "../Ui/PhoneInput/PhoneInput";
import Textarea from "../Ui/Textarea/Textarea";
//"contact": {
//     "phone": "+966570468163",
//     "email": "info@hosoun.com",
//     "address": "المنصورة - مصر"
// },

const ContactUs = ({ contact }) => {
  const { t, i18n } = useTranslation();
  const [responseFlag, setResponseFlag] = useState(false);

  // validation schema
  const validationSchemaYup = Yup.object().shape({
    name: Yup.string()
      .min(3, t("Must be 3 characters or more"))
      .required(t("Required")),

    email: Yup.string()
      .email(t("Invalid email address"))
      .required(t("Required")),

    phonNumber: Yup.string().required(t("Required")),

    message: Yup.string()
      .min(10, t("Must be 10 characters or more"))
      .required(t("Required")),
  });

  // send message to the server

  const sendMessage = async (values) => {
    let userData = JSON.stringify({
      Name: values.name,
      Email: values.email,
      Phone: values.phonNumber,
      Message: values.message,
    });

    setResponseFlag(true);

    try {
      const { data } = await ApiManager.contactUs(userData);

      if (data.code && data.code === 200) {
        Swal.fire({
          title: t("Success"),
          text: t("message sent successfully"),
          icon: "success",
          button: t("Ok"),
        });
      } else {
        Swal.fire({
          title: t("Error"),
          text: t("Something went wrong, please try again later"),
          icon: "error",
          button: t("Ok"),
        });
      }
    } catch (error) {
      console.error("There was an error sending the message:", error);
      Swal.fire({
        title: t("Error"),
        text: t("Something went wrong, please try again later"),
        icon: "error",
        button: t("Ok"),
      });
    } finally {
      setResponseFlag(false);
    }
  };
  const myFormik = useFormik({
    initialValues: {
      name: "",
      email: "",
      phonNumber: "",
      message: "",
    },
    onSubmit: sendMessage,
    validationSchema: validationSchemaYup,
  });
  const contactInputs = [
    {
      inputType: "text",
      inputName: "name",
      inputTransition: "name",
      icon: "fa-user",
    },
    {
      inputType: "email",
      inputName: "email",
      inputTransition: "email",
      icon: "fa-envelope",
    },
    {
      inputType: "tel",
      inputName: "phonNumber",
      inputTransition: "phoneNumber",
      icon: "fa-phone",
    },
  ];
  return (
    <>
      <div className={"my-5 container " + style.contactUs}>
        <div className="row flex-wrap align-items-center justify-content-evenly  ">
          <div className="col-md-6">
            <div className="form">
              <form
                onSubmit={myFormik.handleSubmit}
                className={
                  "row  justify-content-between shadow my-3 pt-5 rounded-5 " +
                  style.ParentContainer
                }
              >
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                  className="col-12 my-3"
                >
                  <h3>{t("contact_title")}</h3>
                </motion.div>
                <motion.div
                  initial={{
                    opacity: 0,
                    x: i18n.language === "ar" ? 100 : -100,
                  }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                  className="col-md-12  d-flex flex-column px-1 justify-content-center"
                >
                  {contactInputs.map((input, index) => (
                    <>
                      <div key={index + "Form"}>
                        {input.inputType == "tel" ? (
                          <PhoneInput
                            idx={index}
                            {...input}
                            myFormik={myFormik}
                          />
                        ) : (
                          <FloatingInput
                            idx={index}
                            {...input}
                            myFormik={myFormik}
                          />
                        )}
                      </div>
                    </>
                  ))}
                </motion.div>
                <motion.div
                  initial={{
                    opacity: 0,
                    x: i18n.language === "ar" ? -100 : 100,
                  }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                  className="col-md-12 "
                >
                  {/* { <div
                    className={
                      " h-100 overflow-hidden d-flex flex-column px-1 " +
                      style.message
                    }
                  >
                    <label htmlFor="message" className="form-label ">
                      <i className="fa-solid fa-message"></i>
                      {t("message")}
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      onChange={myFormik.handleChange}
                      className="form-control flex-grow-1 mb-3"
                      placeholder={t("contact_message_placeholder")}
                      value={myFormik.values.message}
                      style={{
                        minHeight: "100px",
                      }}
                    ></textarea>
                    {myFormik.errors.message && myFormik.touched.message && (
                      <div className="text-center w-100  text-danger">
                        {myFormik.errors.message}
                      </div>
                    )}
                  </div>} */}
                  <Textarea
                    inputName={"message"}
                    myFormik={myFormik}
                    inputTransition={"message"}
                    icon={"fa-message"}
                  />
                </motion.div>
                <div className="col-12 my-3 d-flex justify-content-center flex-column">
                  <button
                    type="submit"
                    className="btn-web btn-web-primary m-auto "
                  >
                    {
                      <span>
                        {responseFlag ? (
                          <div
                            className="spinner-border text-light"
                            role="status"
                          >
                            <span className="visually-hidden">Loading...</span>
                          </div>
                        ) : (
                          t("contact_send")
                        )}
                      </span>
                    }
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div className="col-md-6 d-flex justify-content-center">
            <div className={`${style.image}`}>
              <img src={contactimage} alt="contactimage" />
            </div>
          </div>
        </div>
      </div>
      <div className={"py-5 " + style.information}>
        <div className="container">
          <div className="d-flex flex-wrap  ">
            <div className={`${style.image}`}>
              <img loading="lazy" src={callusimage} alt="callusimage" />
            </div>
            <div className={`${style.CallUS_Card}`}>
              <div className={`${style.CircularCall}`}>
                <h3>{t("CaLUS_Contact")} </h3>
                <div
                  className={`d-flex flex-wrap flex-column flex-md-row gap-2 align-items-center justify-content-evenly  `}
                >
                  <div className={`d-flex align-items-center gap-2`}>
                    <span>{contact.address}</span>
                    <span className={`${style.circleIcon}`}>
                      <i className="fa-solid fa-location-dot"></i>
                    </span>
                  </div>

                  <div className={`d-flex align-items-center gap-2`}>
                    <span>
                      <a to={`mailto:${contact.email}`}>{contact.email}</a>
                    </span>
                    <span className={`${style.circleIcon}`}>
                      <i className="fa-solid fa-envelope"></i>
                    </span>
                  </div>
                  <div className={`d-flex align-items-center gap-2`}>
                    <span>
                      <a to={`tel:${contact.phone}`}>{contact.phone}</a>
                    </span>
                    <span className={`${style.circleIcon}`}>
                      <i className="fa-solid fa-phone-volume"></i>
                    </span>
                  </div>
                </div>
              </div>
              <div
                className={`d-flex flex-row flex-wrap justify-content-evenly align-items-center `}
              >
                <h4>{t("Accept_Pay")}</h4>
                <div className="d-flex align-items-center gap-2 ">
                  <img loading="lazy" src={payCard1} alt="mastercard" />
                  <img loading="lazy" src={payCard2} alt="visa" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContactUs;
