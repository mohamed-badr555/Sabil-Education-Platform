export const RatingStars = ({ rating }) => {
    // Clamp rating between 0-5 and ensure it's a number
    const rate = Math.max(0, Math.min(parseFloat(rating) || 0, 5));
    const fullStars = Math.max(0, Math.floor(rate));
    const hasHalfStar = rate % 1 >= 0.5;
    const emptyStars = Math.max(0, 5 - Math.ceil(rate));
  
    return (
      <div className="d-flex align-items-center gap-1">
        {Array.from({length: fullStars}, (_, index) => (
          <i key={`full-${index}`} className="fas fa-star text-warning"></i>
        ))}
        {hasHalfStar && (
          <i className="fa-regular fa-star-half-stroke text-warning"></i>
        )}
        {Array.from({length: emptyStars}, (_, index) => (
          <i key={`empty-${index}`} className="far fa-star text-warning"></i>
        ))}
        <span style={{color:"var(--mainText)"}} >({rate.toFixed(1)})</span>
      </div>
    );
};