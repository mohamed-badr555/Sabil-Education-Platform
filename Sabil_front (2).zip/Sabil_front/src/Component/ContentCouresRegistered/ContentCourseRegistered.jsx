import React, { useEffect, useState } from "react";
import style from "./ContentCourseRegistered.module.css";
import { useTranslation } from "react-i18next";
import { useOutletContext } from "react-router-dom";
import VideoPlayer from "./../../Pages/VideoPlayer/VideoPlayer";

const ContentCourseRegistered = () => {
  const { t } = useTranslation();
  const { lastAccessedVideoId, units, updateCourseData, finalExamId } =
    useOutletContext();
  const [currentUnitIndex, setCurrentUnitIndex] = useState(0);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);

  // Find initial video position based on lastAccessedVideoId
  useEffect(() => {
    if (units && units.length > 0) {
      // If no lastAccessedVideoId, start with first video
      if (!lastAccessedVideoId) {
        setCurrentUnitIndex(0);
        setCurrentVideoIndex(0);
        return;
      }

      // Find the video with lastAccessedVideoId
      for (let i = 0; i < units.length; i++) {
        const videoIndex = units[i].videos.findIndex(
          (v) => v.id === lastAccessedVideoId
        );
        if (videoIndex !== -1) {
          setCurrentUnitIndex(i);
          setCurrentVideoIndex(videoIndex);
          break;
        }
      }
    }
  }, [units, lastAccessedVideoId]);

  const handleVideoComplete = async (newUnitIndex, newVideoIndex) => {
    try {
      setCurrentUnitIndex(newUnitIndex);
      setCurrentVideoIndex(newVideoIndex);
      // Update course data to save progress
      await updateCourseData();
    } catch (error) {
      console.error("Error handling video completion:", error);
    }
  };

  const handleExamComplete = async () => {
    try {
      await updateCourseData();
    } catch (error) {
      console.error("Error handling exam completion:", error);
    }
  };

  return (
    <div className="container">
      <h4 className={`${style.titleD} mt-4`}>{t("ContentCourse")}</h4>
      <div className={`${style.boxshadow} my-3`}>
        <span>
          {units.length} {t("Units")} |
        </span>
        <span>
          {units.reduce((el, contain) => el + contain.videos.length, 0)}{" "}
          {t("lessons")}
        </span>
      </div>
      <div>
        {units && units.length > 0 && (
          <VideoPlayer
            units={units}
            currentUnitIndex={currentUnitIndex}
            currentVideoIndex={currentVideoIndex}
            onVideoComplete={handleVideoComplete}
            onExamComplete={handleExamComplete}
            lastAccessedVideoId={lastAccessedVideoId} // Pass this to VideoPlayer
            finalExamId={finalExamId} // Pass this to VideoPlayer
          />
        )}
      </div>
    </div>
  );
};
export default ContentCourseRegistered;
