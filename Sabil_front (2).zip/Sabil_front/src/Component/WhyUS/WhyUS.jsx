import React from "react";
import { useTranslation } from "react-i18next";
import style from "./WhyUS.module.css";
import { motion, useInView } from "framer-motion";
// import { whyUSArr } from '../../Utilies/data'
/**   
 *  "whyUs": [
            {
                "title": "اختبارات مستمرة",
                "description": "نقدم الإختبارات المستمرة على كل الدورات الموجودة لمتابعة مستوى الطلاب",
                "icon": "https://hosoun.com/front/svg/question.svg"
            }
        ],
 */
const WhyUS = ({ whyUs }) => {
  const { t } = useTranslation();
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });
  return (
    <div className={style["whyus"] + ``}>
      <div className="text-center p-5 container">
        <h2 className={style["main_head_title"]}>{t("WhyUs_title")}</h2>
        <p className={style["main_head_text"]}>{t("WhyUs_text")}</p>
        <div
          ref={ref}
          className={` my-2  d-flex justify-content-between flex-wrap   align-items-center `}
        >
          {whyUs.map((item, idx) => (
            <motion.div
              initial={{ opacity: 0, x: 100 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 100 }}
              transition={{ duration: 0.3, delay: idx * 0.1 }}
              key={idx}
              className={` col-md-6 col-lg-4  d-flex flex-column overflow-hidden justify-content-center p-2 align-items-center  `}
            >
              <div className={`${style.card} `}>
                <div
                  className={`d-flex align-items-center mb-2 gap-2  flex-column flex-md-row`}
                >
                  <img src={item.icon} alt="icon" />
                  <h5>{t(item.title)}</h5>
                </div>
                <div className="flex-grow-1">
                  <p>{t(item.description)} </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WhyUS;
