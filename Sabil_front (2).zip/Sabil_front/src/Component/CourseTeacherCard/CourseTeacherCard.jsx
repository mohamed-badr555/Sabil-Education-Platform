import style from "./CourseTeacherCard.module.css";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { RatingStars } from "../RatingStars/RatingStars";
const CourseTeacherCard = ({ card }) => {
  const { t } = useTranslation();
  /**
     *     {
                "id": "test1",
                "title": "دورة كيف تتقن البلاغة؟",
                "thumbnail": "https://hosoun.com/images/course/1720703744كيف تتقن البلاغه-1.jpg",
                "rate": 4.5,
                "price": {
                    "usd": 30,
                    "egp": 500,
                    "sar": 100
                }
            },
     */
  return (
    <div className="m-2">
      <div className={`card shadow-md ${style.cardImage}  `}>
        <div className="overflow-hidden">
          <img
            src={card.thumbnail}
            className="card-img-top"
            alt="Course"
            // onError={(e) => {
            //   e.target.src = DefaultImage;
            // }}
          />
        </div>
        <div className="card-body text-center">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <div className="rating">
              {/* {[...Array(5)].map((_, index) => {
                if (index < Math.floor(card.rate)) {
                  return (
                    <i key={index} className="fas fa-star text-warning"></i>
                  );
                } else if (index < card.rate) {
                  return (
                    <i
                      key={index}
                      className="fas fa-star-half-alt text-warning"
                    ></i>
                  );
                } else {
                  return (
                    <i key={index} className="far fa-star text-warning"></i>
                  );
                }
              })} */}
              <RatingStars rating={card.rate} />
            </div>
            <span className={`badge text-white ${style["free"]}`}>
              {card.coursePrice === 0
                ? t("free")
                : card.coursePrice + " " + card.currency}
            </span>
          </div>
          <p className="card-title">{card.title}</p>
          {/* <Link className={`btn ${style.addToCartBtn}  `}>
            <i className="fas fa-shopping-cart me-2"></i>
            {t("add_to_cart")}
          </Link> */}
          <Link
            to={`/courses/${card.path}`}
            className={`btn ${style.addToCartBtn}  `}
          >
            {/* <i className="fas fa-shopping-cart me-2"></i> */}
            {t("goToCourse")}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CourseTeacherCard;
