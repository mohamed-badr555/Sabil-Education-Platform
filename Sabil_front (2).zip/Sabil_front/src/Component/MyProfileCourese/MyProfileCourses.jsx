import React, { useEffect, useState } from "react";
import Heading from "../Heading/Heading";
import { useTranslation } from "react-i18next";

import style from "./MyProfileCourses.module.css";
import { Link } from "react-router-dom";
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../Ui/Spinner/Spinner";
import { useContext } from "react";
import { authContext } from "./../../Context/authContext";
import { RatingStars } from "../RatingStars/RatingStars";

const MyProfileCourses = () => {
  const { t } = useTranslation();
  const [flagNoData, setFlagNoData] = useState(false);
  const [MyCourses, setMyCourses] = useState(null);
  const { token } = useContext(authContext);
  const getMyCourses = async () => {
    setFlagNoData(true);
    setMyCourses(null);
    try {
      setFlagNoData(false);
      setMyCourses(null);
      const { data } = await ApiManager.GetMyCourses(token);
      if (data.data && data.data.length !== 0) {
        // let idx = data.data.findIndex(
        //   (course) =>
        //     course.certificateCode === null && course.progressPercentage >= 100
        // );

        // if (idx !== -1) {
        //   completeCourseAndExportCertificate(data.data[idx].path);
        // } else {
          setMyCourses(data.data);
          setFlagNoData(false);
        // }
      } else {
        setFlagNoData(true);
        setMyCourses(null);
      }
    } catch (error) {
      setFlagNoData(true);
      console.error(error);
    }
  };

 
  const downloadCertificate = async (certificateId, certificateName) => {
    try {
      const { data } = await ApiManager.downloadCertificate(certificateId);

      // create a Blob object from the PDF data
      const blob = new Blob([data], { type: "application/pdf" });

      // create a URL object from the Blob object
      const url = window.URL.createObjectURL(blob);

      // create a link element and trigger a click event to download the PDF
      const a = document.createElement("a");
      a.href = url;
      a.download = `${certificateName}.pdf`;
      document.body.appendChild(a);
      a.click();

      // clean up the URL object
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading certificate:", error);
    }
  };

  useEffect(() => {
    getMyCourses();
  }, []);

  /*
"id": 1,
            "isCompleted": true,
            "subscriptionTime": "2025-01-26T14:52:20.7732787",
            "certificateCode": "lKYI9G0r",
            "certificateUrl": "/files/certificates/lKYI9G0r",
            "progressPercentage": 0,
            "lastAccessedVideoId": 337,
            "title": "البرمجة (برنامج Scratch)",
            "thumbnail": "https://hosoun.izitechs.com/statichttps://hosoun.izitechs.comstatic/courses/Course_66106591-bbd0-41ca-8729-e2c6c1b27fe1.jpg",
            "path": "path_to_course1",
            "audienceLevel": "مبتدئ",
            "duration": null,
            "category": "اللغات",
            "rate": {
                "rateStars": 3,
                "rateComment": "تجربة تحديث ، ستفدت كثيرا، شكرا لك!",
                "rateTime": "2025-01-30T16:45:52.391796"
            }
        },

*/

  return (
    <section className="overflow-hidden">
      <Heading title={t("MyProfileCourses")} />
      {MyCourses ? (
        <div className="container my-5 ">
          <div className="row">
            {MyCourses.map((course, idx) => (
              <div className={`col-lg-4 col-md-6 mb-3 `} key={idx}>
                <div className={`card shadow-md ${style.cardImage}  `}>
                  <div className="overflow-hidden">
                    <img
                      src={course.thumbnail}
                      className="card-img-top"
                      alt="Course"
                    />
                  </div>
                  <div className="card-body ">
                    <div className="d-flex justify-content-between align-content-center gap-2 flex-column">
                      <RatingStars rating={course.rate.rateStars} />

                      <p className={`${style.title}`}>{t(course.title)}</p>
                      <div className="d-flex align-items-center justify-content-around">
                        <div className={`${style.progress}`}>
                          <div
                            className={`${style.progressBar}`}
                            style={{ width: `${course.progressPercentage}%` }}
                          ></div>
                        </div>
                        <p className={`${style.precent} `}>
                          {Math.round(course.progressPercentage)}%
                        </p>
                      </div>
                      <div className="d-flex align-items-center mt-2 justify-content-around">
                        <Link
                          to={`/courses/${course.path}/content`}
                          className={`btn ${style.CourseBtn} d-block    `}
                        >
                          {course.progressPercentage === 0
                            ? t("StartCourse")
                            : course.isCompleted
                            ? t("CompletedCourse")
                            : t("CompleteCourse")}
                        </Link>
                        {course.certificateUrl && course.certificateCode && (
                          <button
                            to={`${course.certificateUrl}`}
                            onClick={() =>
                              downloadCertificate(
                                course.certificateCode,
                                course.title
                              )
                            }
                            className={`btn ${style.CourseBtn} d-block    `}
                          >
                            {t("Download_certificate")}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <>
          {flagNoData ? (
            <div className="  fs-2  text-center alert alert-warning text-dark m-3 ">
              {t("CourseDetails_not_found")}
            </div>
          ) : (
            <Spinner />
          )}
        </>
      )}
    </section>
  );
};

export default MyProfileCourses;
