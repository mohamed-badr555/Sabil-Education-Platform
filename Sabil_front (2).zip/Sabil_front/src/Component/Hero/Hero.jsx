import React, { useContext } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { Autoplay, Navigation, Pagination } from "swiper/modules";
import { Scrollbar } from "swiper/modules";
import style from "./Hero.module.css";
import { Link } from "react-router-dom";
import { IsMobileContext } from "../../Context/isMobileContext";
import { useTranslation } from "react-i18next";
import { authContext } from "../../Context/authContext";

/**
 * 
 "ads": [
            {
                "image": "https://cdn.izitechs.com/hosoun/images/home/banner.png",
                "link": "https://hosoun.com",
                "description": "this is a text that will appear in 'alt' of the image"
            },
            
        ],
  "subAds": [
            {
                "image": "https://cdn.izitechs.com/hosoun/images/home/sub-ad.png",
                "link": "https://hosoun.com",
                "description": "this is a text that will appear in 'alt' of the image"
            },
         
        ],
 */
const Hero = ({ ads, subAds }) => {
  const { isMobile } = useContext(IsMobileContext);
  const { isRegistered } = useContext(authContext);
  const { t, i18n } = useTranslation();

  // const subAdsStat = [
  //   {
  //     image: subAdsImage,
  //     link: "https://hosoun.com",
  //     description: "this is a text that will appear in 'alt' of the image",
  //   },
  //   {
  //     image: subAdsImage,
  //     link: "https://hosoun.com",
  //     description: "this is a text that will appear in 'alt' of the image",
  //   },
  //   {
  //     image: subAdsImage,
  //     link: "https://hosoun.com",
  //     description: "this is a text that will appear in 'alt' of the image",
  //   },
  //   {
  //     image: subAdsImage,
  //     link: "https://hosoun.com",
  //     description: "this is a text that will appear in 'alt' of the image",
  //   },
  // ];

  return (
    <>
      <div className={`container mt-1`}>
        <Swiper
          spaceBetween={10}
          loop={true}
          slidesPerView={1}
          centeredSlides={true}
          autoplay={{
            delay: 6000,
            disableOnInteraction: false,
          }}
          pagination={{
            clickable: true,
          }}
          navigation={true}
          modules={[Autoplay, Pagination, Navigation]}
          className={`${style.swiper} ${
            isMobile ? style.mobile_swiper : style.desktop_swiper
          }`}
        >
          {/* {[...Array(3)].map((_, index) => (
            <SwiperSlide key={index} className={style.swiper_slide}>
              <img loading="lazy" src={cover} alt={`slide ${index}`} />
            </SwiperSlide>
          ))} */}
          {ads.map((ad, index) => (
            <SwiperSlide key={index} className={style.swiper_slide}>
              <a href={ad.link} target="_blank">
                <img
                  loading="lazy"
                  src={ad.image}
                  alt={ad.description}
                  className={style.swiper_image}
                />
              </a>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
      
      <div className={`container mt-3 mb-4 ${style.Hero}`}>
        <Swiper
          slidesPerView="auto"
          spaceBetween={10}
          initialSlide={0}
          scrollbar={{
            draggable: true,
            hide: false,
          }}
          modules={[Scrollbar]}
          className="mySwiper overflow-hidden"
        >
          {
            /* {slides.map((_, index) => (
            <SwiperSlide key={`slide-${index}`} className="circular-slide">
              <Link to={``}>
                <img
                  loading="lazy"
                  src={image} 
                  alt={`slide ${index}`}
                  style={{ width: "100%", height: "auto" }}
                />
              </Link>
            </SwiperSlide> 
            */
            subAds.map((ad, index) => (
              <>
                <SwiperSlide
                  key={index}
                  className="circular-slide  overflow-hidden border border-3 border-success"
                >
                  <a href={ad.link} rel="noopener noreferrer" target="_blank">
                    <img
                      loading="lazy"
                      src={ad.image}
                      alt={ad.description}
                      className={style.swiper_image}
                    />
                  </a>
                </SwiperSlide>
              </>
            ))
          }
        </Swiper>
      </div>

      <div
        className={`my-4 text-center rounded ${style.register_now} container`}
      >
        {isRegistered ? (
          <Link
            to="/courses"
            className="d-flex align-items-center justify-content-center w-100"
          >
            <span
              className={`${style.arrow} d-flex align-items-center justify-content-center`}
            >
              {i18n.language === "ar" ? (
                <i className="fa-solid fs-6 fa-arrow-left"></i>
              ) : (
                <i className="fa-solid fs-6 fa-arrow-right"></i>
              )}
            </span>
            {t("discover_courses")}
          </Link>
        ) : (
          <Link
            to="/register"
            className="d-flex align-items-center justify-content-center w-100"
          >
            <span
              className={`${style.arrow} d-flex align-items-center justify-content-center`}
            >
              {i18n.language === "ar" ? (
                <i className="fa-solid fs-6 fa-arrow-left"></i>
              ) : (
                <i className="fa-solid fs-6 fa-arrow-right"></i>
              )}
            </span>
            {t("register_now")}
          </Link>
        )}
      </div>
    </>
  );
};

export default Hero;
