import React, { useContext, useEffect, useRef, useState } from "react";
import bootstrap from "bootstrap/dist/js/bootstrap.bundle.min.js";
import { Link, useLocation } from "react-router-dom";
import logo from "../../assets/Images/icon.png";
import { HashLink } from "react-router-hash-link";
import { useTranslation } from "react-i18next";
import style from "./Navbar.module.css";
import i18n from "../../i18n";
import { motion } from "framer-motion";
import { isThemeModeContext } from "../../Context/isThemeModeContext";
import NavbarTop from "../Ui/NavbarTop/NavbarTop";
import SubMenuNavbar from "../Ui/SubMenuNavbar/SubMenuNavbar";
import { basketContext } from "../../Context/basketContext";

const Navbar = () => {
  const [navbarCollapse, setNavbarCollapse] = useState();
  const location = useLocation();
  const [active, setActive] = useState("Home");
  const { t } = useTranslation();
  const navBar = useRef(null);
  const { isDarkMode } = useContext(isThemeModeContext);
  const { basket } = useContext(basketContext);

  const links = [
    {
      link: t("nav_link_Home"),
      active: "home",
      to: "/home",
    },
    {
      link: t("nav_link_courses"),
      active: "courses",
      to: "/courses",
    },

  ];

  const hideNavbar = () => {
    navbarCollapse.hide();
  };

  const toggleLanguage = async () => {
    let languageFlag = i18n.language == "en";
    languageFlag
      ? await i18n.changeLanguage("ar")
      : await i18n.changeLanguage("en");

    window.location.reload();
    // if (languageFlag) {
    //   document.body.style.direction = "rtl";
    //   document.title = "منصة حصون التعليمبة";
    // } else {
    //   document.body.style.direction = "ltr";
    //   document.title = "Hoson Education Platform";
    // }
  };
  useEffect(() => {
    // Manually collapse the navbar when a link is clicked
    setNavbarCollapse(
      new bootstrap.Collapse(
        document.getElementById("navbarSupportedContent"),
        {
          toggle: false,
        }
      )
    );
    // // Add padding to the body to prevent the content from being hidden behind the navbar when the page is scrolled
    // if (!isMobile) {
    //   document.body.style.paddingTop = navBar.current.clientHeight + "px";
    // } else {
    //   document.body.style.paddingTop = "0px";
    // }
    // return () => {
    //   document.body.style.paddingTop = "0px";
    // };
  }, []);

  useEffect(() => {
    // Function to update padding and CSS variable
    const updatePadding = () => {
      if (navBar.current) {
        const paddingTop = navBar.current.clientHeight + "px";
        document.getElementById("root").style.paddingTop = paddingTop;
        document.documentElement.style.setProperty(
          "--navbar-height",
          paddingTop
        );
      }
    };

    // Initial update
    updatePadding();

    // Add resize event listener
    window.addEventListener("resize", updatePadding);

    // Cleanup
    return () => {
      window.removeEventListener("resize", updatePadding);
      document.getElementById("root").style.paddingTop = "0px";
      document.documentElement.style.setProperty("--navbar-height", "0px");
    };
  }, []);

  useEffect(() => {
    // First handle the pathname-based active state
    const path = location.pathname;
    const currentPath = path.substring(1);

    if (currentPath === "") {
      setActive("home");
    } else {
      const pathSegment = currentPath.split("/")[0].toLowerCase();
      setActive(pathSegment);
    }

    // Then set up the observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(entry.target.id);
          }
        });
      },
      { threshold: 0.5 }
    ); // You can adjust threshold as needed

    // Observe all sections
    document.querySelectorAll("section[id]").forEach((section) => {
      observer.observe(section);
    });

    // Cleanup
    return () => {
      document.querySelectorAll("section[id]").forEach((section) => {
        observer.unobserve(section);
      });
    };
  }, [location.pathname]); // Add location as dependency

  return (
    <>
      <nav
        id="navBarMain"
        className={
          "navbar lead navbar-expand-lg  fixed-top pt-0 shadow flex-column " +
          style["navbar"]
        }
        data-bs-theme={isDarkMode ? "dark" : "light"}
        ref={navBar}
      >
  
        <NavbarTop />
        <div className="container d-flex justify-content-between flex-nowrap   ">
          <HashLink
            className="navbar-brand  py-3 rounded-3 overflow-hidden"
            to="/"
          >
            <motion.img
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              src={logo}
              style={{ width: "75px" }}
              alt="logo website "
            />
          </HashLink>

          <button
            className="navbar-toggler"
            type="button"
            onClick={() => {
              navbarCollapse.toggle();
            }}
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div
            className={"collapse navbar-collapse  " + style["list-links"]}
            id="navbarSupportedContent"
          >
            <div />
            <ul className="navbar-nav gap-2 ">
              {links.map((link, idx) => (
                <motion.li
                  initial={{ opacity: 0, y: -100 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                  key={idx}
                  className="nav-item "
                >
                  <Link
                    className={
                      "nav-link " +
                      (link.active === active ? style["selected"] : "")
                    }
                    to={link.to}
                    onClick={hideNavbar}
                  >
                    {link.link}
                  </Link>
                </motion.li>
              ))}
            </ul>
            <motion.ul
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="navbar-nav gap-2  d-flex justify-content-center align-items-center"
            >
              <li className={style.cart}>
                <Link to="/cart">
                  <i className="fa-solid fa-cart-shopping"></i>{" "}
                </Link>
                <span className={style.cartCount}>
                  {basket ? basket.items.length : 0}
                </span>
              </li>

              <SubMenuNavbar />
              <li>
                <button
                  className={" btn-web btn-web-primary " + style.langButton}
                  onClick={toggleLanguage}
                >
                  {t("nav_lang")}

                  <i className="fa-solid fa-globe mx-2"></i>
                </button>
              </li>
            </motion.ul>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
