import React, { useContext, useEffect, useState } from "react";
import Heading from "../Heading/Heading";
import { useTranslation } from "react-i18next";
import style from "./MyProfileTransaction.module.css";
import { authContext } from "../../Context/authContext";
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../Ui/Spinner/Spinner";

const MyProfileTransaction = () => {
  const { t, i18n } = useTranslation();
  const [flagNoData, setNoData] = useState(false);
  const [orderhistory, setOrderHistory] = useState(null);
  const { token } = useContext(authContext);

  const formatPrice = (price, currency) => {
    return `${Number(price).toLocaleString("ar-EG", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })} ${currency}`;
  };

  const getMyTranscation = async () => {
    try {
      setNoData(false);
      setOrderHistory(null);
      let { data } = await ApiManager.getTheHistoryOfOrders(token);
      if (data.data && data.data.length !== 0) {
        setOrderHistory(data.data);
        setNoData(false);
      } else {
        setOrderHistory(null);
        setNoData(true);
      }
    } catch (error) {
      setNoData(true);
    }
  };

  const getPaymentMethodText = (method) => {
    switch (method) {
      case 2:
        return t("Visa-Mastercard");
      case 3:
        return t("Fawry");
      case 4:
        return t("MobileWallets");
    }
  };
  useEffect(() => {
    getMyTranscation();
  }, []);

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString(i18n.language, {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getStatusClass = (status) => {
    switch (status.toLowerCase()) {
      case "completed":
        return style.statusCompleted;
      case "pending":
        return style.statusPending;
      case "failed":
        return style.statusFailed;
      default:
        return "";
    }
  };

  return (
    <section className="overflow-hidden">
      <Heading title={t("MyTranscation")} />
      {orderhistory ? (
        <div className={`container my-5`}>
          <div className={`mx-md-3 ${style.content} rounded`}>
            <div className={style.scrollbar}>
              <table className={style.table}>
                <thead>
                  <tr className={`${style.tableH}`}>
                    <th>{t("nameCourse")}</th>
                    <th>{t("datePay")}</th>
                    <th>{t("dateComplete")}</th>
                    <th>{t("wayPay")}</th>
                    <th>{t("itemPrice")}</th>
                    <th>
                      <div>{t("Total_price")}</div>
                      {/* <div className={style.subHeader}>{t("afterDiscount")}</div> */}
                    </th>
                    <th>{t("paystatus")}</th>
                  </tr>
                </thead>
                <tbody>
                  {orderhistory.map((order, index) => (
                    <tr key={index}>
                      <td>
                        {order.items.map((item, i) => (
                          <div key={i} className={style.itemName}>
                            <div>
                              {item.name}{" "}
                              {item.quantity > 1 && `(${item.quantity})`}
                            </div>
                            <div className={style.itemPrice}>
                              {formatPrice(item.total, order.currency)}
                            </div>
                          </div>
                        ))}
                      </td>
                      <td>{formatDate(order.created)}</td>
                      <td>{formatDate(order.lastUpdated)}</td>
                      <td>{getPaymentMethodText(order.paymentMethod)}</td>
                      <td>
                        {order.items.map((item, i) => (
                          <div key={i} className={style.itemPrice}>
                            {formatPrice(item.price, order.currency)}
                          </div>
                        ))}
                      </td>
                      <td>
                        <div className={style.totalPrices}>
                          <div className={style.originalPrice}>
                            {formatPrice(order.totalPrice, order.currency)}
                          </div>
                          <div className={style.discountedPrice}>
                            {formatPrice(
                              order.totalPriceAfterDiscount,
                              order.currency
                            )}
                          </div>
                        </div>
                      </td>
                      <td>
                        <div
                          className={`${style.btnStatus} ${getStatusClass(
                            order.status
                          )}`}
                        >
                          {t(order.status)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <>
          {flagNoData ? (
            <div className="container flex-grow-1 mt-3 d-flex justify-content-center align-items-center flex-column">
              <h3 className="text-center alert alert-warning text-dark w-100">
                {t("NoOrdersyet")}
              </h3>
            </div>
          ) : (
            <Spinner />
          )}
        </>
      )}
    </section>
  );
};
export default MyProfileTransaction;
