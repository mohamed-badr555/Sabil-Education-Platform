import { Suspense, lazy, useEffect } from "react";
import i18n from "./i18n";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
// Context
import AuthProvider from "./Context/authContext";
import IsThemeModeProvider from "./Context/isThemeModeContext";
// import HomeContentProvider from "./Context/homeContentContext";
// import IsMobileProvider from "./Context/isMobileContext";
// import BasketProvider from "./Context/basketContext";
const HomeContentProvider = lazy(() => import("./Context/homeContentContext"));
const IsMobileProvider = lazy(() => import("./Context/isMobileContext"));
const BasketProvider = lazy(() => import("./Context/basketContext"));

//Component
import RoutLayout from "./Component/RoutLayout/RoutLayout";
const Home = lazy(() => import("./Pages/Home/Home"));
const About = lazy(() => import("./Pages/About/About.jsx"));


const Courses = lazy(() => import("./Component/Courses/Courses.jsx"));

const Error404 = lazy(() => import("./Component/Error404/Error404.jsx"));

const Cart = lazy(() => import("./Pages/Cart/Cart.jsx"));
const MyProfile = lazy(() => import("./Component/MyProfile/MyProfile.jsx"));
const MyProfileCourses = lazy(() =>
  import("./Component/MyProfileCourese/MyProfileCourses.jsx")
);



const ChangeMainInfo = lazy(() =>
  import("./Component/changeMainInfo/ChangeMainInfo.jsx")
);
const ChangePassword = lazy(() =>
  import("./Component/changePassword/ChangePassword.jsx")
);
const ChangeEmail = lazy(() =>
  import("./Component/changeEmail/ChangeEmail.jsx")
);

const CourseDetails = lazy(() =>
  import("./Component/CourseDetails/CourseDetails.jsx")
);

const CourseContent = lazy(() =>
  import("./Component/CourseContent/CourseContent.jsx")
);
const ContentCourseRegistered = lazy(() =>
  import("./Component/ContentCouresRegistered/ContentCourseRegistered.jsx")
);
const InformationCourseContent = lazy(() =>
  import("./Component/InformationCourseContent/InformationCourseContent.jsx")
);

import Spinner from "./Component/Ui/Spinner/Spinner.jsx";




const Login = lazy(() => import("./Pages/Login/Login"));
const Register = lazy(() => import("./Pages/Register/Register"));
const EmailConfirmOtp = lazy(() =>
  import("./Pages/EmailConfirmOtp/EmailConfirmOtp")
);
const ProtectedRoute = lazy(() =>
  import("./Component/ProtectedRoute/ProtectedRoute")
);
const InverseProtectedRoute = lazy(() =>
  import("./Component/InverseProtectedRoute/InverseProtectedRoute")
);
const ForgetPasswordEmail = lazy(() =>
  import("./Pages/ForgetPasswordEmail/ForgetPasswordEmail")
);
const ForgetPasswordConfirmOtp = lazy(() =>
  import("./Pages/ForgetPasswordConfirmOtp/ForgetPasswordConfirmOtp")
);
const ForgetPasswordResetPass = lazy(() =>
  import("./Pages/ForgetPasswordResetPass/ForgetPasswordResetPass")
);
function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <RoutLayout />,
      children: [
        //home
        {
          path: "/",
          element: (
            <Suspense fallback={<Spinner />}>
              <Home />
            </Suspense>
          ),
        },
        {
          path: "/home",
          element: (
            <Suspense fallback={<Spinner />}>
              <Home />
            </Suspense>
          ),
        },
        // About
        {
          path: "/about",
          element: (
            <Suspense fallback={<Spinner />}>
              <About />
            </Suspense>
          ),
        },
  
        //Courses
        {
          path: "/courses",
          element: (
            <Suspense fallback={<Spinner />}>
              <Courses />
            </Suspense>
          ),
        },
        {
          path: "/courses/:courseId",
          element: (
            <Suspense fallback={<Spinner />}>
              <CourseDetails />
            </Suspense>
          ),
        },
        {
          path: "/courses/:courseId/content",
          element: (
            <Suspense fallback={<Spinner />}>
              <ProtectedRoute>
                <CourseContent />
              </ProtectedRoute>
            </Suspense>
          ),
          children: [
            {
              index: true,
              element: (
                <Suspense fallback={<Spinner />}>
                  <ContentCourseRegistered />
                </Suspense>
              ),
            },
            {
              path: "courseInformation",
              element: (
                <Suspense fallback={<Spinner />}>
                  <InformationCourseContent />
                </Suspense>
              ),
            },
          ],
        },

        //Cart
        {
          path: "/cart",
          element: (
            <Suspense fallback={<Spinner />}>
              <Cart />
            </Suspense>
          ),
        },

        //Profile
        {
          path: "/profile",
          element: (
            <Suspense fallback={<Spinner />}>
              <ProtectedRoute>
                <MyProfile />
              </ProtectedRoute>
            </Suspense>
          ), //page
          children: [
            {
              index: true,
              element: (
                <Suspense fallback={<Spinner />}>
                  <ChangeMainInfo />
                </Suspense>
              ), //sub rout
            },
            {
              path: "changePassword",
              element: (
                <Suspense fallback={<Spinner />}>
                  <ChangePassword />
                </Suspense>
              ),
            },
            {
              path: "changeEmail",
              element: (
                <Suspense fallback={<Spinner />}>
                  <ChangeEmail />
                </Suspense>
              ),
            },
          ],
        },
        {
          path: "/profile/myCourses",
          element: (
            <Suspense fallback={<Spinner />}>
              <ProtectedRoute>
                <MyProfileCourses />
              </ProtectedRoute>
            </Suspense>
          ),
        },

        //Login and Register
        {
          path: "/login",
          element: (
            <Suspense fallback={<Spinner />}>
              <InverseProtectedRoute>
                <Login />
              </InverseProtectedRoute>
            </Suspense>
          ),
        },
        {
          path: "/register",
          element: (
            <Suspense fallback={<Spinner />}>
              <InverseProtectedRoute>
                <Register />
              </InverseProtectedRoute>
            </Suspense>
          ),
        },
        {
          path: "/forget-password-email",
          element: (
            <Suspense fallback={<Spinner />}>
              <InverseProtectedRoute>
                <ForgetPasswordEmail />
              </InverseProtectedRoute>
            </Suspense>
          ),
        },
        {
          path: "/forget-password-otp",
          element: (
            <Suspense fallback={<Spinner />}>
              <InverseProtectedRoute>
                <ForgetPasswordConfirmOtp />
              </InverseProtectedRoute>
            </Suspense>
          ),
        },
        {
          path: "/forget-password-reset",
          element: (
            <Suspense fallback={<Spinner />}>
              <InverseProtectedRoute>
                <ForgetPasswordResetPass />
              </InverseProtectedRoute>
            </Suspense>
          ),
        },
        {
          path: "/EmailConfirmOtp",
          element: (
            <Suspense fallback={<Spinner />}>
              <EmailConfirmOtp />
            </Suspense>
          ),
        },
      ],
      errorElement: <Error404 />,
    },


  ]);

  useEffect(() => {
    // this code is for the language direction
    const i18nextLng = localStorage.getItem("i18nextLng") || "ar";
    i18n.changeLanguage(i18nextLng);
    if (i18nextLng === "ar") {
      document.body.dir = "rtl";
      document.documentElement.lang = "ar";
      // document.title = "منصة حصون التعليمية";
    } else {
      document.body.dir = "ltr";
      document.documentElement.lang = "en";
      // document.title = "Hoson Platform";
    }
  }, []);

  return (
    <IsThemeModeProvider>
      <AuthProvider>
        <IsMobileProvider>
          <HomeContentProvider>
            <BasketProvider>
              <RouterProvider router={router} />
            </BasketProvider>
          </HomeContentProvider>
        </IsMobileProvider>
      </AuthProvider>
    </IsThemeModeProvider>
  );
}

export default App;
/**
 * online plans responsive
 * share button working in meta tag
 * video player < responsive>
 * global meta tag
 * enhance location
 * chat
 * translate this part         title: "درس مقفل",
 * image upload >>Done
 * subMenueNavbar Enhance >> Done
 * forget password >>Done
 * Register >>Done
 * edit Profile >>Done
 * enhance disabled input >> Done
 * talk to mezar about ABOUT >>Done
 * font in pre >>Done
 */
