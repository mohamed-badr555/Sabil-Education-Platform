import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
//link fontAwesome
import "@fortawesome/fontawesome-free/css/all.min.css";
//link bootstrap
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
//link swiper we use in more than one place
import "swiper/css";
import "swiper/css/navigation";
import App from "./App.jsx";
// link main style
import "./index.css";
import { HelmetProvider } from "react-helmet-async";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <HelmetProvider>
      <App />
    </HelmetProvider>
  </StrictMode>
);
