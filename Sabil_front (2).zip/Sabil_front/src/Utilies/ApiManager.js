import axios from "axios";
import { countries } from "./data";
import i18n from "../i18n";
const baseUrl = "https://api.hosoun.com";
const baseUrl2 = "https://localhost:7267/api";

const DEFAULT_COUNTRY_ID = 141;
const TOKENS = ["fae0f9bafdbcd0", "4875379fa81387", "df8c47fc1c5926"];

// Function to fetch user country
(async function fetchUserCountry() {
  try {
    const storedData = localStorage.getItem("userCountryData");
    if (storedData) {
      const { timestamp } = JSON.parse(storedData);
      if (new Date().getTime() - timestamp < 48 * 60 * 60 * 1000) {
        // Using cached country data
        return;
      }
    }

    let response;
    try {
      response = await axios.get("https://ipinfo.io/json");
    } catch (error) {
      console.warn("Direct request failed, trying with tokens...");
      for (const token of TOKENS) {
        try {
          response = await axios.get(`https://ipinfo.io/json?token=${token}`);
          if (response.data) break; // Break loop if request succeeds
        } catch (error) {
          console.warn(`Token ${token} failed.`);
        }
      }
    }

    const countryCode = response?.data?.country;
    const country = countries.find((c) => c.Code === countryCode);
    const countryId = country ? country.value : DEFAULT_COUNTRY_ID;

    localStorage.setItem(
      "userCountryData",
      JSON.stringify({
        countryId,
        timestamp: new Date().getTime(),
      })
    );
  } catch (error) {
    console.error("Error fetching user country:", error);
    localStorage.setItem(
      "userCountryData",
      JSON.stringify({
        countryId: DEFAULT_COUNTRY_ID,
        timestamp: new Date().getTime(),
      })
    );
  }
})();

const getHeaders = (token) => {
  const storedData = localStorage.getItem("userCountryData");
  const countryId = storedData
    ? JSON.parse(storedData).countryId
    : DEFAULT_COUNTRY_ID;

  return {
    "Content-Type": "application/json",
    Authorization: token ? `Bearer ${token}` : undefined,
    "X-Country-Id": countryId,
    XLanguage: i18n.language,
  };
};
export default class ApiManager {
  /************************ Profile Apis ************************ */
  // Authorized services Apis
  // profile Apis <-- updateProfile, getProfile, updateEmail, checkIfSessionValid,  -->
  /**
   * Update Profile
   * @param {object} user
   * @param {string} token
   * @returns {object} response
   *
   */
  static async updateProfile(user, token) {
    const axiosResult = await axios.put(
      baseUrl + "/accounts/update-profile",
      user,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * @param {string} token
   * @param {File} image
   * @returns {object}
   */
  static async updateImage(token, image) {
    const formdata = new FormData();

    formdata.append("image", image);
    const axiosResult = await axios.put(
      baseUrl + "/accounts/update-profile-image",
      formdata,
      {
        headers: {
          ...getHeaders(token),
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return axiosResult;
  }

  /**
   * Get Profile
   * @param {string} token
   * @returns {object} response
   */
  static async getProfile(token) {
    const axiosResult = await axios.get(`${baseUrl}/auth/current`, {
      headers: getHeaders(token),
    });
    return axiosResult;
  }
  /**
   * update Email
   * @param {string} email
   * @param {string} token
   * @returns {object} response
   */
  static async updateEmail(email, token) {
    const axiosResult = await axios.post(
      baseUrl + `/auth/change-email?email=${email}`,
      {},
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * check if session is still valid
   * @param {string} token
   */
  static async checkIfSessionValid(token) {
    const axiosResult = await axios.post(
      baseUrl + "/auth/validate",
      {},
      {
        headers: getHeaders(token),
      }
    );

    return axiosResult;
  }

  /**
   * get user Book
   * @param {string} token
   * @returns
   */
  static async GetMyCourses(token) {
    const axiosResult = await axios.get(baseUrl + "/courses/mine", {
      headers: getHeaders(token), // Correct usage in axios
    });

    return axiosResult;
  }



  /********************Login Register Page****************************/
  // login Apis <-- Logout, Login, Register, sendOtp, otpConfirm, forgotPasswordSendOtpToEmail, confirmOtpForResetPassword, resetPassword -->

  /**
   * log out user
   *
   * @param {string} token
   * @returns {object} response
   */
  static async logOut(token) {
    const axiosResult = await axios.post(
      baseUrl + "/auth/logout",
      {},
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * log in user
   * @param {object} user
   * @returns {object} response
   */
  static async login(user) {
    const axiosResult = await axios.post(baseUrl + "/auth/login", user, {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * register user
   * @param {object} user
   * @returns {object} response
   *
   */

  static async register(user) {
    const axiosResult = await axios.post(baseUrl + "/auth/register", user, {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * Otp send confirmation
   * @param {string} token
   * @returns {object} response
   */
  static async sendOtp(token) {
    const axiosResult = await axios.post(
      baseUrl + "/auth/SendOTPConfirmAccount",
      {},
      {
        headers: getHeaders(token),
      }
    );

    return axiosResult;
  }
  /**
   * Otp Confirm
   * @param {object} user
   * @returns {object} response
   */
  static async otpConfirm(otp, token) {
    const axiosResult = await axios.post(
      baseUrl + `/auth/ConfirmAccountOTP?otp=${otp}`,
      {},
      { headers: getHeaders(token) }
    );
    return axiosResult;
  }
  /**
   * send email to send reset password otp to user
   * @param {string} email
   * @returns {object} response
   *
   */
  static async forgotPasswordSendOtpToEmail(email) {
    const axiosResult = await axios.post(
      baseUrl + `/auth/SendOTPResetPassword?email=${email}`,
      {},
      {
        headers: getHeaders(),
      }
    );

    return axiosResult;
  }
  /**
   * confirm otp for reset password
   * @param {string} otp
   * @param {string} email
   * @returns {object} response
   */
  static async confirmOtpForResetPassword(otp, email) {
    const axiosResult = await axios.post(
      baseUrl + `/auth/ConfirmResetPasswordOTP?OTP=${otp}&email=${email}`,
      {},
      {
        headers: getHeaders(),
      }
    );

    return axiosResult;
  }
  /**
   * reset password
   * @param {object} data
   * @returns {object} response
   */
  static async resetPassword(email, password, token) {
    const data = {
      email: email,
      newPassword: password,
      token: token,
    };

    const axiosResult = await axios.post(
      baseUrl + `/auth/ResetPassword`,
      data,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * update password
   * @param {object} password
   * @param {string} token
   */
  static async updatePassword(password, token) {
    const axiosResult = await axios.post(
      baseUrl + `/auth/change-password`,
      password,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }

  

  /********************Cart Page****************************/
  // payment Api <-- getPaymentMethods,  -->
  /**
   * get payment methods
   * @returns {object} response
   */
  static async getPaymentMethods() {
    const axiosResult = await axios.get(baseUrl + "/cart/payment-methods", {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * create a payment
   * @param {object} data
   * @param {string} token
   * @returns {object} response
   *
   */
  static async createPayment(data, token) {
    const axiosResult = await axios.post(baseUrl + "/orders", data, {
      headers: getHeaders(token),
    });
    return axiosResult;
  }

  // unAuthorized services Api <-- Home , contactUs, getAllTeachers, getTeacherProfile, getAllBooksCategories, getAllBooks, getAllArticles, getArticleDetails, getAllJobs, getJobDetails, applyToJob-->
  /********************Home Page****************************/
  // Home Page <-- Get Home Data, Contact Us -->
  /**
   * get home data
   * @returns {object} response
   */
  static async getHomeData() {
    const axiosResult = await axios.get(baseUrl + "/home", {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * get About Content
   * @returns
   */
  static async getAboutData() {
    const axiosResult = await axios.get(baseUrl + "/home/about-platform", {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * Contact us
   * @param {object} data
   * @returns {object} response
   *
   */
  static async contactUs(data) {
    const config = {
      headers: getHeaders(),
    };
    const axiosResult = await axios.post(baseUrl + "/contact-us", data, config);

    return axiosResult;
  }
  /********************Basket Page****************************/
  // Basket Apis <-- Open Basket, get Basket Data, Update Basket, Deconste Basket -->
  /**
   * Open Basket
   * @returns {object} response
   */
  static async openBasket() {
    const axiosResult = await axios.get(baseUrl + "/cart", {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * get basket data
   * @param {string} basketId
   * @returns {object} response
   */
  static async getBasketData(basketId, token) {
    const axiosResult = await axios.get(baseUrl + "/cart/" + basketId, {
      headers: getHeaders(token),
    });
    return axiosResult;
  }
  /**
   * @param {string} basketId
   * @param {object} basket
   * @returns {object} response
   */
  static async updateBasket(basketId, basket) {
    const axiosResult = await axios.post(
      baseUrl + "/cart/" + basketId,
      basket,
      {
        headers: getHeaders(),
      }
    );
    return axiosResult;
  }
  /**
   * deconste basket
   * @param {string} basketId
   * @returns {object} response
   * */
  static async deleteBasket(basketId) {
    const axiosResult = await axios.delete(baseUrl + "/cart/" + basketId, {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   *
   * @param {string} basketId
   * @param {string} couponCode
   * @returns
   */
  static async addCoupon(basketId, couponCode) {
    const axiosResult = await axios.post(
      baseUrl + "/cart/coupons/" + basketId + "/" + couponCode,
      {},
      {
        headers: getHeaders(),
      }
    );
    return axiosResult;
  }
  /**
   * @param {string} Type
   * @param {string} itemId
   * @param {string} token
   * @returns {object} response
   */
  static async buyFreeItem(token, Type, itemId) {
    const raw = JSON.stringify({
      ItemId: itemId,
      Type: Type,
    });
    const axiosResult = await axios.post(baseUrl + "/orders/free-item", raw, {
      headers: getHeaders(token),
    });
    return axiosResult;
  }




  /****************** Course Pages **************** */
  // Course Apis <-- Get Popular Courses, Get Categories, Search Courses, getCourseDetails, MakeARate -->
  // /**
  //  * get Popular Courses
  //  * @returns {object} response
  //  */

  static async getPopularCourses() {
    const axiosResult = await axios.get(baseUrl2 + "/courses/popular", {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * get Popular Courses
   * @returns {object} response
   */

  static async getCategories() {
    // Change from baseUrl to baseUrl2 to use the local development API
    const axiosResult = await axios.get(baseUrl2 + "/courses/categories", {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * Search Courses
   * @param {string} param
   * @returns {object} response
   */
  static async searchCourses(param) {
    const axiosResult = await axios.get(baseUrl2 + "/courses" + param, {
      headers: getHeaders(),
    });
    return axiosResult;
  }
  /**
   * Search Courses
   * @param {string} param
   * @returns {object} response
   */
  static async getCourseDetails(courseId, token) {
    const response = await axios.get(`${baseUrl}/courses/${courseId}/details`, {
      headers: getHeaders(token),
    });
    return response;
  }
  /**
   * Make a rate
   *
   * @param {string} token
   * @returns {object} response
   */
  static async MakeARate(token, CoursePath, ratingData) {
    const axiosResult = await axios.post(
      baseUrl + `/courses/${CoursePath}/rate`,
      ratingData,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * get course content
   *
   * @param {string} CoursePath
   * @returns {object} response
   */
  static async GetContentCourse(token, CoursePath) {
    const response = await axios.get(
      `${baseUrl}/courses/${CoursePath}/content`,
      {
        headers: getHeaders(token),
      }
    );
    return response;
  }
  /**
   *
   * @param {string} token
   * @param {string} courseId
   * @param {string} unitvideoIndex
   * @param {string} videoIndex
   * @returns
   */
  static async GetVideoDetails(
    token,
    courseId,
    courseUnitOrderIndex,
    orderIndex
  ) {
    const response = await axios.get(
      `${baseUrl}/courses/${courseId}/units/${courseUnitOrderIndex}/videos/${orderIndex}`,
      {
        headers: getHeaders(token),
      }
    );
    return response;
  }
  /**
   * add comment
   *
   * */
  static async addComment(token, courseId, comment) {
    try {
      const response = await axios.post(
        `${baseUrl}/courses/${courseId}/comment`,
        comment, // The comment body
        {
          headers: getHeaders(token),
        }
      );
      return response;
    } catch (error) {
      console.error("API Error:", error.response?.data || error);
      throw error;
    }
  }
  /**
   * Delete comment
   *
   * */
  static async deleteComment(token, courseId, commentId) {
    try {
      const response = await axios.delete(
        `${baseUrl}/courses/${courseId}/comment/${commentId}`,
        {
          headers: getHeaders(token),
        }
      );
      return response;
    } catch (error) {
      console.error("API Error:", error.response?.data || error);
      throw error;
    }
  }
  /**
   *  Update comment
   *  @param {string} token
   *  @param {string} courseId
   *  @param {string} commentId
   **/
  static async updateComment(token, courseId, comment) {
    try {
      const response = await axios.put(
        `${baseUrl}/courses/${courseId}/comment`,
        comment, // The comment body
        {
          headers: getHeaders(token),
        }
      );
      return response;
    } catch (error) {
      console.error("API Error:", error.response?.data || error);
      throw error;
    }
  }
  /**
   *
   * @param {string} token
   * @param {string} coursePath
   * @returns {object} axiosResponse
   */
  static async completeCourseAndExportCertificate(token, coursePath) {
    const axiosResponse = await axios.post(
      `${baseUrl}/courses/${coursePath}/complete`,
      {},
      {
        headers: getHeaders(token),
      }
    );
    return axiosResponse;
  }

  /****************** Exam Pages **************** */
  // Exam Apis <--getAllExams, starExam , submitExam , getExamDetails, getExamAttempts -->
  /**
   * getAllExams
   * @param {string} token
   * @param {string} SubscriptionId
   * @returns {object} response
   */
  static async getAllExams(token, SubscriptionId) {
    const axiosResult = await axios.get(
      baseUrl + `/online-edu/${SubscriptionId}/exams`,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * starExam
   * @param {object} examObject
   * {"CoursePath", // required if ExamSource was 1,"SubscriptionPlanId": 5,// required if ExamSource wan not 1,"ExamSource": 2// required}
   * @param {string} token
   * @param {string} examId
   * @returns {object} response
   */
  static async starExam(token, examObject, examId) {
    let requestBody = {
      CoursePath:
        examObject.coursePath == undefined ? null : examObject.coursePath, // required if ExamSource was 1,
      SubscriptionPlanId:
        examObject.subscriptionPlanId == undefined
          ? null
          : Number(examObject.subscriptionPlanId), // required if ExamSource wan not 1,
      ExamSource: examObject.examSource, // required
    };
    const axiosResult = await axios.post(
      baseUrl + `/exams/${examId}/start`,
      requestBody,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * submitExam
   * @param {object} answerObject
   * @param {string} token
   * @param {string} examId
   * @param {string} attemptId
   * @returns {object} response
   */
  static async submitExam(token, answerObject, examId, attemptId) {
    const axiosResult = await axios.post(
      baseUrl + `/exams/${examId}/submit/${attemptId}`,
      answerObject,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * get Exam Details
   * @param {string} token
   * @param {string} attemptId
   * @returns {object} response
   */
  static async getExamDetails(token, attemptId) {
    const axiosResult = await axios.get(
      baseUrl + `/exams/attempts/${attemptId}`,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
  /**
   * get Exam Attempts
   * @param {string} token
   * @param {string} subscriptionPlanId
   * @param {string} examId
   * @returns {object} response
   */
  static async getExamAttempts(token, subscriptionPlanId, examId) {
    const axiosResult = await axios.get(
      baseUrl + `/online-edu/${subscriptionPlanId}/exam-attempts/${examId}`,
      {
        headers: getHeaders(token),
      }
    );
    return axiosResult;
  }
}
