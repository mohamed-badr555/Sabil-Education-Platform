import React, { useEffect, useState } from "react";
import style from "./Teachers.module.css";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import Heading from "../../Component/Heading/Heading.jsx";
import TeacherCard from "../../Component/TeacherCard/TeacherCard.jsx";
import ApiManager from "../../Utilies/ApiManager.js";
import Spinner from "../../Component/Ui/Spinner/Spinner.jsx";

const Teachers = () => {
  const { t } = useTranslation();
  const [teachers, setTeachers] = useState(null);
  const [flagNoData, setFlagNoData] = useState(false);
  const getTeachers = async (param = "") => {
    try {
      setTeachers(null);
      setFlagNoData(false);
      const { data } = await ApiManager.getAllTeachers(`?Search=${param}`);
      if (data.data && data.data.length !== 0) {
        setTeachers(data.data);
      } else {
        setFlagNoData(true);
        setTeachers(null);
      }
    } catch (error) {
      setFlagNoData(true);
    }
  };

  useEffect(() => {
    getTeachers();
  }, []);

  return (
    <section id="teachers" className=" overflow-hidden">
      <Heading title={t("teacher_title")} text={t("teacher_text")} />

      <div className={` container py-5 ${style.teach}`}>
        <div className={` text-center row  g-4 `}>
          {teachers ? (
            teachers.map((card, idx) => (
              <motion.div
                key={idx}
                className={`${style.teacherCard} col-md-4 col-lg-3 col-sm-6 col-6`}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: 0.1 * teachers.length,
                  delay: 0.1 * idx,
                }}
              >
                <TeacherCard card={card} />
              </motion.div>
            ))
          ) : (
            <>
              {flagNoData ? (
                <div className="container flex-grow-1 d-flex justify-content-center align-items-center flex-column">
                  <h3 className="text-center alert alert-warning text-dark w-100">
                    {t("teacher_not_found")}
                  </h3>
                </div>
              ) : (
                <>
                  <Spinner />
                </>
              )}
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default Teachers;
