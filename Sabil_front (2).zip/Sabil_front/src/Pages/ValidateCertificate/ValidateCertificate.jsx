import React, {  useState } from "react";
import Heading from "../../Component/Heading/Heading";
import { useTranslation } from "react-i18next";
import SearchInput from "../../Component/Ui/SearchInput/SearchInput";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import CertificateCard from "../../Component/CertificateCard/CertificateCard";
import ApiManager from "../../Utilies/ApiManager";

export default function ValidateCertificate() {
  const { t } = useTranslation();
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [certificate, setCertificate] = useState(null);
  const [flagNotFound, setFlagNotFound] = useState(false);
  const validateCertificate = async () => {
    setLoading(true);
    setCertificate(null);
    try {
      const { data } = await ApiManager.checkIfCertificateIsValid(code);
      if (data.code == 200) {
        setCertificate(data.data);
        setFlagNotFound(false);
      } else {
        setFlagNotFound(true);
        setCertificate(null);
      }
      setLoading(false);
    } catch (error) {
      setFlagNotFound(true);
      setCertificate(null);
      setLoading(false);
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (code.trim()) validateCertificate();
  };
  return (
    <section className="overflow-hidden">
      <Heading title={t("ValidateCertificates")} />
      <div className="container">
        <form className="row align-items-center" onSubmit={handleSubmit}>
          <div className="col-10">
            <SearchInput
              SearchAbout={t("ValidateCertificates")}
              setSearch={setCode}
            />
          </div>
          <div className="col-2 d-flex justify-content-center">
            <button className="btn-web btn-web-primary ">
              <i class="fa-solid fa-check"></i>{" "}
            </button>
          </div>
        </form>
        <div className="row justify-content-center my-2">
          {loading ? (
            <Spinner />
          ) : (
            <>
              {certificate ? (
                <CertificateCard certificate={certificate} />
              ) : flagNotFound ? (
                <h3 className="text-center">
                  {t("NoCertificateWithThisCode")}
                </h3>
              ) : (
                <></>
              )}
            </>
          )}
        </div>
      </div>
    </section>
  );
}
