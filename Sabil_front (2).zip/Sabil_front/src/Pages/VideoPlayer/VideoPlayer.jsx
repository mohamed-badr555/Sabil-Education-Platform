import { useState, useRef, useEffect, useContext } from "react";
import styles from "./videoPlayer.module.css";
import Swal from "sweetalert2";

import { authContext } from "../../Context/authContext";
import { useParams, useNavigate } from "react-router-dom";
import ApiManager from "../../Utilies/ApiManager";
import CustomPlayer from "../../Component/CustomPlayer/CustomPlayer";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import { useTranslation } from "react-i18next";
// import ExamForm from './ExamForm';
// import ApiManager from './../../Utilies/ApiManager';
import ExamForm from "../../Component/ExamForm/ExamForm";
const VideoPlayer = ({
  units,
  currentUnitIndex: initialUnitIndex,
  currentVideoIndex: initialVideoIndex,
  onVideoComplete,
  onExamComplete,
  lastAccessedVideoId,
  finalExamId,
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [videoDetails, setVideoDetails] = useState(null);
  const [currentUnitIndex, setCurrentUnitIndex] = useState(initialUnitIndex);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(initialVideoIndex);
  const playerRef = useRef(null);
  const containerRef = useRef(null);
  const lastVideoId =
    units[units.length - 1].videos[units[units.length - 1].videos.length - 1]
      .id;
  const {user, token } = useContext(authContext);
  const { courseId } = useParams();
  const { t, i18n } = useTranslation();
  const [toggleAnswer, setToggleAnswer] = useState({});
  const [openReplies, setOpenReplies] = useState({});
  const [newComment, setNewComment] = useState("");
  const [replyTexts, setReplyTexts] = useState({});
  const [openUnitId, setOpenUnitId] = useState(units[currentUnitIndex].id);
  const [editingCommentId, setEditingCommentId] = useState(null);
  const [editCommentText, setEditCommentText] = useState("");
  const navigate = useNavigate();
  const loadVideoDetails = async (unitIndex, videoIndex) => {
    try {
      // console.log("Hi");
      // console.log(unitIndex, videoIndex);
      // console.log(user);
      
      setIsLoading(true);
      const currentVideo = units[unitIndex].videos[videoIndex];
      // console.log(currentVideo);

      // Update current indices
      setCurrentUnitIndex(unitIndex);
      setCurrentVideoIndex(videoIndex);

      // Set initial video details from units data, always show video first
      setVideoDetails({
        ...currentVideo,
        examId: null, // Initially hide exam to show video first
      });

      if (currentVideo?.videoUrl) {
        const response = await ApiManager.GetVideoDetails(
          token,
          courseId,
          currentVideo.courseUnitOrderIndex,
          currentVideo.orderIndex
        );

        if (response.data?.data) {
          // Keep examId null to show video first
          setVideoDetails({
            ...response.data.data,
            examId: null, // Keep exam hidden until video ends
          });
        }
      } else {
        setIsLoading(false);
      }
    } catch {
      // Silently handle any errors
    } finally {
      setIsLoading(false);
    }
  };
  

  // Load initial video based on lastAccessedVideoId
  useEffect(() => {
    if (units) {
      let foundVideo = false;
      for (let i = 0; i < units.length; i++) {
        const videoIndex = units[i].videos.findIndex(
          (v) => v.id === lastAccessedVideoId
        );
        if (videoIndex !== -1) {
          setCurrentUnitIndex(i);
          setCurrentVideoIndex(videoIndex);
          loadVideoDetails(i, videoIndex);
          foundVideo = true;
          break;
        }
      }

      // If no lastAccessedVideoId or video not found, load first video
      if (!foundVideo) {
        loadVideoDetails(currentUnitIndex, currentVideoIndex);
      }
    }
    console.log(currentUnitIndex, currentVideoIndex);
  }, [units, lastAccessedVideoId]);
  // stop developer tools

  useEffect(() => {
    const preventDefault = (e) => {
      e.preventDefault();
    };
    const handleStopKeyDown = (e) => {
      // Prevent F12
      if (e.key === "F12") e.preventDefault();
      // Prevent Ctrl+Shift+I
      if (e.ctrlKey && e.shiftKey && e.key === "I") e.preventDefault();
      // Prevent Ctrl+Shift+J
      if (e.ctrlKey && e.shiftKey && e.key === "J") e.preventDefault();
      // Prevent Ctrl+U (view source)
      if (e.ctrlKey && e.key === "U") e.preventDefault();
    };
    // Prevent right click
    document.addEventListener("contextmenu", preventDefault);

    // Prevent keyboard shortcuts
    document.addEventListener("keydown", handleStopKeyDown);

    // Disable developer tools
    const intervalIndex = setInterval(() => {
      const devtools = /./;
      devtools.toString = function () {
        preventDevTools();
      };
    }, 1000);

    return () => {
      // Cleanup event listeners
      document.removeEventListener("contextmenu", preventDefault);
      document.removeEventListener("keydown", handleStopKeyDown);
      // Cleanup interval
      clearInterval(intervalIndex);
    };
  }, []);




  // Function to handle unauthorized access attempts
 
 
 
  const preventDevTools = () => {
    if (
      window.outerHeight - window.innerHeight > 200 ||
      window.outerWidth - window.innerWidth > 200
    ) {
      document.body.innerHTML = "Developer tools detected!";
    }
  };

  const handleReady = (player) => {
    
    playerRef.current = player;
    setIsLoading(false);
  };

  const handleVideoEnd = async () => {
    const currentVideo = units[currentUnitIndex].videos[currentVideoIndex];

    if (currentVideo.examId && currentVideo.id != lastVideoId) {
      setVideoDetails((prev) => ({
        ...prev,
        examId: currentVideo.examId,
        videoUrl: null,
      }));
      return;
    }

    // Calculate next video indices
    const nextUnitIndex =
      currentVideoIndex < units[currentUnitIndex].videos.length - 1
        ? currentUnitIndex
        : currentUnitIndex + 1;

    const nextVideoIndex =
      currentVideoIndex < units[currentUnitIndex].videos.length - 1
        ? currentVideoIndex + 1
        : 0;

    try {
      // First try to load next video
      const nextVideoResponse = await ApiManager.GetVideoDetails(
        token,
        courseId,
        units[nextUnitIndex].videos[nextVideoIndex].courseUnitOrderIndex,
        units[nextUnitIndex].videos[nextVideoIndex].orderIndex
      );

      if (nextVideoResponse.data?.data) {
        // If video loads successfully, update progress and move to next video
        await onVideoComplete(
          units[nextUnitIndex].videos[nextVideoIndex].courseUnitOrderIndex,
          units[nextUnitIndex].videos[nextVideoIndex].orderIndex
        );

        // Load the next video
        await loadVideoDetails(nextUnitIndex, nextVideoIndex);

        // Update course data
        await updateCourseData();
      }
    } catch (error) {
      // If loading next video fails, stay on current video
      console.error("Error loading next video:", error);
    }
  };

  const handleExamComplete = async () => {
    // if last video in course, swal you completed the course
    if (lastVideoId === units[currentUnitIndex].videos[currentVideoIndex].id) {
      await completeCourseAndExportCertificate(courseId);
      Swal.fire({
        title: t("Congratulations!"),
        text: t("You have completed the course!"),
        icon: "success",
        confirmButtonText: t("Ok"),
      }).then(() => {
        navigate("/profile/myCourses");
      });

      return;
    } else {
      await getNextVideo();
    }
  };
  const completeCourseAndExportCertificate = async (coursePath) => {
    try {
      const { data } = await ApiManager.completeCourseAndExportCertificate(
        token,
        coursePath
      );
    } catch (error) {
      console.error(error);
    }
  };
  const handelStartLastExam = async () => {
    setVideoDetails((prev) => ({
      ...prev,
      examId: finalExamId,
      videoUrl: null,
    }));
  };

  const cancelExam = async () => {
    if (lastVideoId === units[currentUnitIndex].videos[currentVideoIndex].id) {
      await completeCourseAndExportCertificate(courseId);
      Swal.fire({
        title: t("Congratulations!"),
        text: t("You have completed the course!"),
        icon: "success",
        confirmButtonText: t("Ok"),
      }).then(() => {
        navigate("/profile/myCourses");
      });
    } else {
      console.log("Hi");

      await getNextVideo();
    }
  };

  const getNextVideo = async () => {
    // Calculate next video indices
    const nextUnitIndex =
      currentVideoIndex < units[currentUnitIndex].videos.length - 1
        ? currentUnitIndex
        : currentUnitIndex + 1;

    const nextVideoIndex =
      currentVideoIndex < units[currentUnitIndex].videos.length - 1
        ? currentVideoIndex + 1
        : 0;

    try {
      // First try to load next video
      const nextVideoResponse = await ApiManager.GetVideoDetails(
        token,
        courseId,
        units[nextUnitIndex].videos[nextVideoIndex].courseUnitOrderIndex,
        units[nextUnitIndex].videos[nextVideoIndex].orderIndex
      );
      console.log(nextVideoResponse);

      if (nextVideoResponse.data?.data) {
        // If video loads successfully, update progress and move to next video
        await onVideoComplete(
          units[nextUnitIndex].videos[nextVideoIndex].courseUnitOrderIndex,
          units[nextUnitIndex].videos[nextVideoIndex].orderIndex
        );
        console.log(
          "nextVideoIndex",
          nextVideoIndex,
          "nextUnitIndex",
          nextUnitIndex
        );

        // Load the next video
        await loadVideoDetails(nextUnitIndex, nextVideoIndex);

        // Update course data
        await updateCourseData();
      }
    } catch (error) {
      // If loading next video fails, stay on current video
      console.error("Error loading next video:", error);
    }
  };
  const handlePlaylistItemClick = async (unitIndex, videoIndex) => {
    const video = units[unitIndex].videos[videoIndex];

    if (!video.videoUrl) {
      Swal.fire({
        icon: "warning",
        title: "درس مقفل",
        text: "هذا الدرس غير متاح حالياً",
        confirmButtonText: t("Ok"),
        confirmButtonColor: "var(--primary-color)",
        background: "var(--bg-color)",
        color: "var(--black-light-color)",
      });
      return;
    }

    try {
      setIsLoading(true);
      setCurrentUnitIndex(unitIndex);
      setCurrentVideoIndex(videoIndex);
      await loadVideoDetails(unitIndex, videoIndex);
    } catch (error) {
      console.error("Error changing video:", error);
      Swal.fire({
        title: t("Error"),
        text: t("ErrorComment"),
        icon: "error",
        confirmButtonText: t("Ok"),
        confirmButtonColor: "var(--primary-color)",
        background: "var(--bg-color)",
        color: "var(--black-light-color)",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddComment = async (parentCommentId = null) => {
    try {
      const commentText = parentCommentId
        ? replyTexts[parentCommentId]
        : newComment;

      if (!commentText?.trim()) {
        return; // Don't submit empty comments
      }

      const currentVideo = units[currentUnitIndex].videos[currentVideoIndex];

      const commentBody = {
        parentCommentId: parentCommentId, // This will be null for new comments
        videoOrderIndex: currentVideo.orderIndex,
        unitOrderIndex: currentVideo.courseUnitOrderIndex,
        comment: commentText.trim(),
      };

      const response = await ApiManager.addComment(
        token,
        courseId,
        commentBody
      );

      if (response.data?.code === 200) {
        // Clear input fields
        if (parentCommentId) {
          setReplyTexts((prev) => ({
            ...prev,
            [parentCommentId]: "",
          }));
          // Close reply input
          setToggleAnswer((prev) => ({
            ...prev,
            [parentCommentId]: false,
          }));
        } else {
          setNewComment("");
        }

        // Refresh video details to show new comment
        await loadVideoDetails(currentUnitIndex, currentVideoIndex);
      }
    } catch (error) {
      console.error("Error adding comment:", error);
      // Show error message to user
      Swal.fire({
        title: t("Error"),
        text: t("ErrorComment"),
        icon: "error",
        confirmButtonText: t("Ok"),
        confirmButtonColor: "var(--primary-color)",
        background: "var(--bg-color)",
        color: "var(--black-light-color)",
      });
    }
  };
  const handleDeleteComment = async (CommentId) => {
    try {
      const response = await ApiManager.deleteComment(
        token,
        courseId,
        CommentId
      );
      if (response.data?.code === 200) {
        // Refresh video details to show new comment
        await loadVideoDetails(currentUnitIndex, currentVideoIndex);
      }
    } catch (error) {
      console.error("Error deleting comment:", error);
      // Show error message to user
      Swal.fire({
        title: t("Error"),
        text: t("ErrorComment"),
        icon: "error",
        confirmButtonText: t("Ok"),
        confirmButtonColor: "var(--primary-color)",
        background: "var(--bg-color)",
        color: "var(--black-light-color)",
      });
    }
  };

  const handleAccordionClick = (unitId) => {
    setOpenUnitId((prevId) => (prevId === unitId ? null : unitId));
  };

  const handleUpdateComment = async (commentId, originalText) => {
    if (editingCommentId === commentId) {
      // Save the edit
      try {
        const currentVideo = units[currentUnitIndex].videos[currentVideoIndex];

        const commentBody = {
          commentId: commentId,
          videoOrderIndex: currentVideo.orderIndex,
          unitOrderIndex: currentVideo.courseUnitOrderIndex,
          comment: editCommentText.trim(),
        };

        const response = await ApiManager.updateComment(
          token,
          courseId,
          commentBody
        );

        if (response.data?.code === 200) {
          // Refresh video details to show updated comment
          await loadVideoDetails(currentUnitIndex, currentVideoIndex);
          // Clear editing state
          setEditingCommentId(null);
          setEditCommentText("");
        }
      } catch (error) {
        console.error("Error updating comment:", error);
        Swal.fire({
          title: "Error",
          text: t("ErrorComment"),
          icon: "error",
          confirmButtonText: t("Ok"),
          confirmButtonColor: "var(--primary-color)",
          background: "var(--bg-color)",
          color: "var(--black-light-color)",
        });
      }
    } else {
      // Start editing
      setEditingCommentId(commentId);
      setEditCommentText(originalText);
    }
  };

  return (
    <div ref={containerRef} className={styles.container + " "}>
      {true && (
        <div className={styles.playlistContainer + ""}>
          <div className={styles.playlist}>
            <h2 className={`${styles.headtitle} mb-4`}>{t("watchCourse")} </h2>

            <div className="accordion" id="courseAccordion">
              {units.map((unit, unitIndex) => (
                <div
                  className={`accordion-item ${styles.accordionItem}`}
                  key={unit.id}
                >
                  <h3 className="accordion-header">
                    <button
                      className={`accordion-button ${
                        openUnitId !== unit.id ? "collapsed" : ""
                      } ${styles.accordionButton}`}
                      type="button"
                      onClick={() => handleAccordionClick(unit.id)}
                    >
                      {unit.title.replace(">", "").replace("<", "")}
                    </button>
                  </h3>
                  <div
                    className={`accordion-collapse collapse ${
                      openUnitId === unit.id ? "show" : ""
                    }`}
                  >
                    <div className={`accordion-body ${styles.accordionBody}`}>
                      {unit.videos.map((video, videoIndex) => (
                        <div
                          key={video.id}
                          className={`${styles.playlistItem} 
                          ${
                            unitIndex === currentUnitIndex &&
                            videoIndex === currentVideoIndex
                              ? styles.active
                              : ""
                          } 
                    ${!video.videoUrl ? styles.locked : ""}`}
                          onClick={() =>
                            handlePlaylistItemClick(unitIndex, videoIndex)
                          }
                        >
                          <div className="d-flex align-items-center gap-2">
                            <div className={styles.videoInfo}>
                              <div className="d-flex justify-content-between align-items-center">
                                {/* Title and description on the right */}
                                <div>
                                  <h3>{video.title}</h3>
                                  <p className="mb-0">
                                    {video.description.replace(
                                      /<\/?[^>]+(>|$)/g,
                                      ""
                                    )}
                                  </p>
                                </div>

                                {/* Icons container on the left */}
                                <div className="d-flex align-items-center  gap-2">
                                  {video.examId && (
                                    <i
                                      className={`fa-solid fa-file-lines text-warning ${styles.examIcon}`}
                                    ></i>
                                  )}
                                  {!video.videoUrl && (
                                    <i
                                      className={`fas fa-lock  ${styles.lockIcon}`}
                                    ></i>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
              {lastVideoId == lastAccessedVideoId && (
                <button
                  className="btn-web btn-web-secondary w-100"
                  onClick={handelStartLastExam}
                >
                  {t("Exam.start the exam")}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      <div className={styles.mainContent}>
        {videoDetails?.examId ? (
          <ExamForm
            examId={videoDetails.examId}
            examSource={1}
            coursePath={courseId}
            token={token}
            doAfterFinishExam={handleExamComplete}
            cancelExam={cancelExam}
          />
        ) : (
          <>
            <div className={styles.playerWrapper}>
              {isLoading ? (
                <Spinner />
              ) : videoDetails?.videoUrl ? (
                <CustomPlayer
                  key={videoDetails.videoUrl}
                  videoId={videoDetails.videoUrl}
                  onReady={handleReady}
                  onEnded={handleVideoEnd}
                />
              ) : (
                <div className={styles.lockedMessage}>
                  <div>
                    <i className="fas fa-lock fa-2x mb-3"></i>
                    <h3>هذا الدرس غير متاح حالياً</h3>
                  </div>
                </div>
              )}
            </div>

            <div className={styles.commentsSection}>
              <div className="d-flex flex-column    mb-3">
                <h3 className={`${styles.askLesson}`}>
                  {" "}
                  {t("Asksinthislesson")}({videoDetails?.comments?.length || 0})
                </h3>
                <div className="row justify-content-between row-gap-2 flex-wrap align-items-center">
                  <input
                    type="text"
                    className={`${styles.askInputRep} col-md-10`}
                    placeholder={t("AddQuestion")}
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                  />
                  <button
                    className={`${styles.addQuestionBtn} col-md-2`}
                    onClick={() => handleAddComment(null)}
                  >
                    {t("Ask")}
                  </button>
                </div>
              </div>

              {/* Comments list */}
              <div className="">
                {isLoading ? (
                  <div className="text-center py-4">
                    <Spinner />
                  </div>
                ) : !videoDetails?.comments ||
                  videoDetails.comments.length === 0 ? (
                  <div className={`text-center py-4 `}>
                    <i className="far fa-comments fa-2x mb-3 "></i>
                    <p>{t("noCommentsYet")}</p>
                  </div>
                ) : (
                  videoDetails.comments.map((comment) => (
                    <div
                      key={comment.id}
                      className={`${styles.commentCard} mb-4`}
                    >
                      <div className="d-flex align-items-start gap-3">
                        {/* User Avatar */}
                        <div className={styles.avatarWrapper}>
                          <img
                            src={comment.profileImage}
                            alt={comment.user}
                            className={styles.avatar}
                          />
                        </div>

                        {/* Comment Content */}
                        <div className="flex-grow-1">
                          <div className="d-flex justify-content-between align-items-center mb-2">
                            <h6 className={styles.userName}>{comment.user}</h6>
                            <div>
                         { (user.id === comment.userId || user.roles.includes("Admin") ) ?<> 
                          <i
                                onClick={() =>
                                  handleUpdateComment(
                                    comment.id,
                                    comment.comment
                                  )
                                }
                                className="fa-solid text-warning mx-1 fa-pen-to-square"
                                style={{ cursor: "pointer" }}
                              ></i>
                              <i
                                onClick={() => handleDeleteComment(comment.id)}
                                className="fa-solid mx-1  text-danger fa-trash"
                                style={{ cursor: "pointer" }}
                              ></i> 
                         </>  : ""}
                              <small className={styles.commentTime}>
                                <i className="far fa-clock mx-1"></i>
                                {new Date(comment.time).toLocaleString(
                                  i18n.language,
                                  {
                                    weekday: "long",
                                    year: "numeric",
                                    month: "long",
                                    day: "numeric",
                                  }
                                )}
                              </small>
                            </div>
                          </div>
                          {editingCommentId === comment.id ? (
                            <div className="row justify-content-between row-gap-2 flex-wrap align-items-center">
                              <input
                                type="text"
                                className={`${styles.askInput} col-md-10`}
                                value={editCommentText}
                                onChange={(e) =>
                                  setEditCommentText(e.target.value)
                                }
                              />
                              <button
                                className={`${styles.addQuestionBtn} col-md-2`}
                                onClick={() => handleUpdateComment(comment.id)}
                              >
                                {t("Ask")}
                              </button>
                            </div>
                          ) : (
                            <p className={styles.commentText}>
                              {comment.comment}
                            </p>
                          )}

                          {/* Comment Actions */}
                          <div
                            className={`${styles.commentActions} d-flex align-items-center mt-2`}
                          >
                            <button
                              className={`${styles.actionBtn} d-flex align-items-center`}
                              onClick={() => {
                                // Close answer input if open
                                if (toggleAnswer[comment.id]) {
                                  setToggleAnswer((prev) => ({
                                    ...prev,
                                    [comment.id]: false,
                                  }));
                                }
                                // Toggle replies
                                setOpenReplies((prev) => ({
                                  ...prev,
                                  [comment.id]: !prev[comment.id],
                                }));
                              }}
                            >
                              <i className="fa-regular fa-comments mx-1 "></i>
                              {t("AnswersQuestion")}
                            </button>
                            <button
                              className={`${styles.actionBtn} d-flex align-items-center`}
                              onClick={() => {
                                // Close replies if open
                                if (openReplies[comment.id]) {
                                  setOpenReplies((prev) => ({
                                    ...prev,
                                    [comment.id]: false,
                                  }));
                                }
                                // Toggle answer input
                                setToggleAnswer((prev) => ({
                                  ...prev,
                                  [comment.id]: !prev[comment.id],
                                }));
                              }}
                            >
                              <i className="far fa-comment mx-1"></i>
                              {t("Answer")}
                            </button>
                          </div>

                          {/* Replies */}
                          {openReplies[comment.id] &&
                            comment.replies?.length > 0 && (
                              <div className={`${styles.replies} mt-3`}>
                                {comment.replies.map((reply) => (
                                  <div
                                    key={reply.id}
                                    className={`${styles.replyCard} mb-3`}
                                  >
                                    <div className="d-flex align-items-start gap-3">
                                      <div className={styles.avatarWrapper}>
                                        <img
                                          src={reply.profileImage}
                                          alt={reply.user}
                                          className={styles.avatarSmall}
                                        />
                                      </div>
                                      <div className="flex-grow-1">
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                          <h6 className={styles.userNameRep}>
                                            {reply.user}
                                          </h6>
                                          <div>
                                         { (user.id === comment.userId || user.roles.includes("Admin") ) &&
                                        <>
                                           <i
                                              onClick={() =>
                                                handleUpdateComment(
                                                  reply.id,
                                                  reply.comment
                                                )
                                              }
                                              className="fa-solid text-warning mx-1 fa-pen-to-square"
                                              style={{ cursor: "pointer" }}
                                            ></i>
                                            <i
                                              onClick={() =>
                                                handleDeleteComment(reply.id)
                                              }
                                              className="fa-solid mx-1 text-danger fa-trash "
                                              style={{ cursor: "pointer" }}
                                            ></i>
                                        </>}
                                            <small
                                              className={styles.commentTimeRep}
                                            >
                                              <i className="far fa-clock mx-1"></i>
                                              {new Date(
                                                reply.time
                                              ).toLocaleDateString("ar-EG")}
                                            </small>
                                          </div>
                                        </div>
                                        {editingCommentId === reply.id ? (
                                          <div className="row justify-content-between row-gap-2 px-2  flex-wrap align-items-center">
                                            <input
                                              type="text"
                                              className={`${styles.askInput} col-md-10 `}
                                              value={editCommentText}
                                              onChange={(e) =>
                                                setEditCommentText(
                                                  e.target.value
                                                )
                                              }
                                            />
                                            <button
                                              className={`${styles.addQuestionBtn} col-md-2 `}
                                              onClick={() =>
                                                handleUpdateComment(reply.id)
                                              }
                                            >
                                              {t("Answer")}
                                            </button>
                                          </div>
                                        ) : (
                                          <p className={styles.commentTextRep}>
                                            {reply.comment}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          {/* AnswerAbout Question */}
                          {toggleAnswer[comment.id] && (
                            <div
                              className={`row justify-content-between relative row-gap-2 flex-wrap align-items-center`}
                            >
                              <input
                                type="text"
                                className={`${styles.askInput} col-md-10`}
                                placeholder={t("AnswerAboutQuestion")}
                                value={replyTexts[comment.id] || ""}
                                onChange={(e) =>
                                  setReplyTexts((prev) => ({
                                    ...prev,
                                    [comment.id]: e.target.value,
                                  }))
                                }
                              />
                              <button
                                className={`${styles.addQuestionBtn} col-md-2`}
                                onClick={() => handleAddComment(comment.id)}
                              >
                                {t("Answer")}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default VideoPlayer;
