import React, { useEffect, useState } from "react";
import style from "./Books.module.css";
import Heading from "../../Component/Heading/Heading";
import { useTranslation } from "react-i18next";
import SearchInput from "../../Component/Ui/SearchInput/SearchInput";
import BookCard from "../../Component/BookCard/BookCard";
import { motion } from "framer-motion";
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";

const Books = () => {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSupCategory, setSelectedSupCategory] = useState("");
  const [search, setSearch] = useState("");
  const [books, setBooks] = useState(null);
  const [flagNoData, setFlagNoData] = useState(false);
  const [categories, setCategories] = useState(null);
  const { categoryId } = useParams();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const getCategories = async () => {
    try {
      const { data } = await ApiManager.getAllBooksCategories();
      setCategories(data.data);
    } catch (error) {
      console.error("Error fetching Categories:", error);
    }
  };
  const getBooks = async (param = "") => {
    try {
      setBooks(null);
      setFlagNoData(false);
      const { data } = await ApiManager.getAllBooks(param);
      if (data.data.data && data.data.data.length !== 0) {
        setBooks(data.data.data);
        setPageSize(data.data.pageSize);

        setTotalPages(Math.ceil(data.data.count / pageSize));
      } else {
        setFlagNoData(true);
        setBooks(null);
      }
    } catch (error) {
      setFlagNoData(true);
    }
  };
  useEffect(() => {
    getCategories();
    if (categoryId) {
      setSelectedCategory(categoryId);
    }
  }, []);

  useEffect(() => {
    getBooks(
      `?search=${search}&categoryId=${selectedCategory}&subCategoryId=${selectedSupCategory}&PageIndex=${currentPage}&PageSize=${pageSize}`
    );
  }, [selectedCategory, selectedSupCategory, search, currentPage]);

  // Get specializations based on selected department
  const getSubCategories = (categoryID) => {
    const category = categories.find(
      (category) => category.id === Number(categoryID)
    );

    return category && category.subCategories ? category.subCategories : [];
  };

  // Update specialization handler
  const handleSupCategoriesChange = (e) => {
    setSelectedSupCategory(e.target.value);
  };
  const getCategoryIdFromName = (categoryName) => {
    const category = categories.find(
      (category) => category.name === categoryName
    );
    return category ? category.id : null;
  };

  return (
    <section id="books" className="overflow-hidden">
      <Heading title={t("book_title")} />
      <div className="container">
        <SearchInput setSearch={setSearch} SearchAbout={t("searchAboutBook")} />
        <div className={`${style.selectContainer}`}>
          <div className={style.selectBox}>
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
              }}
              className="placeholder-glow"
            >
              <option value="">{t("option_department")}</option>
              {categories &&
                categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.title}
                  </option>
                ))}
            </select>
          </div>

          {selectedCategory&&
            <div className={style.selectBox}>
              <select
                disabled={!selectedCategory}
                value={selectedSupCategory}
                onChange={handleSupCategoriesChange}
              >
                <option value="">{t("option_special")}</option>
                {categories &&
                  getSubCategories(selectedCategory).map((subCategory) => (
                    <option key={subCategory.id} value={subCategory.id}>
                      {subCategory.title}
                    </option>
                  ))}
              </select>
            </div>
          }
        </div>

        {/* Add books display */}
        <div className={`row mb-5 `}>
          {books ? (
            <>
              {books.map((book, idx) => (
                <motion.div
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 * idx }}
                  key={idx}
                  className={"col-md-6 col-lg-4  "}
                >
                  <BookCard
                    card={book}
                    getCategoryIdFromName={getCategoryIdFromName}
                  />
                </motion.div>
              ))}
            </>
          ) : (
            <>
              {flagNoData ? (
                <div className="container flex-grow-1 d-flex justify-content-center align-items-center flex-column">
                  <h3 className="text-center alert alert-warning text-dark w-100">
                    {t("books_not_found")}
                  </h3>
                </div>
              ) : (
                <>
                  <Spinner />
                </>
              )}
            </>
          )}
          {/* {
            
          ))} */}
        </div>
        {/* pagination */}
        <nav aria-label="Page navigation">
          <ul className="pagination justify-content-center">
            <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
              <Link
                className={`${style.pageLink} page-link`}
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                to="#"
              >
                {t("PreviousNav")}
              </Link>
            </li>

            {[...Array(totalPages)].map((_, idx) => (
              <li
                key={idx}
                className={`page-item ${
                  currentPage === idx + 1 ? style.active : ""
                }`}
              >
                <Link
                  className="page-link"
                  onClick={() => setCurrentPage(idx + 1)}
                  to="#"
                >
                  {idx + 1}
                </Link>
              </li>
            ))}

            <li
              className={`page-item ${
                currentPage >= totalPages ? "disabled" : ""
              }`}
            >
              <Link
                className="page-link"
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                to="#"
              >
                {t("NextNav")}
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </section>
  );
};

export default Books;
