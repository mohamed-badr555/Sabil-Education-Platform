import React, { useEffect, useState } from "react";
import Heading from "../../Component/Heading/Heading";
import { useTranslation } from "react-i18next";
import SearchInput from "../../Component/Ui/SearchInput/SearchInput";
import { motion } from "framer-motion";
import ArticleCard from "../../Component/ArticleCard/ArticleCard";
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import { Link } from "react-router-dom";
import style from './Articles.module.css'

const Articles = () => {
  const [articles, setArticles] = useState(null);
  const [flagNoData, setFlagNoData] = useState(false);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize,setPageSize] = useState(10);

  const getArticles = async (param = "") => {
    try {
      setArticles(null);
      setFlagNoData(false);
      const { data } = await ApiManager.getArticles(
        `?Search=${param}&PageIndex=${currentPage}&PageSize=${pageSize}`
      );
      if (data.data.data && data.data.data.length !== 0) {
        setArticles(data.data.data);
        setPageSize(data.data.pageSize);
      
        setTotalPages(Math.ceil(data.data.count / pageSize));
      } else {
        setFlagNoData(true);
        setArticles(null);
      }
    } catch (error) {
      setFlagNoData(true);
    }
  };

  useEffect(() => {
    getArticles(search);
  }, [search, currentPage]);

  const { t } = useTranslation();
  return (
    <section id="articles" className="overflow-hidden  ">
      <Heading title={t("article_title")} />
      <div className={`container my-5 `}>
        <SearchInput
          SearchAbout={t("SearchAboutArticle")}
          setSearch={setSearch}
        />
        <div className="row   ">
          {articles ? (
            <>
              {articles.map((item, idx) => (
                <motion.div
                  className={`col-md-6 col-lg-4 mb-4 `}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 * idx }}
                  key={idx}
                >
                  <ArticleCard card={item} />
                </motion.div>
              ))}
            </>
          ) : (
            <>
              {flagNoData ? (
                <div className="container flex-grow-1 d-flex justify-content-center align-items-center flex-column">
                  <h3 className="text-center alert alert-warning text-dark w-100">
                    {t("articles_not_found")}
                  </h3>
                </div>
              ) : (
                <>
                  <Spinner />
                </>
              )}
            </>
          )}
        </div>
        {/* pagination */}
        <nav aria-label="Page navigation">
    <ul className="pagination justify-content-center">
      <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
        <Link 
          className={`${style.pageLink} page-link`} 
          onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
          to=""
        >
          {t("PreviousNav")}
        </Link>
      </li>
      
      {[...Array(totalPages)].map((_, idx) => (
        <li 
          key={idx} 
          className={`page-item ${currentPage === idx + 1 ? style.active : ''}`}
        >
          <Link 
            className="page-link" 
            onClick={() => setCurrentPage(idx + 1)}
            to=""
          >
            {idx + 1}
          </Link>
        </li>
      ))}
      
      <li className={`page-item ${currentPage >= totalPages ? 'disabled' : ''}`}>
        <Link 
          className="page-link" 
          onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
          to="#"
        >
          {t("NextNav")}
        </Link>
      </li>
    </ul>
  </nav>
      </div>
    </section>
  );
};

export default Articles;
