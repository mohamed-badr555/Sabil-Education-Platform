import React, { useEffect, useState } from "react";
import Heading from "../../Component/Heading/Heading";
import { useTranslation } from "react-i18next";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import ApiManager from "../../Utilies/ApiManager";

export default function About() {
  const { t } = useTranslation();
  const [about, setAbout] = useState(null);
  const getAboutContent = async () => {
    try {
      const { data } = await ApiManager.getAboutData();
      if (data.code == 200) {
        setAbout(data.data);
      } else {
        setAbout(
          `<p>${t("Something went wrong, please try again later")}</p> `
        );
      }
    } catch (error) {
      setAbout(`<p>${t("Something went wrong, please try again later")}</p> `);
    }
  };
  useEffect(() => {
    getAboutContent();
  }, []);
  return (
    <section>
      <Heading title={t("know_about")} />
      {about ? (
        <div
          style={{
            color: "var(--black-light-color)",
            fontSize: "1.3rem",
            lineHeight: "1.8",
          }}
          className="container my-3"
          dangerouslySetInnerHTML={{ __html: about }}
        ></div>
      ) : (
        <Spinner />
      )}
    </section>
  );
}
