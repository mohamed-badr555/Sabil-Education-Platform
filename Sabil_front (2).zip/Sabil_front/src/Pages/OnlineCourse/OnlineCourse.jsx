import { useTranslation } from "react-i18next";
import Heading from "../../Component/Heading/Heading";
import { Outlet } from "react-router-dom";
import SubLinkNavigator from "../../Component/Ui/SubLinkNavigator/SubLinkNavigator";

const OnlineCourse = () => {
  const { t } = useTranslation();
  const OnlineCourseOptions = [
    {
      title: t("Parent"),
      active: "/study",
      to: "/study",
    },
    {
      title: t("Student"),
      active: "/study/student",
      to: "/study/student",
    },
    {
      title:t("online Packages"),
      active: "/study/JoinOnlineCourses",
      to: "/study/JoinOnlineCourses",
    },
  ];
  return (
    <section id="study" className={`overflow-hidden`}>
      <Heading title={t("OnLine_title")} text={t("Online_text")} />
      <div className="container my-5">
        <SubLinkNavigator options={OnlineCourseOptions} />
        <Outlet />
      </div>
    </section>
  );
};

export default OnlineCourse;
