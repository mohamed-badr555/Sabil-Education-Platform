import React, { useEffect, useState } from "react";
import styles from "./Jobs.module.css";
import Heading from "../../Component/Heading/Heading";
import { useTranslation } from "react-i18next";
// comment search feature if mezar change his mind
// import Search from "../../Component/Ui/SearchInput/SearchInput";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import JobCard from "../../Component/JobCard/JobCard";
import ApiManager from "../../Utilies/ApiManager";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import i18n from "../../i18n";
const Jobs = () => {
  const { t } = useTranslation();
  const [flagNoData, setFlagNoData] = useState(false);
  // const [search, setSearch] = useState("");
  const [jobs, setJobs] = useState(null);
  /**
     * {
            "id": 1,
            "title": "معلم لغة عربية للأجانب",
            "subtitle": "معلم لغة عربية للأجانب عن بعد",
            "type": "دوام كامل"
        },
     */
  const getJobs = async () =>
    // param
    {
      try {
        setJobs(null);
        setFlagNoData(false);
        const { data } = await ApiManager
          .getAllJobs
          // param
          ();
        if (data.data && data.data.length !== 0) {
          setJobs(data.data);
        } else {
          setFlagNoData(true);
          setJobs(null);
        }
      } catch (error) {
        setFlagNoData(true);
      }
    };
  useEffect(
    () => {
      getJobs();
      // `?Search=${search}`
    },
    [
      // search
    ]
  );
  return (
    <section id="jobs" className={`overflow-hidden`}>
      <Heading title={t("jobs_title")} />
      <div className="container my-5">
        {/* <Search SearchAbout={t("searchAboutJobs")} setSearch={setSearch} /> */}
        {jobs ? (
          <div className="row   ">
            {jobs.map((item, idx) => (
              <motion.div
                className="col-md-6 col-lg-4 mb-4  "
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.1 * idx }}
                key={idx}
              >
                <div
                  className={`text-center  d-flex flex-column gap-2 p-3 ${styles.jobsCard}`}
                >
                  <JobCard job={item} />
                  <Link
                    className={` text-decoration-none btn-web btn-web-primary ${styles.btncard}`}
                    to={`/jobs/${item.id}`}
                  >
                    {t("moreDetails")}
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        ) : flagNoData ? (
          <div className="text-center">
            <h3 className="text-danger">{t("jobs_not_found")}</h3>
          </div>
        ) : (
          <Spinner />
        )}
      </div>
    </section>
  );
};

export default Jobs;
