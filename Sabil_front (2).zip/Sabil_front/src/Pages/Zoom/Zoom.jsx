import React, { useEffect } from "react";
import { ZoomMtg } from "@zoom/meetingsdk";
import { useLocation, useNavigate } from "react-router-dom";

const ZoomComponent = ({
  meetingNumber,
  userName,
  sdkKey,
  sdkSecret,
  passWord,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  // const [zoomMeetingObject, setZoomMeetingObject] = useState(null);
  useEffect(() => {
    // const zoomMeeting = {
    //   meetingNumber: 86776623953,
    //   sdkKey: "3Y2lcq_vTPuSELROUD_olQ",
    //   signature:
    //     "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzWTJsY3FfdlRQdVNFTFJPVURfb2xRIiwiYXBwS2V5IjoiM1kybGNxX3ZUUHVTRUxST1VEX29sUSIsIm1uIjoiODY3NzY2MjM5NTMiLCJyb2xlIjoiMCIsImlhdCI6MTczOTI3NjY0OCwiZXhwIjoxNzM5MjgzODQ4LCJ0b2tlbkV4cCI6MTczOTI4Mzg0OCwiaXNzIjoiM1kybGNxX3ZUUHVTRUxST1VEX29sUSJ9.KCX0VavTcOX803fzqmUX_BYMSa2HH-GFQ9sug-rLCUo",
    //   userName: "مودة محمد",
    //   role: 0,
    //   password: "tV6d9D",
    //   userEmail: "abdume.z.a.r@gmail.com",
    //   zak: null,
    // };
    console.log(location.state);

    if (location.state) {
      ZoomMtg.setZoomJSLib("https://source.zoom.us/3.11.2/lib", "/av");
      ZoomMtg.preLoadWasm();
      ZoomMtg.prepareWebSDK();

      const startMeeting = () => {
        ZoomMtg.init({
          leaveUrl: window.location.origin,
          success: function () {
            ZoomMtg.join({
              meetingNumber: location.state.meetingNumber,
              userName: location.state.userName,
              signature: location.state.signature,
              sdkKey: location.state.sdkKey,
              passWord: location.state.password,
              userEmail: location.state.userEmail,
              success: function () {
                console.log(" Successfully joined Zoom meeting!");
              },
              error: function (err) {
                console.error(" Error joining Zoom meeting:", err);
              },
            });
          },
          error: function (err) {
            console.error(" Error initializing Zoom:", err);
          },
        });
      };
      startMeeting();
    } else {
      navigate("/");
    }
    //   meetingNumber: zoomMeeting.meetingNumber,
    //   sdkKey: zoomMeeting.sdkKey,
    //   sdkSecret,
    //   role: 0,
    //         success: function (res) {
    //     startMeeting(res.result);
    //   },
    //   error: function (err) {
    //     console.error(" Error Generating Signature:", err);
    //   },
    // });
  }, [meetingNumber, userName, sdkKey, sdkSecret, passWord]);

  return (
    <div>
      {/* <h2>Zoom Meeting</h2> */}
      <div id="zmmtg-root"></div>
    </div>
  );
};

export default ZoomComponent;
