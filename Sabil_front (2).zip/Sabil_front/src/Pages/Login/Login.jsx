import React, { useContext, useEffect, useState } from "react";
import style from "./Login.module.css";
import { useTranslation } from "react-i18next";
import * as Yup from "yup";
import { useFormik } from "formik";
import { Link, useNavigate } from "react-router-dom";
import ApiManager from "../../Utilies/ApiManager";
import { authContext } from "../../Context/authContext";
import FloatingInput from "../../Component/Ui/FloatingInput/FloatingInput";
import { motion } from "framer-motion";
import Swal from "sweetalert2";

export default function Login() {
  const { t, i18n } = useTranslation();
  const [responseFlag, setResponseFlag] = useState(false);
  const { setToken } = useContext(authContext);
  let navigator = useNavigate();

  const validationSchemaYup = Yup.object().shape({
    // validation for email or phone
    email: Yup.string()
      .email(t("Invalid email address"))
      .required(t("Required")),
    password: Yup.string()
      .min(6, t("Password must contain at least 6 characters"))
      .required(t("Required")),
  });

  // send message to the server
  const loginToWebsite = async (values) => {
    let data = JSON.stringify({
      emailOrPhone: values.email,
      password: values.password,
      remember: values.remember,
    });

    setResponseFlag(true);
    await ApiManager.login(data)
      .then((response) => {
        let res = response.data;
        if (!res.code && res.token) {
          if (res.isVerified) {
            Swal.fire({
              icon: "success",
              title: t("Login successfully"),
              timer: 3000,
              showConfirmButton: false,
            });

            setTimeout(() => {
              setToken(res.token);
              navigator("/");
            }, 3000);
          } else {
            Swal.fire({
              icon: "info",
              title: t("You need to verify your email"),
              timer: 4000,
              showConfirmButton: false,
            });

            setTimeout(() => {
              setToken(res.token);
              navigator("/EmailConfirmOtp", { state: { token: res.token } });
            }, 4000);
          }
        } else {
          Swal.fire({
            icon: "error",
            title: t("Something went wrong, please try again later"),
          });
        }

        setResponseFlag(false);
      })
      .catch((error) => {
        console.error("There was an error sending the message!", error);
        setResponseFlag(false);
        let res = error.response?.data;
        if (res?.code && res.code == 400) {
          Swal.fire({
            icon: "error",
            title: t("Invalid email or password"),
          });
        } else {
          Swal.fire({
            icon: "error",
            title: t("Something went wrong, please try again later"),
          });
        }
      });
  };

  const myFormik = useFormik({
    initialValues: {
      email: "",
      password: "",
      remember: false,
    },
    onSubmit: loginToWebsite,
    validationSchema: validationSchemaYup,
  });
  const loginInputs = [
    {
      inputType: "email",
      inputName: "email",
      inputTransition: "email",
      icon: "fa-user",
    },
    {
      inputType: "password",
      inputName: "password",
      inputTransition: "password",
      icon: "fa-lock",
    },
  ];

  //function using swal to display message this future will added soon
  const displayMessage = () => {
    Swal.fire({
      icon: "info",
      title:
        i18n.language === "ar"
          ? "هذه الخاصية ستضاف قريبا"
          : "This feature will be added soon",
      timer: 3000,
      showConfirmButton: false,
    });
  };

  return (
    <section className={style.Login + " d-flex align-items-center "} id="Login">
      <form
        onSubmit={myFormik.handleSubmit} // Changed from submitForm to handleSubmit
        className="container d-flex flex-column"
      >
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className={style["heading"] + " my-5"}
        >
          <h2>
            {t("User")} <span>{t("Login")}</span>
          </h2>
          <p>{t("Login_desc")}</p>
        </motion.div>
        {/* Direct signIn with google and Facebook */}
        {/* <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className={
            style["inputContainer"] +
            " d-flex justify-content-center align-items-center gap-2 mb-3"
          }
        >
          <button
            onClick={displayMessage}
            type="button"
            className="btn btn-outline-success px-md-5 py-md-2 w-50 "
          >
            <i className="fa-brands fa-google"></i> {t("Login_google")}
          </button>
          <button
            onClick={displayMessage}
            type="button"
            className="btn btn-outline-info px-md-5 py-md-2 w-50"
          >
            <i className="fa-brands fa-facebook"></i> {t("Login_facebook")}
          </button>
        </motion.div> */}

        {loginInputs.map((input, index) => (
          <div key={index} className={style["inputContainer"] + " mb-3"}>
            <FloatingInput
              key={index}
              idx={index}
              {...input}
              myFormik={myFormik}
            />
          </div>
        ))}
        {/* Remember me */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className={style["inputContainer"]}
        >
          <div className="form-check mb-3 d-flex align-items-center gap-5">
            <input
              className="form-check-input"
              type="checkbox"
              id="flexCheckDefault"
              name="remember"
              onChange={myFormik.handleChange}
              checked={myFormik.values.remember}
            />
            <label className="form-check-label" htmlFor="flexCheckDefault">
              {t("Remember_me")}
            </label>
          </div>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          type="submit"
          disabled={responseFlag}
          className=" object-fit-contain btn-web btn-web-primary"
        >
          <span>
            {responseFlag ? (
              <div className="spinner-border text-light" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              t("Login_btn")
            )}
          </span>
        </motion.button>

        <motion.p
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className={"my-3 " + style["login-footer"]}
        >
          {t("donot_have_account")}
          <Link to={"/Register"}> {t("create_account")} </Link>
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className={style["login-footer"]}
        >
          <Link className="lead " to={"/forget-password-email"}>
            {t("Login_forget_password")}
          </Link>
        </motion.div>
      </form>
    </section>
  );
}
