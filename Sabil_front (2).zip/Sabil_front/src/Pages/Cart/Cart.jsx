import React, { useContext, useEffect, useState } from "react";
import Heading from "../../Component/Heading/Heading";
import { useTranslation } from "react-i18next";
import style from "./Cart.module.css";
import { Link, useNavigate } from "react-router-dom";
import { basketContext } from "../../Context/basketContext";
import Spinner from "../../Component/Ui/Spinner/Spinner";
import cartImg from "../../assets/Images/Cart.png";
import Swal from "sweetalert2";
import CartCard from "../../Component/CartCard/CartCard";
import PaymentsMethods from "../../Component/PaymentsMethods/PaymentsMethods";
import { authContext } from "../../Context/authContext";
const Cart = () => {
  const { t } = useTranslation();
  const { isRegistered, token } = useContext(authContext);
  const navigate = useNavigate();
  const {
    basket,
    getBasket,
    removeBasketItem,
    clearBasket,
    applyCoupon,
    coupon,
    setCoupon,
  } = useContext(basketContext);
  const [showModal, setShowModal] = useState(false);
  const removeItem = (id) => {
    Swal.fire({
      title: t("Are you sure you want to remove this item?"),
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      cancelButtonText: t("Cancel"),
      confirmButtonText: t("Yes, remove it!"),
    }).then(async (result) => {
      if (result.isConfirmed) {
        await removeBasketItem(id);
        Swal.fire(t("Removed!"), t("Item has been removed."), "success");
      }
    });
  };
  const clear = async () => {
    Swal.fire({
      title: t("Are you sure you want to clear the cart"),
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: t("Yes, clear it!"),
    }).then(async (result) => {
      if (result.isConfirmed) {
        await clearBasket();
        Swal.fire(t("Cleared!"), t("Cart has been cleared."), "success");
      }
    });
  };
  const payNow = () => {
    if (isRegistered) {
      setShowModal(true);
    } else {
      Swal.fire({
        title: t("You must be logged in to"),
        icon: "warning",
        confirmButtonColor: "#3085d6",
        confirmButtonText: t("login_now"),
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/login");
        }
      });
    }
  };
  useEffect(() => {
    getBasket();
  }, []);
  return (
    <>
      {basket ? (
        basket?.items?.length !== 0 ? (
          <section id="cart" className="overflow-hidden">
            <Heading title={t("cart_title")} />
            <div className="container  my-5">
              <div className="d-flex justify-content-start align-items-center gap-3 mb-3 ">
                <button
                  className="btn btn-outline-danger border-0"
                  onClick={clear}
                >
                  <i className="fa-solid fa-trash p-0"></i>
                </button>
                <h2 className={`${style.cartTitle} `}>
                  {t("cart_title")} <span>{basket.items.length}</span>
                </h2>
              </div>
              <div className="row g-3">
                <div className="col-lg-7">
                  {basket.items.map((item, idx) => (
                    <CartCard
                      item={item}
                      idx={idx}
                      key={idx}
                      length={basket.items.length}
                      currency={basket.currency}
                      removeItem={removeItem}
                    />
                  ))}
                </div>
                <div className="col-lg-5">
                  <div className={`${style.cardTotal}`}>
                    <h4 className={`${style.cardTotalTittle}`}>
                      {t("Total_Request")}
                    </h4>
                    <div className={`${style.bordetTOPBottom}`}>
                      <div className="d-flex align-items-center justify-content-between  ">
                        <p className={`${style.cardTotalLabel}`}>
                          {t("Total_price")}
                        </p>
                        <div className={`${style.cardTotalPrice}`}>
                          {basket.totalPriceBefore} {basket.currency}
                        </div>
                      </div>
                      <div className="d-flex align-items-center justify-content-between  ">
                        <p className={`${style.cardTotalLabel}`}>
                          {t("display_discount")}
                        </p>
                        <div className={`${style.cardTotaldiscount}`}>
                          -{" "}
                          {Number(basket.totalPriceBefore) - basket.totalPrice}{" "}
                          {basket.currency}
                        </div>
                      </div>

                      <div className="d-flex align-items-center justify-content-between gap-2 flex-wrap  ">
                        <p className={`${style.cardTotalLabel}`}>
                          {t("cart_discount")}
                        </p>
                        <div
                          className={
                            "d-flex align-items-center flex-grow-1 " +
                            style.discountInputContainer
                          }
                        >
                          <input
                            id="discountInput"
                            type="text"
                            disabled={basket?.coupon}
                            className={`${style.discountInput}`}
                            onChange={(e) => setCoupon(e.target.value)}
                            value={coupon}
                            placeholder={t("enter_discount_code")}
                          />
                          {!basket?.coupon && (
                            <button
                              htmlFor="applyDiscount"
                              onClick={() => applyCoupon(coupon)}
                              className={`${style.applyDiscount}`}
                            >
                              {t("apply_discount")}
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="d-flex align-items-center justify-content-between  ">
                        <p className={`${style.cardTotalLabel}`}>
                          {t("display_discount")}
                        </p>
                        {basket.coupon && (
                          <div className={`${style.cardTotalPrice}`}>
                            {basket?.coupon?.couponType == 1
                              ? basket?.coupon.discount + "%"
                              : basket?.coupon.discount}{" "}
                            {t("Kasm")}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="d-flex align-items-center my-2 justify-content-between  ">
                      <p className={`${style.cardTotalLabel}`}>
                        {t("Total_price")}
                      </p>
                      <div className={`${style.cardTotalSumary}`}>
                        {basket.totalPrice} {basket.currency}
                      </div>
                    </div>

                    <div className="d-flex justify-content-center">
                      <button
                        className={`${style.payNow}  w-50 my-2 `}
                        onClick={payNow}
                      >
                        {t("Pay_now")}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        ) : (
          <div className={style.noData}>
            <img src={cartImg} alt="Cart Image" />
            <h2>
              {t("There aren't any item in Cart, Add item to Start Shopping")}
            </h2>
            <Link to={"/courses"} className="btn-web btn-web-primary fw-bold">
              {t("Go To Courses")}
            </Link>
          </div>
        )
      ) : (
        <Spinner />
      )}
      {/* Payment Methods */}
      {showModal && (
        <PaymentsMethods
          hidePayments={setShowModal}
          cartId={basket?.id}
          token={token}
        />
      )}
    </>
  );
};

export default Cart;
