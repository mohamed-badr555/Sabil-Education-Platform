import { useContext, useEffect, useState } from "react";
import style from "./Register.module.css";
import { useTranslation } from "react-i18next";
import * as Yup from "yup";
import { useFormik } from "formik";
import { Link, useNavigate } from "react-router-dom";
import ApiManager from "../../Utilies/ApiManager";
import { authContext } from "../../Context/authContext";
import FloatingInput from "../../Component/Ui/FloatingInput/FloatingInput";
import SelectElement from "../../Component/Ui/SelectElement/SelectElement";
import { motion } from "framer-motion";
import PhoneInput from "../../Component/Ui/PhoneInput/PhoneInput";
import { arCountries, countries } from "../../Utilies/data";
import Swal from "sweetalert2";
import DatalistElement from "../../Component/Ui/DatalistElement/DatalistElement";

export default function Register() {
  const { t, i18n } = useTranslation();
  const [responseFlag, setResponseFlag] = useState(false);
  const { setToken } = useContext(authContext);
  let navigator = useNavigate();

  const validationSchemaYup = Yup.object().shape({
    firstName: Yup.string().required(t("Required")),
    lastName: Yup.string().required(t("Required")),
    phone: Yup.string().required(t("Required")),
    email: Yup.string()
      .email(t("Invalid email address"))
      .required(t("Required")),
    password: Yup.string()
      .min(6, t("Password must contain at least 6 characters"))

      .required(t("Required")),
    confirmPassword: Yup.string()
      .required(t("Required"))
      .oneOf([Yup.ref("password"), null], t("Passwords must match")),
    birthDate: Yup.date().required(t("Required")),
    eduLevel: Yup.number().required(t("Required")),
    gender: Yup.string().required(t("Required")),
    countryId: Yup.string().required(t("Required")),
  });

  const countryOptions = (i18n.language === "ar" ? arCountries : countries).map(
    (country) => ({
      value: country.value,
      key: country.key,
    })
  );

  // send message to the server
  const registerToWebsite = async (values) => {
    let data = JSON.stringify({
      ...values,
      gender: "M" == values.gender,
    });

    setResponseFlag(true);
    await ApiManager.register(data)
      .then((response) => {
        let res = response.data;

        if (res.code == 200 && res.token) {
          Swal.fire({
            icon: "info",
            title: t("You need to verify your email"),
            timer: 3000,
            showConfirmButton: false,
          });

          setTimeout(() => {
            setToken(res.token);
            navigator("/EmailConfirmOtp", { state: { token: res.token } });
          }, 3000);
        } else if (res.code == 201) {
          setTimeout(() => {
            navigator("/");
          }, 1000);
        } else {
          Swal.fire({
            icon: "error",
            title: t("Something went wrong, please try again later"),
          });
        }

        setResponseFlag(false);
      })
      .catch((error) => {
        setResponseFlag(false);
        let res = error.response?.data;

        if (res?.code && res.code == 400) {
          Swal.fire({
            icon: "error",
            title: res.errors[0],
          });
        } else {
          Swal.fire({
            icon: "error",
            title: t("Something went wrong, please try again later"),
          });
        }
      });
  };

  const myFormik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      phone: "",
      email: "",
      password: "",
      confirmPassword: "",
      birthDate: "",
      gender: "",
      countryId: "",
      eduLevel: "",
    },
    onSubmit: registerToWebsite,
    validationSchema: validationSchemaYup,
  });
  const registerInputs = [
    {
      inputType: "text",
      inputName: "firstName",
      inputTransition: "firstName",
      icon: "fa-user",
    },
    {
      inputType: "text",
      inputName: "lastName",
      inputTransition: "lastName",
      icon: "fa-user",
    },
    {
      inputType: "tel",
      inputName: "phone",
      inputTransition: "phoneNumber",
      icon: "fa-phone",
    },
    {
      inputType: "email",
      inputName: "email",
      inputTransition: "email",
      icon: "fa-envelope",
    },
  ];

  const registerInputs2 = [
    {
      inputType: "date",
      inputName: "birthDate",
      inputTransition: "birthday",
      icon: "fa-calendar",
    },
    {
      inputType: "password",
      inputName: "password",
      inputTransition: "password",
      icon: "fa-lock",
    },
    {
      inputType: "password",
      inputName: "confirmPassword",
      inputTransition: "confirmPassword",
      icon: "fa-lock",
    },
  ];
  const registerSelect = [
    {
      selectName: "eduLevel",
      selectTransition: "eduLevel",
      options: [
        {
          key: "level 1",
          value: 1,
        },
        {
          key: "level 2",
          value: 2,
        },
        {
          key: "level 3",
          value: 3,
        },
        {
          key: "level 4",
          value: 4,
        },
        {
          key: "level 5",
          value: 5,
        },
        {
          key: "level 6",
          value: 6,
        },
        {
          key: "level 7",
          value: 7,
        },
        {
          key: "level 8",
          value: 8,
        },
      ],
      icon: "fa-graduation-cap",
    },
    {
      selectName: "countryId",
      selectTransition: "Country",
      options: countryOptions,
      icon: "fa-location-dot",
    },

    {
      selectName: "gender",
      selectTransition: "Gender",
      options: [
        {
          key: "Male",
          value: "M",
        },
        {
          key: "Female",
          value: "F",
        },
      ],
      icon: "fa-children",
    },
  ];
  //function using swal to display message this future will added soon
  const displayMessage = () => {
    Swal.fire({
      icon: "info",
      title:
        i18n.language == "ar"
          ? "هذه الخاصية ستضاف قريبا"
          : "This feature will be added soon",
      timer: 3000,
      showConfirmButton: false,
    });
  };
  return (
    <section
      className={style.Register + " d-flex align-items-center "}
      id="Register"
    >
      <form onSubmit={myFormik.handleSubmit} className="container">
        <div className="row">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className={style["heading"] + " my-5"}
          >
            <h2>
              {t("User_Register")} <span>{t("Register")}</span>
            </h2>
            <p>{t("Register_desc")}</p>
          </motion.div>

          {/* <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className=" d-flex justify-content-center align-items-center gap-2 mb-3"
          >
            <button
              onClick={displayMessage}
              type="button"
              className="btn btn-outline-success px-md-5 py-md-2 w-50 "
            >
              <i className="fa-brands fa-google"></i> {t("Register_google")}
            </button>
            <button
              onClick={displayMessage}
              type="button"
              className="btn btn-outline-info px-md-5 py-md-2 w-50"
            >
              <i className="fa-brands fa-facebook"></i> {t("Register_facebook")}
            </button>
          </motion.div> */}

          {registerInputs.map((input, index) => (
            <>
              {input.inputType == "tel" ? (
                <div key={index} className="col-md-6 ">
                  <PhoneInput idx={index} {...input} myFormik={myFormik} />
                </div>
              ) : (
                <div key={index} className="col-md-6  ">
                  <FloatingInput idx={index} {...input} myFormik={myFormik} />
                </div>
              )}
            </>
          ))}
          {registerSelect.map((select, index) => (
            <div key={index} className="col-md-6">
              {select.selectName == "countryId" ? (
                <DatalistElement
                  idx={index}
                  {...select}
                  myFormik={myFormik}
                  icon={select.icon}
                />
              ) : (
                <SelectElement
                  idx={index}
                  {...select}
                  myFormik={myFormik}
                  icon={select.icon}
                />
              )}
            </div>
          ))}
          {registerInputs2.map((input, index) => (
            <div key={index} className="col-md-6">
              <FloatingInput
                key={index}
                idx={index}
                {...input}
                myFormik={myFormik}
              />
            </div>
          ))}

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="col-12"
          >
            <button
              type="submit"
              disabled={responseFlag}
              className="btn-web btn-web-primary"
            >
              {responseFlag ? (
                <div className="spinner-border text-light" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              ) : (
                t("Register_btn")
              )}
            </button>

            <p className={"my-3 " + style.haveAccount}>
              {t("have_account")}
              <Link to={"/Login"}> {t("login_now")} </Link>
            </p>
          </motion.div>
        </div>
      </form>
    </section>
  );
}
