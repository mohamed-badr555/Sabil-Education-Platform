import React, { lazy, useContext } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import style from "./Home.module.css";
const MainSwiper = lazy(() => import("../../Component/MainSwip/MainSwiper"));
const Hero = lazy(() => import("../../Component/Hero/Hero"));
const WhyUS = lazy(() => import("../../Component/WhyUS/WhyUS"));

const CourseTeacherCard = lazy(() =>
  import("../../Component/CourseTeacherCard/CourseTeacherCard")
);

const ContactUs = lazy(() => import("../../Component/ContactUS/ContactUs"));


import Spinner from "../../Component/Ui/Spinner/Spinner";
import { HomeContentContext } from "../../Context/homeContentContext";
import { authContext } from "../../Context/authContext";

const Home = () => {
  const { t, i18n } = useTranslation();
  const { homeContent, isLoading, convertToEmbedUrl } =
    useContext(HomeContentContext);
  const { isRegistered } = useContext(authContext);

  return (
    <>
      {isLoading ? (
        <Spinner />
      ) : (
        <section id="Home">
          <React.Suspense fallback={<Spinner />}>
            <Hero ads={homeContent?.ads} subAds={homeContent?.subAds} />
          </React.Suspense>
          {/* Why us */}
          <React.Suspense fallback={<Spinner />}>
            <WhyUS whyUs={homeContent?.whyUs} />
          </React.Suspense>
          <div className="mainSwoper">
            {homeContent?.courses && homeContent?.courses.length > 0 && (
              <div className="container my-5  ">
                <div className={`${style.headSection}`}>
                  <h2>{t("Courses_title")}</h2>
                  <p>{t("Courses_text")}</p>
                </div>

                <React.Suspense fallback={<Spinner />}>
                  <MainSwiper
                    data={homeContent?.courses}
                    Card={CourseTeacherCard}
                  />
                </React.Suspense>
                <div
                  className={`${style["watch-all"]} my-2 text-center rounded-pill `}
                >
                  <Link
                    to={`/courses`}
                    className="d-flex align-items-center justify-content-center w-100 "
                  >
                    <span
                      className={`${style.arrowAll} d-flex align-items-center justify-content-center`}
                    >
                      {i18n.language == "ar" ? (
                        <i className="fa-solid fs-6  fa-arrow-left"></i>
                      ) : (
                        <i className="fa-solid fs-6 fa-arrow-right"></i>
                      )}
                    </span>
                    {t("Watch_more")}
                  </Link>
                </div>
              </div>
            )}
            {/* Teachers */}
            
            {/* <React.Suspense fallback={<Spinner />}>
              <div className="container my-5  ">
                <div className={`${style.headSection}`}>
                  <h2>{t("teacher_title")}</h2>
                  <p>{t("teacher_text")}</p>
                </div>
                <MainSwiper data={homeContent?.teachers} Card={TeacherCard} />

    
                <div
                  className={`${style["watch-all"]} my-2 text-center rounded-pill `}
                >
                  <Link
                    to={`/teachers`}
                    className="d-flex align-items-center justify-content-center w-100 "
                  >
                    <span
                      className={`${style.arrowAll} d-flex align-items-center justify-content-center`}
                    >
                      {i18n.language == "ar" ? (
                        <i className="fa-solid fs-6  fa-arrow-left"></i>
                      ) : (
                        <i className="fa-solid fs-6 fa-arrow-right"></i>
                      )}
                    </span>
                    {t("Watch_more")}
                  </Link>
                </div>
              </div>
            </React.Suspense> */}

            {/* Books */}
            {/* <div className={`${style.books}`}>
              {homeContent?.bookCategories &&
                homeContent?.bookCategories.length > 0 && (
                  <div className="container my-5  ">
                    <div className={`${style.headSection}`}>
                      <h2>{t("book_title")}</h2>
                      <p>{t("book_text")}</p>
                    </div>
                    <React.Suspense fallback={<Spinner />}>
                      <MainSwiper
                        data={homeContent?.bookCategories}
                        Card={BookCategoryCard}
                      />
                    </React.Suspense>
                    <div
                      className={`${style["watch-all"]} my-2 text-center rounded-pill `}
                    >
                      <Link
                        to={`/books`}
                        className="d-flex align-items-center justify-content-center w-100 "
                      >
                        <span
                          className={`${style.arrowAll} d-flex align-items-center justify-content-center`}
                        >
                          {i18n.language == "ar" ? (
                            <i className="fa-solid fs-6  fa-arrow-left"></i>
                          ) : (
                            <i className="fa-solid fs-6 fa-arrow-right"></i>
                          )}
                        </span>
                        {t("Watch_more")}
                      </Link>
                    </div>
                  </div>
                )}
            </div> */}
            {/* Articles */}
            {/* {homeContent?.blogs && homeContent?.blogs.length > 0 && (
              <div className="container my-5  ">
                <div className={`${style.headSection}`}>
                  <h2>{t("article_title")}</h2>
                  <p>{t("article_text")}</p>
                </div>
                <React.Suspense fallback={<Spinner />}>
                  <MainSwiper data={homeContent?.blogs} Card={ArticleCard} />
                </React.Suspense>
                <div
                  className={`${style["watch-all"]} my-2 text-center rounded-pill `}
                >
                  <Link
                    to={`/articles`}
                    className="d-flex align-items-center justify-content-center w-100 "
                  >
                    <span
                      className={`${style.arrowAll} d-flex align-items-center justify-content-center`}
                    >
                      {i18n.language == "ar" ? (
                        <i className="fa-solid fs-6  fa-arrow-left"></i>
                      ) : (
                        <i className="fa-solid fs-6 fa-arrow-right"></i>
                      )}
                    </span>
                    {t("Watch_more")}
                  </Link>
                </div>
              </div>
            )} */}
          </div>

        
          {/* <div className={`${style.start_your_journey}`}>
            <div className="container">
              <div className="d-flex flex-row flex-wrap align-items-center justify-content-between">
                <div className={`${style.text} text-center`}>
                  <h3>{t("Start_YourJourney")}</h3>
                  <div className="d-flex flex-row flex-wrap justify-content-center ">
                    {!isRegistered && (
                      <div
                        className={`text-center rounded ${
                          style.home_link + " " + style.register_now
                        }`}
                      >
                        <Link
                          to="/register"
                          className="d-flex align-items-center justify-content-center w-100"
                        >
                          <span
                            className={`${style.arrow} d-flex align-items-center justify-content-center`}
                          >
                            {i18n.language === "ar" ? (
                              <i className="fa-solid fs-6 fa-arrow-left"></i>
                            ) : (
                              <i className="fa-solid fs-6 fa-arrow-right"></i>
                            )}
                          </span>
                          {t("register_now_about")}
                        </Link>
                      </div>
                    )}
                    <div
                      className={`text-center rounded ${
                        style.home_link + " " + style.know_about
                      }`}
                    >
                   
                      <Link
                        to="/about"
                        className="d-flex align-items-center justify-content-center w-100"
                      >
                        <span
                          className={`${style.arrow} d-flex align-items-center justify-content-center`}
                        >
                          {i18n.language === "ar" ? (
                            <i className="fa-solid fs-6 fa-arrow-left"></i>
                          ) : (
                            <i className="fa-solid fs-6 fa-arrow-right"></i>
                          )}
                        </span>
                        {t("know_about")}
                      </Link>
                    </div>
                  </div>
                </div>
                <div className={`${style.youtube}`}>
                  <iframe
                  
                    src={convertToEmbedUrl(homeContent?.homeInfo.welcomeVideo)}
                    title="التعريف بمنصة حصون التعليمية 🥰"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
            </div>
          </div> */}
          {/* Contact us */}
          {/* <React.Suspense fallback={<Spinner />}>
            <ContactUs contact={homeContent?.homeInfo} />
          </React.Suspense> */}
          {/* CallUs */}
        </section>
      )}
    </>
  );
};

export default Home;
